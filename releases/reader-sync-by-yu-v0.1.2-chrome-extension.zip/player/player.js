// src/shared/logger.ts
function log(level, scope, message, metadata) {
  const prefix = `[reader-sync:${scope}]`;
  if (metadata === void 0) {
    console[level](`${prefix} ${message}`);
    return;
  }
  console[level](`${prefix} ${message}`, metadata);
}
function createLogger(scope) {
  return {
    debug(message, metadata) {
      log("debug", scope, message, metadata);
    },
    info(message, metadata) {
      log("info", scope, message, metadata);
    },
    warn(message, metadata) {
      log("warn", scope, message, metadata);
    },
    error(message, metadata) {
      log("error", scope, message, metadata);
    }
  };
}

// src/shared/protocol.ts
var PLAYER_PORT_NAME = "reader-sync-player";
function isObject(value) {
  return typeof value === "object" && value !== null;
}
function clamp(value, minimum, maximum) {
  return Math.min(Math.max(value, minimum), maximum);
}
function normalizeEpisodeSlug(fileName) {
  const sanitized = fileName.toLowerCase().replace(/\.[a-z0-9]{2,4}$/g, "").replace(/[^a-z0-9]+/g, " ").trim();
  const seasonEpisodeMatch = sanitized.match(/^(.*?)(s\d{1,2}e\d{1,2})\b/);
  if (seasonEpisodeMatch) {
    const seriesName = seasonEpisodeMatch[1].replace(/[^a-z0-9]+/g, "_").replace(/_+/g, "_").replace(/^_+|_+$/g, "");
    const episodeToken = seasonEpisodeMatch[2];
    return `${seriesName}_${episodeToken}`;
  }
  return sanitized.replace(/[^a-z0-9]+/g, "_").replace(/_+/g, "_").replace(/^_+|_+$/g, "");
}
function resolveActiveSyncEntry(manifest2, currentTimeMs) {
  if (!manifest2 || manifest2.sync.length === 0) {
    return null;
  }
  let low = 0;
  let high = manifest2.sync.length - 1;
  while (low <= high) {
    const middle = Math.floor((low + high) / 2);
    const entry = manifest2.sync[middle];
    if (currentTimeMs < entry.startMs) {
      high = middle - 1;
      continue;
    }
    if (currentTimeMs > entry.endMs) {
      low = middle + 1;
      continue;
    }
    return entry;
  }
  let nearestEntry = null;
  let nearestDistance = Number.POSITIVE_INFINITY;
  for (const entry of manifest2.sync) {
    if (currentTimeMs >= entry.startMs && currentTimeMs <= entry.endMs) {
      return entry;
    }
    const distance = currentTimeMs < entry.startMs ? entry.startMs - currentTimeMs : currentTimeMs - entry.endMs;
    if (distance < nearestDistance) {
      nearestDistance = distance;
      nearestEntry = entry;
    }
  }
  return nearestDistance <= 1500 ? nearestEntry : null;
}

// src/shared/runtime-sync-builder.ts
var SPEAKER_PREFIX_PATTERN = /^[A-Za-z][A-Za-z' .-]{0,40}:\s*/;
var NON_ALPHANUMERIC_PATTERN = /[^a-z0-9\s]/g;
var MULTISPACE_PATTERN = /\s+/g;
function normalizeAlignmentText(value) {
  return value.toLowerCase().trim().replace(SPEAKER_PREFIX_PATTERN, "").replace(NON_ALPHANUMERIC_PATTERN, " ").replace(MULTISPACE_PATTERN, " ").trim();
}
function tokenizeAlignmentText(value) {
  return normalizeAlignmentText(value).split(" ").filter((token) => token.length >= 2);
}
function lcsLength(left, right) {
  if (left.length === 0 || right.length === 0) {
    return 0;
  }
  const row = new Array(right.length + 1).fill(0);
  for (let leftIndex = 1; leftIndex <= left.length; leftIndex += 1) {
    let diagonal = 0;
    for (let rightIndex = 1; rightIndex <= right.length; rightIndex += 1) {
      const previous = row[rightIndex];
      if (left[leftIndex - 1] === right[rightIndex - 1]) {
        row[rightIndex] = diagonal + 1;
      } else {
        row[rightIndex] = Math.max(row[rightIndex], row[rightIndex - 1]);
      }
      diagonal = previous;
    }
  }
  return row[right.length] ?? 0;
}
function calculateSimilarity(left, right) {
  if (!left || !right) {
    return 0;
  }
  const leftTokens = tokenizeAlignmentText(left);
  const rightTokens = tokenizeAlignmentText(right);
  if (leftTokens.length === 0 || rightTokens.length === 0) {
    return 0;
  }
  const leftSet = new Set(leftTokens);
  const rightSet = new Set(rightTokens);
  const overlapCount = Array.from(leftSet).filter((token) => rightSet.has(token)).length;
  const tokenOverlap = overlapCount / Math.max(leftSet.size, rightSet.size);
  const lcsRatio = lcsLength(leftTokens, rightTokens) / Math.max(leftTokens.length, rightTokens.length);
  let score = Math.max(lcsRatio, lcsRatio * 0.75 + tokenOverlap * 0.25);
  const normalizedLeft = normalizeAlignmentText(left);
  const normalizedRight = normalizeAlignmentText(right);
  if (Math.min(normalizedLeft.length, normalizedRight.length) >= 15 && tokenOverlap >= 0.45 && (normalizedLeft.includes(normalizedRight) || normalizedRight.includes(normalizedLeft))) {
    score = Math.max(score, 0.9);
  }
  return score;
}
function joinTranscriptText(segments) {
  return segments.map((segment) => normalizeAlignmentText(segment.text)).filter(Boolean).join(" ").trim();
}
function joinArticleText(paragraphs) {
  return paragraphs.map((paragraph) => normalizeAlignmentText(paragraph.text)).filter(Boolean).join(" ").trim();
}
function splitTimeRange(startMs, endMs, weights) {
  const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
  if (totalWeight <= 0 || endMs <= startMs) {
    return weights.map(() => [startMs, endMs]);
  }
  const result = [];
  let cursor = startMs;
  for (let index = 0; index < weights.length; index += 1) {
    if (index === weights.length - 1) {
      result.push([cursor, endMs]);
      break;
    }
    const sliceDuration = Math.max(1, Math.round((endMs - startMs) * (weights[index] / totalWeight)));
    const nextCursor = Math.min(endMs, cursor + sliceDuration);
    result.push([cursor, nextCursor]);
    cursor = nextCursor;
  }
  return result;
}
function isLowSignalText(value) {
  if (value.includes("\u{1F3BC}")) {
    return true;
  }
  const normalized = normalizeAlignmentText(value);
  if (!normalized) {
    return true;
  }
  const tokens = tokenizeAlignmentText(normalized);
  return tokens.length <= 2 && normalized.length <= 12;
}
function trimLowSignalSegments(segments) {
  let startIndex = 0;
  let endIndex = segments.length;
  while (startIndex < endIndex && isLowSignalText(segments[startIndex]?.text ?? "")) {
    startIndex += 1;
  }
  while (endIndex > startIndex && isLowSignalText(segments[endIndex - 1]?.text ?? "")) {
    endIndex -= 1;
  }
  return startIndex < endIndex ? segments.slice(startIndex, endIndex) : segments;
}
function buildCandidate(transcriptSegments, articleParagraphs, transcriptStart, transcriptWindow, paragraphStart, paragraphWindow, baseTranscriptIndex, baseParagraphIndex) {
  const transcriptSlice = transcriptSegments.slice(transcriptStart, transcriptStart + transcriptWindow);
  const articleSlice = articleParagraphs.slice(paragraphStart, paragraphStart + paragraphWindow);
  if (transcriptSlice.length === 0 || articleSlice.length === 0) {
    return null;
  }
  const trimmedTranscriptSlice = trimLowSignalSegments(transcriptSlice);
  const transcriptText = joinTranscriptText(trimmedTranscriptSlice);
  const articleText = joinArticleText(articleSlice);
  if (!transcriptText || !articleText) {
    return null;
  }
  const similarity = calculateSimilarity(articleText, transcriptText);
  const lengthBalance = Math.min(articleText.length, transcriptText.length) / Math.max(articleText.length, transcriptText.length);
  const continuityPenalty = (transcriptStart - baseTranscriptIndex) * 0.09 + (paragraphStart - baseParagraphIndex) * 0.06;
  const windowPenalty = (transcriptWindow - 1) * 0.02 + (paragraphWindow - 1) * 0.015;
  const score = similarity * (0.85 + 0.15 * lengthBalance) - continuityPenalty - windowPenalty;
  return {
    transcriptStart,
    transcriptEnd: transcriptStart + transcriptWindow,
    paragraphStart,
    paragraphEnd: paragraphStart + paragraphWindow,
    similarity,
    score
  };
}
function findBestCandidate(transcriptSegments, articleParagraphs, transcriptIndex, paragraphIndex, options) {
  let bestCandidate = null;
  for (let transcriptOffset = 0; transcriptOffset <= options.maxTranscriptLookahead; transcriptOffset += 1) {
    const candidateTranscriptStart = transcriptIndex + transcriptOffset;
    if (candidateTranscriptStart >= transcriptSegments.length) {
      break;
    }
    for (let paragraphOffset = 0; paragraphOffset <= options.maxParagraphLookahead; paragraphOffset += 1) {
      const candidateParagraphStart = paragraphIndex + paragraphOffset;
      if (candidateParagraphStart >= articleParagraphs.length) {
        break;
      }
      for (let transcriptWindow = 1; transcriptWindow <= options.maxSegmentWindow; transcriptWindow += 1) {
        if (candidateTranscriptStart + transcriptWindow > transcriptSegments.length) {
          break;
        }
        for (let paragraphWindow = 1; paragraphWindow <= options.maxParagraphWindow; paragraphWindow += 1) {
          if (candidateParagraphStart + paragraphWindow > articleParagraphs.length) {
            break;
          }
          const candidate = buildCandidate(
            transcriptSegments,
            articleParagraphs,
            candidateTranscriptStart,
            transcriptWindow,
            candidateParagraphStart,
            paragraphWindow,
            transcriptIndex,
            paragraphIndex
          );
          if (!candidate) {
            continue;
          }
          if (!bestCandidate || candidate.score > bestCandidate.score) {
            bestCandidate = candidate;
          }
        }
      }
    }
  }
  return bestCandidate;
}
function calculateReanchorScore(candidate, baseTranscriptIndex, baseParagraphIndex) {
  const transcriptOffset = candidate.transcriptStart - baseTranscriptIndex;
  const paragraphOffset = candidate.paragraphStart - baseParagraphIndex;
  const windowPenalty = (candidate.transcriptEnd - candidate.transcriptStart - 1) * 0.015 + (candidate.paragraphEnd - candidate.paragraphStart - 1) * 0.012;
  return candidate.similarity - transcriptOffset * 0.02 - paragraphOffset * 0.012 - windowPenalty;
}
function findBestReanchorCandidate(transcriptSegments, articleParagraphs, transcriptIndex, paragraphIndex) {
  const options = {
    maxSegmentWindow: 4,
    maxParagraphWindow: 4,
    maxTranscriptLookahead: 24,
    maxParagraphLookahead: 12
  };
  let bestCandidate = null;
  let bestScore = Number.NEGATIVE_INFINITY;
  for (let transcriptOffset = 0; transcriptOffset <= options.maxTranscriptLookahead; transcriptOffset += 1) {
    const candidateTranscriptStart = transcriptIndex + transcriptOffset;
    if (candidateTranscriptStart >= transcriptSegments.length) {
      break;
    }
    for (let paragraphOffset = 0; paragraphOffset <= options.maxParagraphLookahead; paragraphOffset += 1) {
      const candidateParagraphStart = paragraphIndex + paragraphOffset;
      if (candidateParagraphStart >= articleParagraphs.length) {
        break;
      }
      for (let transcriptWindow = 1; transcriptWindow <= options.maxSegmentWindow; transcriptWindow += 1) {
        if (candidateTranscriptStart + transcriptWindow > transcriptSegments.length) {
          break;
        }
        for (let paragraphWindow = 1; paragraphWindow <= options.maxParagraphWindow; paragraphWindow += 1) {
          if (candidateParagraphStart + paragraphWindow > articleParagraphs.length) {
            break;
          }
          const candidate = buildCandidate(
            transcriptSegments,
            articleParagraphs,
            candidateTranscriptStart,
            transcriptWindow,
            candidateParagraphStart,
            paragraphWindow,
            transcriptIndex,
            paragraphIndex
          );
          if (!candidate) {
            continue;
          }
          const reanchorScore = calculateReanchorScore(candidate, transcriptIndex, paragraphIndex);
          if (!bestCandidate || reanchorScore > bestScore) {
            bestCandidate = candidate;
            bestScore = reanchorScore;
          }
        }
      }
    }
  }
  return bestCandidate;
}
function appendCandidateSyncEntries(syncEntries, transcriptSegments, articleParagraphs, candidate) {
  const transcriptSlice = trimLowSignalSegments(
    transcriptSegments.slice(candidate.transcriptStart, candidate.transcriptEnd)
  );
  const articleSlice = articleParagraphs.slice(candidate.paragraphStart, candidate.paragraphEnd);
  const weights = articleSlice.map((paragraph) => Math.max(1, normalizeAlignmentText(paragraph.text).length));
  const timeRanges = splitTimeRange(
    transcriptSlice[0]?.startMs ?? 0,
    transcriptSlice[transcriptSlice.length - 1]?.endMs ?? 0,
    weights
  );
  const transcriptSegmentIndexes = transcriptSlice.map((segment) => segment.index);
  for (let itemIndex = 0; itemIndex < articleSlice.length; itemIndex += 1) {
    const paragraph = articleSlice[itemIndex];
    const [startMs, endMs] = timeRanges[itemIndex] ?? [
      transcriptSlice[0]?.startMs ?? 0,
      transcriptSlice[transcriptSlice.length - 1]?.endMs ?? 0
    ];
    syncEntries.push({
      paragraphIndex: paragraph.paragraphIndex,
      startMs,
      endMs,
      transcriptSegmentIndexes,
      alignmentScore: candidate.similarity
    });
  }
}
function fillSmallGapSyncEntries(syncEntries, articleParagraphs, options) {
  if (syncEntries.length === 0) {
    return [];
  }
  const paragraphLookup = new Map(articleParagraphs.map((paragraph) => [paragraph.paragraphIndex, paragraph]));
  const filledEntries = [];
  for (let index = 0; index < syncEntries.length; index += 1) {
    const currentEntry = syncEntries[index];
    filledEntries.push(currentEntry);
    if (index === syncEntries.length - 1) {
      continue;
    }
    const nextEntry = syncEntries[index + 1];
    const missingCount = nextEntry.paragraphIndex - currentEntry.paragraphIndex - 1;
    const availableDuration = nextEntry.startMs - currentEntry.endMs;
    if (missingCount <= 0 || missingCount > options.maxGapParagraphs) {
      continue;
    }
    if (availableDuration <= 120 || availableDuration > options.maxGapDurationMs) {
      continue;
    }
    const missingParagraphs = [];
    for (let paragraphIndex = currentEntry.paragraphIndex + 1; paragraphIndex < nextEntry.paragraphIndex; paragraphIndex += 1) {
      const paragraph = paragraphLookup.get(paragraphIndex);
      if (!paragraph) {
        missingParagraphs.length = 0;
        break;
      }
      missingParagraphs.push(paragraph);
    }
    if (missingParagraphs.length === 0) {
      continue;
    }
    const weights = missingParagraphs.map((paragraph) => Math.max(1, normalizeAlignmentText(paragraph.text).length));
    const timeRanges = splitTimeRange(currentEntry.endMs, nextEntry.startMs, weights);
    for (let missingIndex = 0; missingIndex < missingParagraphs.length; missingIndex += 1) {
      const paragraph = missingParagraphs[missingIndex];
      const [startMs, endMs] = timeRanges[missingIndex] ?? [currentEntry.endMs, nextEntry.startMs];
      filledEntries.push({
        paragraphIndex: paragraph.paragraphIndex,
        startMs,
        endMs,
        transcriptSegmentIndexes: [],
        alignmentScore: 0.35
      });
    }
  }
  return filledEntries.sort((left, right) => left.paragraphIndex - right.paragraphIndex);
}
function estimateFallbackParagraphDurationMs(transcriptSegments, articleParagraphs, syncEntries) {
  if (syncEntries.length >= 2) {
    const totalAnchoredDuration = syncEntries[syncEntries.length - 1].endMs - syncEntries[0].startMs;
    const anchoredSpanParagraphs = syncEntries[syncEntries.length - 1].paragraphIndex - syncEntries[0].paragraphIndex + 1;
    if (totalAnchoredDuration > 0 && anchoredSpanParagraphs > 0) {
      return totalAnchoredDuration / anchoredSpanParagraphs;
    }
  }
  const transcriptDuration = Math.max(0, (transcriptSegments[transcriptSegments.length - 1]?.endMs ?? 0) - (transcriptSegments[0]?.startMs ?? 0));
  if (transcriptDuration > 0 && articleParagraphs.length > 0) {
    return transcriptDuration / articleParagraphs.length;
  }
  return 1500;
}
function fillRemainingGapSyncEntries(syncEntries, transcriptSegments, articleParagraphs) {
  if (syncEntries.length === 0) {
    return [];
  }
  const sortedEntries = [...syncEntries].sort((left, right) => left.paragraphIndex - right.paragraphIndex);
  const entryByParagraphIndex = new Map(sortedEntries.map((entry) => [entry.paragraphIndex, entry]));
  const fallbackParagraphDurationMs = estimateFallbackParagraphDurationMs(transcriptSegments, articleParagraphs, sortedEntries);
  const transcriptStartMs = Math.max(0, transcriptSegments[0]?.startMs ?? 0);
  const transcriptEndMs = Math.max(transcriptStartMs, transcriptSegments[transcriptSegments.length - 1]?.endMs ?? transcriptStartMs);
  const firstEntry = sortedEntries[0];
  if (firstEntry && firstEntry.paragraphIndex > articleParagraphs[0].paragraphIndex) {
    const headParagraphs = articleParagraphs.filter((paragraph) => paragraph.paragraphIndex < firstEntry.paragraphIndex);
    const headStartMs = Math.max(transcriptStartMs, firstEntry.startMs - fallbackParagraphDurationMs * headParagraphs.length);
    const headRanges = splitTimeRange(headStartMs, Math.max(headStartMs, firstEntry.startMs), headParagraphs.map((paragraph) => Math.max(1, normalizeAlignmentText(paragraph.text).length)));
    headParagraphs.forEach((paragraph, index) => {
      if (entryByParagraphIndex.has(paragraph.paragraphIndex)) {
        return;
      }
      const [startMs, endMs] = headRanges[index] ?? [headStartMs, firstEntry.startMs];
      entryByParagraphIndex.set(paragraph.paragraphIndex, {
        paragraphIndex: paragraph.paragraphIndex,
        startMs,
        endMs,
        transcriptSegmentIndexes: [],
        alignmentScore: 0.2
      });
    });
  }
  for (let index = 0; index < sortedEntries.length - 1; index += 1) {
    const currentEntry = sortedEntries[index];
    const nextEntry = sortedEntries[index + 1];
    const gapParagraphs = articleParagraphs.filter(
      (paragraph) => paragraph.paragraphIndex > currentEntry.paragraphIndex && paragraph.paragraphIndex < nextEntry.paragraphIndex
    );
    if (gapParagraphs.length === 0) {
      continue;
    }
    const gapStartMs = Math.min(currentEntry.endMs, nextEntry.startMs);
    const gapEndMs = Math.max(currentEntry.endMs, nextEntry.startMs);
    const ranges = gapEndMs > gapStartMs ? splitTimeRange(
      gapStartMs,
      gapEndMs,
      gapParagraphs.map((paragraph) => Math.max(1, normalizeAlignmentText(paragraph.text).length))
    ) : gapParagraphs.map((_, gapIndex) => {
      const startMs = currentEntry.endMs + gapIndex * fallbackParagraphDurationMs;
      return [startMs, startMs + fallbackParagraphDurationMs];
    });
    gapParagraphs.forEach((paragraph, gapIndex) => {
      if (entryByParagraphIndex.has(paragraph.paragraphIndex)) {
        return;
      }
      const [startMs, endMs] = ranges[gapIndex] ?? [currentEntry.endMs, nextEntry.startMs];
      entryByParagraphIndex.set(paragraph.paragraphIndex, {
        paragraphIndex: paragraph.paragraphIndex,
        startMs,
        endMs,
        transcriptSegmentIndexes: [],
        alignmentScore: 0.18
      });
    });
  }
  const lastEntry = sortedEntries[sortedEntries.length - 1];
  if (lastEntry && lastEntry.paragraphIndex < articleParagraphs[articleParagraphs.length - 1].paragraphIndex) {
    const tailParagraphs = articleParagraphs.filter((paragraph) => paragraph.paragraphIndex > lastEntry.paragraphIndex);
    const tailEndMs = Math.max(lastEntry.endMs, Math.min(transcriptEndMs, lastEntry.endMs + fallbackParagraphDurationMs * tailParagraphs.length));
    const tailRanges = splitTimeRange(lastEntry.endMs, tailEndMs, tailParagraphs.map((paragraph) => Math.max(1, normalizeAlignmentText(paragraph.text).length)));
    tailParagraphs.forEach((paragraph, index) => {
      if (entryByParagraphIndex.has(paragraph.paragraphIndex)) {
        return;
      }
      const [startMs, endMs] = tailRanges[index] ?? [lastEntry.endMs, tailEndMs];
      entryByParagraphIndex.set(paragraph.paragraphIndex, {
        paragraphIndex: paragraph.paragraphIndex,
        startMs,
        endMs,
        transcriptSegmentIndexes: [],
        alignmentScore: 0.2
      });
    });
  }
  return Array.from(entryByParagraphIndex.values()).sort((left, right) => left.paragraphIndex - right.paragraphIndex);
}
function sortSyncEntriesByTimeline(syncEntries) {
  return [...syncEntries].map((entry) => {
    const startMs = Math.max(0, entry.startMs);
    return {
      ...entry,
      startMs,
      endMs: Math.max(startMs + 1, entry.endMs)
    };
  }).sort((left, right) => {
    if (left.startMs !== right.startMs) {
      return left.startMs - right.startMs;
    }
    if (left.endMs !== right.endMs) {
      return left.endMs - right.endMs;
    }
    return left.paragraphIndex - right.paragraphIndex;
  });
}
function finalizeAlignmentResult(syncEntries, transcriptSegments, articleParagraphs) {
  const smallGapFilledEntries = fillSmallGapSyncEntries(
    syncEntries.sort((left, right) => left.paragraphIndex - right.paragraphIndex),
    articleParagraphs,
    {
      maxGapParagraphs: 3,
      maxGapDurationMs: 12e3
    }
  );
  const allFilledEntries = fillRemainingGapSyncEntries(smallGapFilledEntries, transcriptSegments, articleParagraphs);
  const timelineSortedEntries = sortSyncEntriesByTimeline(allFilledEntries);
  const anchoredParagraphCount = timelineSortedEntries.filter((entry) => entry.transcriptSegmentIndexes.length > 0).length;
  const unmatchedParagraphCount = articleParagraphs.length - timelineSortedEntries.length;
  return {
    syncEntries: timelineSortedEntries,
    matchedParagraphCount: anchoredParagraphCount,
    unmatchedParagraphCount,
    consumedSegmentCount: transcriptSegments.length
  };
}
function buildAlignmentOptions() {
  return {
    maxSegmentWindow: 3,
    maxParagraphWindow: 3,
    maxTranscriptLookahead: 4,
    maxParagraphLookahead: 4
  };
}
function createProgressReporter(transcriptSegments, articleParagraphs, onProgress) {
  return (phase, processedSegmentCount, processedParagraphCount, message) => {
    if (!onProgress) {
      return;
    }
    const progressBase = phase === "preparing" ? 0.04 : phase === "matching" ? 0.08 + 0.8 * Math.max(
      processedParagraphCount / Math.max(articleParagraphs.length, 1),
      processedSegmentCount / Math.max(transcriptSegments.length, 1)
    ) : phase === "smoothing" ? 0.93 : 1;
    onProgress({
      phase,
      processedParagraphCount,
      articleParagraphCount: articleParagraphs.length,
      processedSegmentCount,
      subtitleSegmentCount: transcriptSegments.length,
      percent: Math.max(0, Math.min(1, progressBase)),
      message
    });
  };
}
function yieldToBrowser() {
  return new Promise((resolve) => {
    window.setTimeout(resolve, 0);
  });
}
async function buildSyncEntriesAsync(transcriptSegments, articleParagraphs, onProgress) {
  const reportProgress = createProgressReporter(transcriptSegments, articleParagraphs, onProgress);
  reportProgress("preparing", 0, 0, "\u6B63\u5728\u51C6\u5907\u5B57\u5E55\u548C\u6587\u7AE0\u6BB5\u843D...");
  const syncEntries = [];
  let transcriptIndex = 0;
  let paragraphIndex = 0;
  let iterationCount = 0;
  let lastYieldAt = performance.now();
  const options = buildAlignmentOptions();
  const minimumMatchScore = 0.55;
  const rescueMatchScore = 0.48;
  const reanchorSimilarityThreshold = 0.74;
  const reanchorScoreThreshold = 0.56;
  while (transcriptIndex < transcriptSegments.length && paragraphIndex < articleParagraphs.length) {
    iterationCount += 1;
    const candidate = findBestCandidate(transcriptSegments, articleParagraphs, transcriptIndex, paragraphIndex, options);
    if (candidate && candidate.score >= minimumMatchScore) {
      appendCandidateSyncEntries(syncEntries, transcriptSegments, articleParagraphs, candidate);
      transcriptIndex = candidate.transcriptEnd;
      paragraphIndex = candidate.paragraphEnd;
    } else {
      const rescueCandidate = candidate && candidate.score >= rescueMatchScore && candidate.transcriptStart === transcriptIndex && candidate.paragraphStart === paragraphIndex ? candidate : null;
      if (rescueCandidate) {
        appendCandidateSyncEntries(syncEntries, transcriptSegments, articleParagraphs, rescueCandidate);
        transcriptIndex = rescueCandidate.transcriptEnd;
        paragraphIndex = rescueCandidate.paragraphEnd;
      } else {
        const currentTranscriptText = transcriptSegments[transcriptIndex]?.text ?? "";
        const currentParagraphText = articleParagraphs[paragraphIndex]?.text ?? "";
        if (isLowSignalText(currentTranscriptText)) {
          transcriptIndex += 1;
        } else if (isLowSignalText(currentParagraphText)) {
          paragraphIndex += 1;
        } else {
          const reanchorCandidate = findBestReanchorCandidate(
            transcriptSegments,
            articleParagraphs,
            transcriptIndex,
            paragraphIndex
          );
          const reanchorScore = reanchorCandidate ? calculateReanchorScore(reanchorCandidate, transcriptIndex, paragraphIndex) : Number.NEGATIVE_INFINITY;
          if (reanchorCandidate && reanchorCandidate.similarity >= reanchorSimilarityThreshold && reanchorScore >= reanchorScoreThreshold) {
            appendCandidateSyncEntries(syncEntries, transcriptSegments, articleParagraphs, reanchorCandidate);
            transcriptIndex = reanchorCandidate.transcriptEnd;
            paragraphIndex = reanchorCandidate.paragraphEnd;
            continue;
          }
          const skipTranscriptCandidate = findBestCandidate(
            transcriptSegments,
            articleParagraphs,
            Math.min(transcriptIndex + 1, transcriptSegments.length),
            paragraphIndex,
            options
          );
          const skipParagraphCandidate = findBestCandidate(
            transcriptSegments,
            articleParagraphs,
            transcriptIndex,
            Math.min(paragraphIndex + 1, articleParagraphs.length),
            options
          );
          const skipTranscriptScore = skipTranscriptCandidate?.score ?? -1;
          const skipParagraphScore = skipParagraphCandidate?.score ?? -1;
          if (skipTranscriptScore >= skipParagraphScore) {
            transcriptIndex += 1;
          } else {
            paragraphIndex += 1;
          }
        }
      }
    }
    if (iterationCount % 2 === 0 || performance.now() - lastYieldAt >= 20) {
      reportProgress("matching", transcriptIndex, paragraphIndex, `\u6B63\u5728\u5339\u914D\u7B2C ${Math.min(paragraphIndex + 1, articleParagraphs.length)}/${articleParagraphs.length} \u6BB5...`);
      await yieldToBrowser();
      lastYieldAt = performance.now();
    }
  }
  reportProgress("smoothing", transcriptIndex, paragraphIndex, "\u6B63\u5728\u5E73\u6ED1\u8865\u9F50\u5C0F\u7F3A\u53E3...");
  await yieldToBrowser();
  reportProgress("finalizing", transcriptIndex, articleParagraphs.length, "\u6B63\u5728\u751F\u6210\u6700\u7EC8\u540C\u6B65\u6E05\u5355...");
  const finalizedResult = finalizeAlignmentResult(syncEntries, transcriptSegments, articleParagraphs);
  return {
    ...finalizedResult,
    consumedSegmentCount: transcriptIndex
  };
}
async function buildRuntimeManifestFromSubtitleAsync(subtitleDocument, articleSnapshot2, onProgress) {
  const transcriptSegments = subtitleDocument.transcript.segments;
  const articleParagraphs = articleSnapshot2.paragraphs;
  if (transcriptSegments.length === 0) {
    throw new Error("\u5B57\u5E55\u6587\u4EF6\u91CC\u6CA1\u6709\u53EF\u7528\u5BF9\u767D\u6BB5\u3002");
  }
  if (articleParagraphs.length === 0) {
    throw new Error("\u6587\u7AE0\u5FEB\u7167\u4E3A\u7A7A\uFF0C\u65E0\u6CD5\u6267\u884C\u8FD0\u884C\u65F6\u5339\u914D\u3002");
  }
  const alignmentResult = await buildSyncEntriesAsync(transcriptSegments, articleParagraphs, onProgress);
  if (alignmentResult.syncEntries.length === 0) {
    throw new Error("\u5B57\u5E55\u4E0E\u5F53\u524D\u6587\u7AE0\u6CA1\u6709\u627E\u5230\u53EF\u7528\u5339\u914D\uFF0C\u6682\u65F6\u65E0\u6CD5\u751F\u6210\u540C\u6B65\u6E05\u5355\u3002");
  }
  const smoothedParagraphCount = alignmentResult.syncEntries.filter((entry) => entry.transcriptSegmentIndexes.length === 0).length;
  const coverageRatio = alignmentResult.matchedParagraphCount / articleParagraphs.length;
  if (alignmentResult.matchedParagraphCount < 3) {
    throw new Error(`\u76F4\u63A5\u547D\u4E2D\u7684\u951A\u70B9\u8FC7\u5C11 (${alignmentResult.matchedParagraphCount} \u6BB5)\uFF0C\u8BF7\u786E\u8BA4\u5F53\u524D\u9875\u9762\u548C\u5B57\u5E55\u662F\u5426\u5C5E\u4E8E\u540C\u4E00\u96C6\u3002`);
  }
  const manifest2 = {
    version: "1.0.0",
    source: {
      slug: normalizeEpisodeSlug(subtitleDocument.fileName),
      title: articleSnapshot2.title || subtitleDocument.metadata.title,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      generator: "reader-sync-extension-runtime-subtitle",
      mediaFileName: subtitleDocument.fileName,
      articleUrl: articleSnapshot2.articleUrl,
      articleId: articleSnapshot2.articleId ?? void 0,
      categoryId: articleSnapshot2.categoryId ?? void 0
    },
    transcript: {
      mode: subtitleDocument.transcript.mode,
      language: subtitleDocument.transcript.language,
      modelName: subtitleDocument.transcript.modelName,
      text: subtitleDocument.transcript.text,
      segments: transcriptSegments
    },
    article: {
      capturedAt: articleSnapshot2.capturedAt,
      title: articleSnapshot2.title,
      articleUrl: articleSnapshot2.articleUrl,
      paragraphs: articleParagraphs
    },
    sync: alignmentResult.syncEntries
  };
  return {
    manifest: manifest2,
    stats: {
      subtitleSegmentCount: transcriptSegments.length,
      articleParagraphCount: articleParagraphs.length,
      matchedParagraphCount: alignmentResult.matchedParagraphCount,
      unmatchedParagraphCount: alignmentResult.unmatchedParagraphCount,
      smoothedParagraphCount,
      consumedSegmentCount: alignmentResult.consumedSegmentCount,
      coverageRatio
    }
  };
}

// src/shared/subtitle-parser.ts
var ASS_TAG_PATTERN = /\{[^}]*\}/g;
var HTML_TAG_PATTERN = /<[^>]+>/g;
var SPEAKER_PREFIX_PATTERN2 = /^[A-Za-z][A-Za-z' .-]{0,40}:\s*/;
var MULTISPACE_PATTERN2 = /\s+/g;
var CJK_PATTERN = /[\u3400-\u9fff]/;
var LATIN_PATTERN = /[A-Za-z]/g;
function detectTextEncoding(bytes) {
  if (bytes.length >= 2) {
    if (bytes[0] === 255 && bytes[1] === 254) {
      return "utf-16le";
    }
    if (bytes[0] === 254 && bytes[1] === 255) {
      return "utf-16be";
    }
  }
  if (bytes.length >= 3 && bytes[0] === 239 && bytes[1] === 187 && bytes[2] === 191) {
    return "utf-8";
  }
  let nullByteCount = 0;
  for (const value of bytes) {
    if (value === 0) {
      nullByteCount += 1;
    }
  }
  return nullByteCount > bytes.length * 0.15 ? "utf-16le" : "utf-8";
}
async function readTextFile(file) {
  const buffer = new Uint8Array(await file.arrayBuffer());
  return new TextDecoder(detectTextEncoding(buffer), { fatal: false }).decode(buffer);
}
function normalizeWhitespace(value) {
  return value.replace(/\r/g, "").replace(/\uFEFF/g, "").replace(MULTISPACE_PATTERN2, " ").trim();
}
function stripSpeakerPrefix(value) {
  return value.replace(SPEAKER_PREFIX_PATTERN2, "").trim();
}
function scoreEnglishLikelihood(value) {
  const normalized = value.trim();
  if (!normalized) {
    return -100;
  }
  const latinCount = (normalized.match(LATIN_PATTERN) ?? []).length;
  const cjkCount = (normalized.match(CJK_PATTERN) ?? []).length;
  const asciiCount = Array.from(normalized).filter((character) => character.charCodeAt(0) <= 127).length;
  return latinCount * 3 + asciiCount - cjkCount * 4;
}
function pickPrimaryAndTranslation(rawLines) {
  const cleanedLines = rawLines.map((line) => normalizeWhitespace(stripSpeakerPrefix(line))).filter(Boolean);
  if (cleanedLines.length === 0) {
    return { text: "" };
  }
  if (cleanedLines.length === 1) {
    return { text: cleanedLines[0] };
  }
  const rankedLines = cleanedLines.map((line) => ({ line, score: scoreEnglishLikelihood(line) })).sort((left, right) => right.score - left.score);
  const primary = rankedLines[0]?.line ?? cleanedLines[0];
  const translation = cleanedLines.find((line) => line !== primary);
  return {
    text: primary,
    translation
  };
}
function toTranscriptSegments(lines) {
  const segments = lines.map((line, index) => ({
    index: index + 1,
    startMs: line.startMs,
    endMs: Math.max(line.endMs, line.startMs + 1),
    text: line.text
  })).filter((segment) => segment.text.length > 0 && segment.endMs > segment.startMs);
  return segments.map((segment, index) => ({
    ...segment,
    index: index + 1
  }));
}
function normalizeSubtitleText(value) {
  return value.replace(/\r/g, "").replace(/\uFEFF/g, "").replace(ASS_TAG_PATTERN, "").replace(HTML_TAG_PATTERN, "").replace(/\\N/gi, "\n").replace(/\\n/gi, "\n").replace(/\\h/gi, " ");
}
function parseAssTimestamp(value) {
  const match = value.trim().match(/^(\d+):(\d{1,2}):(\d{1,2})[.:](\d{1,3})$/);
  if (!match) {
    throw new Error(`\u65E0\u6548\u7684 ASS \u65F6\u95F4\u6233: ${value}`);
  }
  const hours = Number.parseInt(match[1], 10);
  const minutes = Number.parseInt(match[2], 10);
  const seconds = Number.parseInt(match[3], 10);
  const fractionRaw = match[4];
  const milliseconds = fractionRaw.length === 1 ? Number.parseInt(fractionRaw, 10) * 100 : fractionRaw.length === 2 ? Number.parseInt(fractionRaw, 10) * 10 : Number.parseInt(fractionRaw.slice(0, 3), 10);
  return (hours * 60 + minutes) * 60 * 1e3 + seconds * 1e3 + milliseconds;
}
function parseAssDialogue(text) {
  const normalizedText = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const lines = normalizedText.split("\n");
  let inEventsSection = false;
  let eventFormat = [];
  let title;
  const parsedLines = [];
  let translationCount = 0;
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) {
      continue;
    }
    if (line.startsWith("[")) {
      inEventsSection = line.toLowerCase() === "[events]";
      continue;
    }
    if (/^title:/i.test(line)) {
      title = normalizeWhitespace(line.slice(line.indexOf(":") + 1));
      continue;
    }
    if (!inEventsSection) {
      continue;
    }
    if (/^format:/i.test(line)) {
      eventFormat = line.slice(line.indexOf(":") + 1).split(",").map((value) => value.trim().toLowerCase());
      continue;
    }
    if (!/^dialogue:/i.test(line)) {
      continue;
    }
    if (eventFormat.length === 0) {
      throw new Error("ASS \u6587\u4EF6\u7F3A\u5C11 [Events] Format \u5B9A\u4E49\u3002");
    }
    const rawFields = line.slice(line.indexOf(":") + 1).split(",");
    if (rawFields.length < eventFormat.length) {
      continue;
    }
    const fields = rawFields.slice(0, eventFormat.length - 1);
    fields.push(rawFields.slice(eventFormat.length - 1).join(","));
    const startIndex = eventFormat.indexOf("start");
    const endIndex = eventFormat.indexOf("end");
    const textIndex = eventFormat.indexOf("text");
    if (startIndex === -1 || endIndex === -1 || textIndex === -1) {
      throw new Error("ASS Events Format \u7F3A\u5C11 start/end/text \u5B57\u6BB5\u3002");
    }
    const normalizedDialogue = normalizeSubtitleText(fields[textIndex] ?? "");
    const { text: primaryText, translation } = pickPrimaryAndTranslation(normalizedDialogue.split("\n"));
    if (!primaryText) {
      continue;
    }
    if (translation) {
      translationCount += 1;
    }
    parsedLines.push({
      startMs: parseAssTimestamp(fields[startIndex] ?? ""),
      endMs: parseAssTimestamp(fields[endIndex] ?? ""),
      text: primaryText,
      translation
    });
  }
  return {
    title,
    segmentCount: parsedLines.length,
    translationCount,
    lines: parsedLines
  };
}
function parseSrtTimestamp(value) {
  const match = value.trim().match(/^(\d{2,}):(\d{2}):(\d{2})[,.](\d{3})$/);
  if (!match) {
    throw new Error(`\u65E0\u6548\u7684 SRT/VTT \u65F6\u95F4\u6233: ${value}`);
  }
  const hours = Number.parseInt(match[1], 10);
  const minutes = Number.parseInt(match[2], 10);
  const seconds = Number.parseInt(match[3], 10);
  const milliseconds = Number.parseInt(match[4], 10);
  return (hours * 60 + minutes) * 60 * 1e3 + seconds * 1e3 + milliseconds;
}
function parseSimpleTimedSubtitle(text, format) {
  const normalizedText = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\uFEFF/g, "");
  const blocks = normalizedText.split(/\n{2,}/);
  const parsedLines = [];
  let translationCount = 0;
  for (const block of blocks) {
    const lines = block.split("\n").map((line) => line.trim()).filter(Boolean);
    if (lines.length === 0 || format === "vtt" && lines[0] === "WEBVTT") {
      continue;
    }
    const timingLineIndex = lines.findIndex((line) => line.includes("-->"));
    if (timingLineIndex === -1) {
      continue;
    }
    const [startRaw, endRaw] = lines[timingLineIndex].split("-->").map((value) => value.trim().split(/\s+/)[0] ?? "");
    const textLines = lines.slice(timingLineIndex + 1).map((line) => normalizeSubtitleText(line));
    const { text: primaryText, translation } = pickPrimaryAndTranslation(textLines);
    if (!primaryText) {
      continue;
    }
    if (translation) {
      translationCount += 1;
    }
    parsedLines.push({
      startMs: parseSrtTimestamp(startRaw),
      endMs: parseSrtTimestamp(endRaw),
      text: primaryText,
      translation
    });
  }
  return {
    segmentCount: parsedLines.length,
    translationCount,
    lines: parsedLines
  };
}
function buildParsedDocument(fileName, format, metadata, lines) {
  const segments = toTranscriptSegments(lines);
  if (segments.length === 0) {
    throw new Error("\u5B57\u5E55\u6587\u4EF6\u91CC\u6CA1\u6709\u53EF\u7528\u5BF9\u767D\u6BB5\u3002");
  }
  return {
    fileName,
    format,
    transcript: {
      mode: `subtitle-${format}`,
      language: "en",
      modelName: format === "ass" ? "sidecar-ass-subtitle" : "sidecar-subtitle",
      text: segments.map((segment) => segment.text).join(" ").trim(),
      segments
    },
    metadata: {
      ...metadata,
      segmentCount: segments.length
    }
  };
}
async function parseSubtitleFile(file) {
  const text = await readTextFile(file);
  const fileName = file.name;
  const extension = fileName.split(".").pop()?.toLowerCase() ?? "";
  if (extension === "ass" || extension === "ssa") {
    const parsed = parseAssDialogue(text);
    return buildParsedDocument(fileName, "ass", parsed, parsed.lines);
  }
  if (extension === "srt") {
    const parsed = parseSimpleTimedSubtitle(text, "srt");
    return buildParsedDocument(fileName, "srt", parsed, parsed.lines);
  }
  if (extension === "vtt") {
    const parsed = parseSimpleTimedSubtitle(text, "vtt");
    return buildParsedDocument(fileName, "vtt", parsed, parsed.lines);
  }
  throw new Error(`\u5F53\u524D\u8FD8\u4E0D\u652F\u6301\u8BE5\u5B57\u5E55\u683C\u5F0F: ${extension || "unknown"}`);
}

// node_modules/@ffmpeg/ffmpeg/dist/esm/const.js
var CORE_VERSION = "0.12.9";
var CORE_URL = `https://unpkg.com/@ffmpeg/core@${CORE_VERSION}/dist/umd/ffmpeg-core.js`;
var FFMessageType;
(function(FFMessageType2) {
  FFMessageType2["LOAD"] = "LOAD";
  FFMessageType2["EXEC"] = "EXEC";
  FFMessageType2["FFPROBE"] = "FFPROBE";
  FFMessageType2["WRITE_FILE"] = "WRITE_FILE";
  FFMessageType2["READ_FILE"] = "READ_FILE";
  FFMessageType2["DELETE_FILE"] = "DELETE_FILE";
  FFMessageType2["RENAME"] = "RENAME";
  FFMessageType2["CREATE_DIR"] = "CREATE_DIR";
  FFMessageType2["LIST_DIR"] = "LIST_DIR";
  FFMessageType2["DELETE_DIR"] = "DELETE_DIR";
  FFMessageType2["ERROR"] = "ERROR";
  FFMessageType2["DOWNLOAD"] = "DOWNLOAD";
  FFMessageType2["PROGRESS"] = "PROGRESS";
  FFMessageType2["LOG"] = "LOG";
  FFMessageType2["MOUNT"] = "MOUNT";
  FFMessageType2["UNMOUNT"] = "UNMOUNT";
})(FFMessageType || (FFMessageType = {}));

// node_modules/@ffmpeg/ffmpeg/dist/esm/utils.js
var getMessageID = /* @__PURE__ */ (() => {
  let messageID = 0;
  return () => messageID++;
})();

// node_modules/@ffmpeg/ffmpeg/dist/esm/errors.js
var ERROR_UNKNOWN_MESSAGE_TYPE = new Error("unknown message type");
var ERROR_NOT_LOADED = new Error("ffmpeg is not loaded, call `await ffmpeg.load()` first");
var ERROR_TERMINATED = new Error("called FFmpeg.terminate()");
var ERROR_IMPORT_FAILURE = new Error("failed to import ffmpeg-core.js");

// node_modules/@ffmpeg/ffmpeg/dist/esm/classes.js
var FFmpeg = class {
  #worker = null;
  /**
   * #resolves and #rejects tracks Promise resolves and rejects to
   * be called when we receive message from web worker.
   */
  #resolves = {};
  #rejects = {};
  #logEventCallbacks = [];
  #progressEventCallbacks = [];
  loaded = false;
  /**
   * register worker message event handlers.
   */
  #registerHandlers = () => {
    if (this.#worker) {
      this.#worker.onmessage = ({ data: { id, type, data } }) => {
        switch (type) {
          case FFMessageType.LOAD:
            this.loaded = true;
            this.#resolves[id](data);
            break;
          case FFMessageType.MOUNT:
          case FFMessageType.UNMOUNT:
          case FFMessageType.EXEC:
          case FFMessageType.FFPROBE:
          case FFMessageType.WRITE_FILE:
          case FFMessageType.READ_FILE:
          case FFMessageType.DELETE_FILE:
          case FFMessageType.RENAME:
          case FFMessageType.CREATE_DIR:
          case FFMessageType.LIST_DIR:
          case FFMessageType.DELETE_DIR:
            this.#resolves[id](data);
            break;
          case FFMessageType.LOG:
            this.#logEventCallbacks.forEach((f) => f(data));
            break;
          case FFMessageType.PROGRESS:
            this.#progressEventCallbacks.forEach((f) => f(data));
            break;
          case FFMessageType.ERROR:
            this.#rejects[id](data);
            break;
        }
        delete this.#resolves[id];
        delete this.#rejects[id];
      };
    }
  };
  /**
   * Generic function to send messages to web worker.
   */
  #send = ({ type, data }, trans = [], signal) => {
    if (!this.#worker) {
      return Promise.reject(ERROR_NOT_LOADED);
    }
    return new Promise((resolve, reject) => {
      const id = getMessageID();
      this.#worker && this.#worker.postMessage({ id, type, data }, trans);
      this.#resolves[id] = resolve;
      this.#rejects[id] = reject;
      signal?.addEventListener("abort", () => {
        reject(new DOMException(`Message # ${id} was aborted`, "AbortError"));
      }, { once: true });
    });
  };
  on(event, callback) {
    if (event === "log") {
      this.#logEventCallbacks.push(callback);
    } else if (event === "progress") {
      this.#progressEventCallbacks.push(callback);
    }
  }
  off(event, callback) {
    if (event === "log") {
      this.#logEventCallbacks = this.#logEventCallbacks.filter((f) => f !== callback);
    } else if (event === "progress") {
      this.#progressEventCallbacks = this.#progressEventCallbacks.filter((f) => f !== callback);
    }
  }
  /**
   * Loads ffmpeg-core inside web worker. It is required to call this method first
   * as it initializes WebAssembly and other essential variables.
   *
   * @category FFmpeg
   * @returns `true` if ffmpeg core is loaded for the first time.
   */
  load = ({ classWorkerURL, ...config } = {}, { signal } = {}) => {
    if (!this.#worker) {
      this.#worker = classWorkerURL ? new Worker(new URL(classWorkerURL, import.meta.url), {
        type: "module"
      }) : (
        // We need to duplicated the code here to enable webpack
        // to bundle worekr.js here.
        new Worker(new URL("./worker.js", import.meta.url), {
          type: "module"
        })
      );
      this.#registerHandlers();
    }
    return this.#send({
      type: FFMessageType.LOAD,
      data: config
    }, void 0, signal);
  };
  /**
   * Execute ffmpeg command.
   *
   * @remarks
   * To avoid common I/O issues, ["-nostdin", "-y"] are prepended to the args
   * by default.
   *
   * @example
   * ```ts
   * const ffmpeg = new FFmpeg();
   * await ffmpeg.load();
   * await ffmpeg.writeFile("video.avi", ...);
   * // ffmpeg -i video.avi video.mp4
   * await ffmpeg.exec(["-i", "video.avi", "video.mp4"]);
   * const data = ffmpeg.readFile("video.mp4");
   * ```
   *
   * @returns `0` if no error, `!= 0` if timeout (1) or error.
   * @category FFmpeg
   */
  exec = (args, timeout = -1, { signal } = {}) => this.#send({
    type: FFMessageType.EXEC,
    data: { args, timeout }
  }, void 0, signal);
  /**
   * Execute ffprobe command.
   *
   * @example
   * ```ts
   * const ffmpeg = new FFmpeg();
   * await ffmpeg.load();
   * await ffmpeg.writeFile("video.avi", ...);
   * // Getting duration of a video in seconds: ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 video.avi -o output.txt
   * await ffmpeg.ffprobe(["-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", "video.avi", "-o", "output.txt"]);
   * const data = ffmpeg.readFile("output.txt");
   * ```
   *
   * @returns `0` if no error, `!= 0` if timeout (1) or error.
   * @category FFmpeg
   */
  ffprobe = (args, timeout = -1, { signal } = {}) => this.#send({
    type: FFMessageType.FFPROBE,
    data: { args, timeout }
  }, void 0, signal);
  /**
   * Terminate all ongoing API calls and terminate web worker.
   * `FFmpeg.load()` must be called again before calling any other APIs.
   *
   * @category FFmpeg
   */
  terminate = () => {
    const ids = Object.keys(this.#rejects);
    for (const id of ids) {
      this.#rejects[id](ERROR_TERMINATED);
      delete this.#rejects[id];
      delete this.#resolves[id];
    }
    if (this.#worker) {
      this.#worker.terminate();
      this.#worker = null;
      this.loaded = false;
    }
  };
  /**
   * Write data to ffmpeg.wasm.
   *
   * @example
   * ```ts
   * const ffmpeg = new FFmpeg();
   * await ffmpeg.load();
   * await ffmpeg.writeFile("video.avi", await fetchFile("../video.avi"));
   * await ffmpeg.writeFile("text.txt", "hello world");
   * ```
   *
   * @category File System
   */
  writeFile = (path, data, { signal } = {}) => {
    const trans = [];
    if (data instanceof Uint8Array) {
      trans.push(data.buffer);
    }
    return this.#send({
      type: FFMessageType.WRITE_FILE,
      data: { path, data }
    }, trans, signal);
  };
  mount = (fsType, options, mountPoint) => {
    const trans = [];
    return this.#send({
      type: FFMessageType.MOUNT,
      data: { fsType, options, mountPoint }
    }, trans);
  };
  unmount = (mountPoint) => {
    const trans = [];
    return this.#send({
      type: FFMessageType.UNMOUNT,
      data: { mountPoint }
    }, trans);
  };
  /**
   * Read data from ffmpeg.wasm.
   *
   * @example
   * ```ts
   * const ffmpeg = new FFmpeg();
   * await ffmpeg.load();
   * const data = await ffmpeg.readFile("video.mp4");
   * ```
   *
   * @category File System
   */
  readFile = (path, encoding = "binary", { signal } = {}) => this.#send({
    type: FFMessageType.READ_FILE,
    data: { path, encoding }
  }, void 0, signal);
  /**
   * Delete a file.
   *
   * @category File System
   */
  deleteFile = (path, { signal } = {}) => this.#send({
    type: FFMessageType.DELETE_FILE,
    data: { path }
  }, void 0, signal);
  /**
   * Rename a file or directory.
   *
   * @category File System
   */
  rename = (oldPath, newPath, { signal } = {}) => this.#send({
    type: FFMessageType.RENAME,
    data: { oldPath, newPath }
  }, void 0, signal);
  /**
   * Create a directory.
   *
   * @category File System
   */
  createDir = (path, { signal } = {}) => this.#send({
    type: FFMessageType.CREATE_DIR,
    data: { path }
  }, void 0, signal);
  /**
   * List directory contents.
   *
   * @category File System
   */
  listDir = (path, { signal } = {}) => this.#send({
    type: FFMessageType.LIST_DIR,
    data: { path }
  }, void 0, signal);
  /**
   * Delete an empty directory.
   *
   * @category File System
   */
  deleteDir = (path, { signal } = {}) => this.#send({
    type: FFMessageType.DELETE_DIR,
    data: { path }
  }, void 0, signal);
};

// node_modules/@ffmpeg/ffmpeg/dist/esm/types.js
var FFFSType;
(function(FFFSType2) {
  FFFSType2["MEMFS"] = "MEMFS";
  FFFSType2["NODEFS"] = "NODEFS";
  FFFSType2["NODERAWFS"] = "NODERAWFS";
  FFFSType2["IDBFS"] = "IDBFS";
  FFFSType2["WORKERFS"] = "WORKERFS";
  FFFSType2["PROXYFS"] = "PROXYFS";
})(FFFSType || (FFFSType = {}));

// node_modules/@ffmpeg/util/dist/esm/errors.js
var ERROR_RESPONSE_BODY_READER = new Error("failed to get response body reader");
var ERROR_INCOMPLETED_DOWNLOAD = new Error("failed to complete download");

// node_modules/@ffmpeg/util/dist/esm/index.js
var readFromBlobOrFile = (blob) => new Promise((resolve, reject) => {
  const fileReader = new FileReader();
  fileReader.onload = () => {
    const { result } = fileReader;
    if (result instanceof ArrayBuffer) {
      resolve(new Uint8Array(result));
    } else {
      resolve(new Uint8Array());
    }
  };
  fileReader.onerror = (event) => {
    reject(Error(`File could not be read! Code=${event?.target?.error?.code || -1}`));
  };
  fileReader.readAsArrayBuffer(blob);
});
var fetchFile = async (file) => {
  let data;
  if (typeof file === "string") {
    if (/data:_data\/([a-zA-Z]*);base64,([^"]*)/.test(file)) {
      data = atob(file.split(",")[1]).split("").map((c) => c.charCodeAt(0));
    } else {
      data = await (await fetch(file)).arrayBuffer();
    }
  } else if (file instanceof URL) {
    data = await (await fetch(file)).arrayBuffer();
  } else if (file instanceof File || file instanceof Blob) {
    data = await readFromBlobOrFile(file);
  } else {
    return new Uint8Array();
  }
  return new Uint8Array(data);
};

// src/player/media-compatibility.ts
var preferredContainerFormats = /* @__PURE__ */ new Set(["mov", "mp4", "m4a", "3gp", "3g2", "mj2"]);
function buildOutputVideoName(fileName) {
  const lastDotIndex = fileName.lastIndexOf(".");
  const stem = lastDotIndex === -1 ? fileName : fileName.slice(0, lastDotIndex);
  return `${stem}.hvc1.aac.mp4`;
}
function buildMediaTranscodeStrategy(fileName, probe) {
  const resolvedContainerFormats = resolveContainerFormats(fileName, probe.containerFormats);
  const videoStream = probe.streams.find((stream) => stream.codecType === "video");
  const audioStreams = probe.streams.filter((stream) => stream.codecType === "audio");
  if (!videoStream) {
    throw new Error("\u8F93\u5165\u6587\u4EF6\u7F3A\u5C11\u89C6\u9891\u6D41\uFF0C\u65E0\u6CD5\u8FDB\u5165\u64AD\u653E\u5668\u3002");
  }
  const containerAction = isPreferredContainer(resolvedContainerFormats) ? "copy" : "remux";
  const videoAction = videoStream.codecName === "hevc" ? "copy" : "transcode";
  const audioAction = audioStreams.length === 0 || audioStreams.every((stream) => stream.codecName === "aac") ? "copy" : "transcode";
  return {
    containerAction,
    videoAction,
    audioAction,
    videoCodec: videoStream.codecName,
    audioCodecs: audioStreams.map((stream) => stream.codecName),
    outputFileName: buildOutputVideoName(fileName)
  };
}
function assessMediaCompatibility(fileName, probe) {
  const resolvedContainerFormats = resolveContainerFormats(fileName, probe.containerFormats);
  const strategy = buildMediaTranscodeStrategy(fileName, probe);
  const reasons = [];
  if (strategy.containerAction === "remux") {
    reasons.push(`\u5C01\u88C5\u683C\u5F0F\u4E3A ${formatContainerFormats(resolvedContainerFormats)}\uFF0C\u4E0D\u5728\u63A8\u8350\u7684 MP4/MOV \u57FA\u7EBF\u5185`);
  }
  if (strategy.videoAction === "transcode") {
    reasons.push(`\u89C6\u9891\u7F16\u7801\u4E3A ${strategy.videoCodec}\uFF0C\u4E0D\u662F\u76EE\u6807 HEVC(HVC1)`);
  }
  if (strategy.audioAction === "transcode") {
    reasons.push(`\u97F3\u9891\u7F16\u7801\u4E3A ${formatAudioCodecs(strategy.audioCodecs)}\uFF0C\u4E0D\u662F\u76EE\u6807 AAC`);
  }
  if (reasons.length === 0) {
    return {
      isRecommendedProfile: true,
      reasons,
      summary: "\u5DF2\u547D\u4E2D\u63A8\u8350\u64AD\u653E\u57FA\u7EBF\uFF0C\u5C06\u76F4\u63A5\u8FDB\u5165\u539F\u751F\u64AD\u653E\u5668\u3002",
      detail: `\u5C01\u88C5 ${formatContainerFormats(resolvedContainerFormats)}\uFF0C\u89C6\u9891 ${strategy.videoCodec}\uFF0C\u97F3\u9891 ${formatAudioCodecs(strategy.audioCodecs)}\u3002`
    };
  }
  return {
    isRecommendedProfile: false,
    reasons,
    summary: "\u5F53\u524D\u6587\u4EF6\u504F\u79BB\u63A8\u8350\u7684 HVC1 + AAC \u64AD\u653E\u57FA\u7EBF\uFF0C\u5EFA\u8BAE\u5148\u505A\u672C\u5730\u9884\u5904\u7406\u3002",
    detail: reasons.join("\uFF1B")
  };
}
function formatContainerFormats(containerFormats) {
  return containerFormats.length > 0 ? containerFormats.join(", ") : "unknown";
}
function formatAudioCodecs(audioCodecs) {
  return audioCodecs.length > 0 ? audioCodecs.join(", ") : "none";
}
function resolveContainerFormatsForDisplay(fileName, containerFormats) {
  return resolveContainerFormats(fileName, containerFormats);
}
function isPreferredContainer(containerFormats) {
  return containerFormats.some((format) => preferredContainerFormats.has(format));
}
function resolveContainerFormats(fileName, containerFormats) {
  if (containerFormats.length > 0) {
    return containerFormats;
  }
  const extension = fileName.split(".").pop()?.trim().toLowerCase() ?? "";
  switch (extension) {
    case "mkv":
      return ["matroska"];
    case "mp4":
    case "m4v":
      return ["mp4"];
    case "mov":
      return ["mov"];
    case "webm":
      return ["webm"];
    case "avi":
      return ["avi"];
    default:
      return containerFormats;
  }
}

// src/player/browser-ffmpeg-service.ts
var ENCODING_PROFILE = Object.freeze({
  crf: "34",
  preset: "ultrafast",
  audioBitrate: "96k",
  pixelFormat: "yuv420p",
  maxWidth: "1280"
});
var LOCAL_CORE_ASSETS = Object.freeze({
  coreURL: {
    path: "vendor/ffmpeg/ffmpeg-core.js",
    mimeType: "text/javascript"
  },
  wasmURL: {
    path: "vendor/ffmpeg/ffmpeg-core.wasm",
    mimeType: "application/wasm"
  },
  classWorkerURL: {
    path: "vendor/ffmpeg-runtime/worker.js",
    mimeType: "text/javascript"
  }
});
var BrowserFfmpegService = class {
  ffmpeg = new FFmpeg();
  loaded = false;
  coreAssetUrls = null;
  recentLogs = [];
  activeHandlers = null;
  constructor() {
    this.ffmpeg.on("log", ({ message }) => {
      this.recentLogs.push(message);
      if (this.recentLogs.length > 60) {
        this.recentLogs.splice(0, this.recentLogs.length - 60);
      }
      this.activeHandlers?.onLog?.(message);
    });
    this.ffmpeg.on("progress", ({ progress, time }) => {
      this.activeHandlers?.onProgress?.({ progress, time });
    });
  }
  async inspectFile(file, handlers = {}) {
    await this.ensureLoaded(handlers);
    const jobKey = crypto.randomUUID();
    const inputPath = `${jobKey}-${sanitizeFileName(file.name)}`;
    const probeOutputPath = `${jobKey}-probe.null`;
    this.activeHandlers = handlers;
    this.recentLogs.length = 0;
    try {
      handlers.onStatusChange?.({
        phase: "writing-input",
        detail: { message: "\u6B63\u5728\u5199\u5165\u5F85\u68C0\u6D4B\u6587\u4EF6\u5230\u6D4F\u89C8\u5668\u672C\u5730\u5185\u5B58\u6587\u4EF6\u7CFB\u7EDF" }
      });
      await this.ffmpeg.writeFile(inputPath, await fetchFile(file));
      handlers.onStatusChange?.({
        phase: "probing",
        detail: { message: "\u6B63\u5728\u89E3\u6790\u5BB9\u5668\u3001\u89C6\u9891\u6D41\u548C\u97F3\u9891\u6D41\u4FE1\u606F" }
      });
      this.recentLogs.length = 0;
      const probe = await inspectMedia(this.ffmpeg, inputPath, probeOutputPath, this.recentLogs);
      return probe;
    } catch (error) {
      throw enrichWithRecentLogs(error, this.recentLogs);
    } finally {
      this.activeHandlers = null;
      await safeDelete(this.ffmpeg, inputPath);
      await safeDelete(this.ffmpeg, probeOutputPath);
    }
  }
  async transcodeFile(file, probe, handlers = {}) {
    await this.ensureLoaded(handlers);
    const strategy = buildMediaTranscodeStrategy(file.name, probe);
    const jobKey = crypto.randomUUID();
    const inputPath = `${jobKey}-${sanitizeFileName(file.name)}`;
    const outputPath = `${jobKey}-${strategy.outputFileName}`;
    this.activeHandlers = handlers;
    this.recentLogs.length = 0;
    try {
      handlers.onStatusChange?.({
        phase: "writing-input",
        detail: { message: "\u6B63\u5728\u5199\u5165\u5F85\u9884\u5904\u7406\u6587\u4EF6" }
      });
      await this.ffmpeg.writeFile(inputPath, await fetchFile(file));
      handlers.onStatusChange?.({
        phase: "transcoding",
        detail: {
          message: describeStrategy(strategy)
        }
      });
      const exitCode = await this.ffmpeg.exec(buildTranscodeCommand(inputPath, outputPath, strategy));
      if (exitCode !== 0) {
        throw new Error(buildCommandFailureMessage("FFmpeg", exitCode, this.recentLogs));
      }
      handlers.onStatusChange?.({
        phase: "reading-output",
        detail: { message: "\u6B63\u5728\u8BFB\u53D6\u9884\u5904\u7406\u7ED3\u679C\u5E76\u751F\u6210\u53EF\u64AD\u653E\u6587\u4EF6" }
      });
      const outputData = await this.ffmpeg.readFile(outputPath);
      const outputBytes = outputData instanceof Uint8Array ? Uint8Array.from(outputData) : new TextEncoder().encode(String(outputData));
      const outputBlob = new Blob([outputBytes.buffer], { type: "video/mp4" });
      const outputFile = new File([outputBlob], strategy.outputFileName, { type: "video/mp4" });
      handlers.onStatusChange?.({
        phase: "completed",
        detail: { message: "\u9884\u5904\u7406\u5B8C\u6210" }
      });
      return {
        file: outputFile,
        blob: outputBlob,
        strategy,
        probe
      };
    } catch (error) {
      throw enrichWithRecentLogs(error, this.recentLogs);
    } finally {
      this.activeHandlers = null;
      await safeDelete(this.ffmpeg, inputPath);
      await safeDelete(this.ffmpeg, outputPath);
    }
  }
  terminate() {
    this.ffmpeg.terminate();
    this.loaded = false;
    this.coreAssetUrls = null;
  }
  async ensureLoaded(handlers) {
    if (this.loaded) {
      handlers.onStatusChange?.({
        phase: "ready",
        detail: { message: "\u5185\u7F6E FFmpeg Core \u5DF2\u5C31\u7EEA" }
      });
      return;
    }
    handlers.onStatusChange?.({
      phase: "loading-core",
      detail: { message: "\u6B63\u5728\u88C5\u8F7D\u6269\u5C55\u5185\u7F6E FFmpeg Core" }
    });
    if (!this.coreAssetUrls) {
      this.coreAssetUrls = await loadLocalCoreAssetUrls();
    }
    await this.ffmpeg.load(this.coreAssetUrls);
    this.loaded = true;
    handlers.onStatusChange?.({
      phase: "ready",
      detail: { message: "\u5185\u7F6E FFmpeg Core \u88C5\u8F7D\u5B8C\u6210" }
    });
  }
};
function describeStrategy(strategy) {
  const videoStep = strategy.videoAction === "copy" ? `\u89C6\u9891\u76F4\u63A5\u590D\u7528(${strategy.videoCodec})` : `\u89C6\u9891\u8F6C HEVC(HVC1)`;
  const audioStep = strategy.audioAction === "copy" ? `\u97F3\u9891\u76F4\u63A5\u590D\u7528(${strategy.audioCodecs.length > 0 ? strategy.audioCodecs.join(", ") : "none"})` : `\u97F3\u9891\u8F6C AAC`;
  const containerStep = strategy.containerAction === "copy" ? "\u6CBF\u7528 MP4/MOV \u57FA\u7EBF" : "\u91CD\u5C01\u88C5\u4E3A MP4";
  return `${containerStep}\uFF1B${videoStep}\uFF1B${audioStep}`;
}
function buildTranscodeCommand(inputPath, outputPath, strategy) {
  const command = ["-i", inputPath, "-map", "0:v:0", "-map", "0:a?"];
  if (strategy.videoAction === "copy") {
    command.push("-c:v", "copy");
  } else {
    command.push(
      "-c:v",
      "libx265",
      "-preset",
      ENCODING_PROFILE.preset,
      "-crf",
      ENCODING_PROFILE.crf,
      "-vf",
      `scale='min(${ENCODING_PROFILE.maxWidth},iw)':-2`,
      "-pix_fmt",
      ENCODING_PROFILE.pixelFormat
    );
  }
  command.push("-tag:v", "hvc1");
  if (strategy.audioAction === "copy") {
    command.push("-c:a", "copy");
  } else {
    command.push("-c:a", "aac", "-ac", "2", "-b:a", ENCODING_PROFILE.audioBitrate);
  }
  command.push("-sn", "-dn", "-movflags", "+faststart", outputPath);
  return command;
}
async function inspectMedia(ffmpeg, inputPath, probeOutputPath, recentLogs) {
  const exitCode = await ffmpeg.exec([
    "-v",
    "info",
    "-i",
    inputPath,
    "-map",
    "0:v:0",
    "-map",
    "0:a?",
    "-c",
    "copy",
    "-t",
    "0.1",
    "-f",
    "null",
    probeOutputPath
  ]);
  if (exitCode !== 0) {
    throw new Error(buildCommandFailureMessage("probe(ffmpeg)", exitCode, recentLogs));
  }
  await waitForLogFlush();
  return parseProbeFromLogs(recentLogs);
}
function parseProbeFromLogs(logs) {
  const inputLine = logs.find((line) => line.startsWith("Input #0,"));
  const videoLines = logs.filter((line) => line.includes("Video:"));
  const audioLines = logs.filter((line) => line.includes("Audio:"));
  if (videoLines.length === 0) {
    throw new Error(`\u65E0\u6CD5\u4ECE FFmpeg \u65E5\u5FD7\u4E2D\u89E3\u6790\u89C6\u9891\u6D41\u4FE1\u606F\u3002
Recent logs:
${logs.slice(-20).join("\n")}`);
  }
  const containerFormats = inputLine?.match(/^Input #0,\s+(.+),\s+from\b/)?.[1]?.split(",").map((value) => value.trim()).filter(Boolean) ?? [];
  const streams = videoLines.map((line, index) => {
    const codecName = line.match(/Video:\s+([^\s,(]+)/)?.[1];
    const width = line.match(/(\d{2,5})x(\d{2,5})/);
    if (!codecName || !width) {
      throw new Error(`\u65E0\u6CD5\u4ECE FFmpeg \u65E5\u5FD7\u4E2D\u89E3\u6790\u89C6\u9891\u7F16\u7801\u8BE6\u60C5\u3002
Recent logs:
${logs.slice(-20).join("\n")}`);
    }
    return {
      codecType: "video",
      codecName,
      index,
      width: Number.parseInt(width[1], 10),
      height: Number.parseInt(width[2], 10)
    };
  });
  audioLines.forEach((line, index) => {
    const codecName = line.match(/Audio:\s+([^\s,(]+)/)?.[1];
    if (!codecName) {
      return;
    }
    streams.push({
      codecType: "audio",
      codecName,
      index
    });
  });
  return {
    containerFormats,
    streams
  };
}
async function loadLocalCoreAssetUrls() {
  const [coreResponse, wasmResponse, classWorkerResponse] = await Promise.all([
    fetch(chrome.runtime.getURL(LOCAL_CORE_ASSETS.coreURL.path), { cache: "force-cache" }),
    fetch(chrome.runtime.getURL(LOCAL_CORE_ASSETS.wasmURL.path), { cache: "force-cache" }),
    fetch(chrome.runtime.getURL(LOCAL_CORE_ASSETS.classWorkerURL.path), { cache: "force-cache" })
  ]);
  if (!coreResponse.ok) {
    throw new Error(`\u65E0\u6CD5\u52A0\u8F7D\u6269\u5C55\u5185\u7F6E FFmpeg Core \u8D44\u6E90\uFF1A${LOCAL_CORE_ASSETS.coreURL.path} (${coreResponse.status})`);
  }
  if (!wasmResponse.ok) {
    throw new Error(`\u65E0\u6CD5\u52A0\u8F7D\u6269\u5C55\u5185\u7F6E FFmpeg Core \u8D44\u6E90\uFF1A${LOCAL_CORE_ASSETS.wasmURL.path} (${wasmResponse.status})`);
  }
  if (!classWorkerResponse.ok) {
    throw new Error(
      `\u65E0\u6CD5\u52A0\u8F7D\u6269\u5C55\u5185\u7F6E FFmpeg Runtime Worker\uFF1A${LOCAL_CORE_ASSETS.classWorkerURL.path} (${classWorkerResponse.status})`
    );
  }
  return {
    coreURL: chrome.runtime.getURL(LOCAL_CORE_ASSETS.coreURL.path),
    wasmURL: chrome.runtime.getURL(LOCAL_CORE_ASSETS.wasmURL.path),
    classWorkerURL: chrome.runtime.getURL(LOCAL_CORE_ASSETS.classWorkerURL.path)
  };
}
async function safeDelete(ffmpeg, filePath) {
  try {
    await ffmpeg.deleteFile(filePath);
  } catch {
    return;
  }
}
function sanitizeFileName(fileName) {
  return fileName.replaceAll(/[^\w.-]+/g, "_");
}
function buildCommandFailureMessage(commandName, exitCode, logs) {
  const tail = logs.slice(-12).join("\n");
  return `${commandName} exited with code ${exitCode}${tail ? `
Recent logs:
${tail}` : ""}`;
}
function enrichWithRecentLogs(error, recentLogs) {
  if (error instanceof Error && !error.message.includes("Recent logs:")) {
    return new Error(`${error.message}
Recent logs:
${recentLogs.slice(-12).join("\n")}`);
  }
  return error instanceof Error ? error : new Error(String(error));
}
function waitForLogFlush() {
  return new Promise((resolve) => {
    setTimeout(resolve, 50);
  });
}

// src/player/player.ts
var logger = createLogger("player");
var storageKey = "reader-sync-manifest-base-url";
var searchParameters = new URLSearchParams(window.location.search);
var transcriptFallbackText = "\u8BE5\u6BB5\u5F53\u524D\u4E3A\u5E73\u6ED1\u8865\u6BB5\uFF0C\u6CA1\u6709\u76F4\u63A5\u547D\u4E2D\u7684 transcript \u7247\u6BB5\u3002";
var articleFallbackText = "\u5F53\u524D\u65F6\u95F4\u5BF9\u5E94\u7684\u6587\u7AE0\u6BB5\u843D\u6682\u672A\u8FDB\u5165\u672C\u5730\u5FEB\u7167\u89C6\u91CE\u3002";
var supportedSubtitleExtensions = /* @__PURE__ */ new Set(["ass", "ssa", "srt", "vtt"]);
var supportedVideoExtensions = /* @__PURE__ */ new Set(["mp4", "m4v", "mkv", "mov", "webm", "avi"]);
var supportedManifestExtensions = /* @__PURE__ */ new Set();
var shortcutStorageKey = "reader-sync-shortcut-settings";
var tutorialStorageKey = "reader-sync-player-tutorial";
var tutorialVersion = "2026-04-player-onboarding-v1";
var defaultShortcutSettings = {
  togglePlayback: "Space",
  seekBackward: "ArrowLeft",
  seekForward: "ArrowRight",
  rateDown: "KeyZ",
  rateUp: "KeyX",
  seekSeconds: 5
};
var defaultTutorialState = {
  completedVersion: null,
  dismissedVersion: null
};
var tutorialSteps = [
  {
    title: "\u6B22\u8FCE\u6765\u5230\u64AD\u653E\u5668\u9875",
    description: "\u8FD9\u4E2A\u64AD\u653E\u5668\u9875\u4F1A\u628A\u672C\u5730\u89C6\u9891\u3001\u5B57\u5E55\u548C aim-read \u9605\u8BFB\u9875\u4E32\u8D77\u6765\u3002\u4EE5\u540E\u60F3\u518D\u770B\u4E00\u904D\u6559\u7A0B\uFF0C\u70B9\u53F3\u4E0A\u89D2\u201C\u65B0\u624B\u5F15\u5BFC\u201D\u5C31\u80FD\u91CD\u65B0\u6253\u5F00\u3002",
    targetSelector: "#tutorial-hero",
    spotlightPadding: 14
  },
  {
    title: "\u5148\u7ED1\u5B9A\u9605\u8BFB\u9875",
    description: "\u7B2C\u4E00\u6B65\u5148\u6253\u5F00\u4E00\u4E2A aim-read \u5267\u96C6\u6587\u7AE0\u9875\uFF0C\u7136\u540E\u5728\u8FD9\u91CC\u9009\u62E9\u76EE\u6807\u9875\u9762\u3002\u5217\u8868\u4E0D\u5B8C\u6574\u65F6\uFF0C\u53EF\u4EE5\u70B9\u201C\u5237\u65B0\u9875\u9762\u5217\u8868\u201D\u91CD\u65B0\u626B\u63CF\u5E76\u5237\u65B0\u6587\u7AE0\u9875\u3002",
    targetSelector: "#binding-field",
    spotlightPadding: 12
  },
  {
    title: "\u4E5F\u53EF\u4EE5\u76F4\u63A5\u62D6\u5165",
    description: "\u5982\u679C\u4F60\u66F4\u4E60\u60EF\u62D6\u62FD\uFF0C\u53EF\u4EE5\u628A\u89C6\u9891\u548C\u5B57\u5E55\u76F4\u63A5\u62D6\u5230\u8FD9\u4E2A\u533A\u57DF\u3002\u89C6\u9891\u4F1A\u81EA\u52A8\u88C5\u8F7D\uFF0C\u5B57\u5E55\u4F1A\u7ACB\u5373\u8FDB\u5165\u8FD0\u884C\u65F6\u5339\u914D\u6D41\u7A0B\u3002",
    targetSelector: "#drop-zone",
    spotlightPadding: 14
  },
  {
    title: "\u624B\u52A8\u5BFC\u5165\u672C\u5730\u89C6\u9891",
    description: "\u9664\u4E86\u62D6\u62FD\uFF0C\u4E5F\u53EF\u4EE5\u4ECE\u8FD9\u91CC\u9009\u62E9\u672C\u5730\u89C6\u9891\u6587\u4EF6\u3002\u89C6\u9891\u5BFC\u5165\u540E\uFF0C\u4E0B\u9762\u7684\u517C\u5BB9\u4E0E\u9884\u5904\u7406\u533A\u57DF\u4F1A\u5148\u68C0\u67E5\u771F\u5B9E\u97F3\u89C6\u9891\u6D41\u3002",
    targetSelector: "#video-file-field",
    spotlightPadding: 12
  },
  {
    title: "\u518D\u5BFC\u5165\u5B57\u5E55\u6587\u4EF6",
    description: "\u5B57\u5E55\u652F\u6301 ass\u3001ssa\u3001srt \u548C vtt\u3002\u5BFC\u5165\u540E\uFF0C\u6269\u5C55\u4F1A\u81EA\u52A8\u6293\u5168\u6587\u6587\u7AE0\u5E76\u751F\u6210\u8FD0\u884C\u65F6\u540C\u6B65\u6E05\u5355\u3002",
    targetSelector: "#subtitle-file-field",
    spotlightPadding: 12
  },
  {
    title: "\u5148\u770B\u517C\u5BB9\u4E0E\u9884\u5904\u7406",
    description: "\u8FD9\u91CC\u4F1A\u5224\u65AD\u5F53\u524D\u6587\u4EF6\u80FD\u5426\u76F4\u63A5\u64AD\u3002\u5982\u679C\u6D4F\u89C8\u5668\u5BF9\u89C6\u9891\u6216\u97F3\u8F68\u517C\u5BB9\u6027\u4E0D\u597D\uFF0C\u53EF\u4EE5\u5148\u9884\u5904\u7406\uFF0C\u518D\u5207\u56DE\u64AD\u653E\u5668\u3002",
    targetSelector: "#preprocess-panel",
    spotlightPadding: 14
  },
  {
    title: "\u6700\u540E\u5C31\u5728\u8FD9\u91CC\u64AD\u653E",
    description: "\u64AD\u653E\u5668\u533A\u53EF\u4EE5\u76F4\u63A5\u8C03\u8FDB\u5EA6\u3001\u6539\u500D\u901F\u548C\u5207\u753B\u4E2D\u753B\u3002\u5B8C\u6210\u524D\u9762\u51E0\u6B65\u540E\uFF0C\u9605\u8BFB\u9875\u548C\u89C6\u9891\u5C31\u4F1A\u5F00\u59CB\u53CC\u5411\u540C\u6B65\u3002",
    targetSelector: "#player-panel",
    spotlightPadding: 14
  }
];
function requireElement(selector) {
  const element = document.querySelector(selector);
  if (!element) {
    throw new Error(`Missing required element: ${selector}`);
  }
  return element;
}
function queryOptionalElement(selector) {
  return document.querySelector(selector);
}
function isEventFromVideoElement(event) {
  if (event.target === elements.video || document.activeElement === elements.video) {
    return true;
  }
  return event.composedPath().includes(elements.video);
}
var elements = {
  video: requireElement("#video"),
  videoFile: requireElement("#video-file"),
  subtitleFile: requireElement("#subtitle-file"),
  videoFileStatus: requireElement("#video-file-status"),
  subtitleFileStatus: requireElement("#subtitle-file-status"),
  manifestFile: queryOptionalElement("#manifest-file"),
  manifestBaseUrl: queryOptionalElement("#manifest-base-url"),
  remoteSlug: queryOptionalElement("#remote-slug"),
  fetchRemoteManifestButton: queryOptionalElement("#fetch-remote-manifest"),
  refreshRemoteIndexButton: queryOptionalElement("#refresh-remote-index"),
  remoteManifestCandidate: queryOptionalElement("#remote-manifest-candidate"),
  loadRemoteCandidateButton: queryOptionalElement("#load-remote-candidate"),
  remoteIndexStatus: queryOptionalElement("#remote-index-status"),
  requestPageContextButton: requireElement("#request-page-context"),
  refreshConnectedTabsButton: requireElement("#refresh-connected-tabs"),
  pageTabSelect: requireElement("#page-tab-select"),
  bindSelectedPageButton: requireElement("#bind-selected-page"),
  connectedTabsStatus: requireElement("#connected-tabs-status"),
  exportPageContextButton: requireElement("#export-page-context"),
  openTutorialButton: requireElement("#open-tutorial"),
  pipToggle: requireElement("#pip-toggle"),
  pipTogglePlayer: requireElement("#pip-toggle-player"),
  playToggle: requireElement("#play-toggle"),
  seekRange: requireElement("#seek-range"),
  playbackRate: requireElement("#playback-rate"),
  shortcutTogglePlay: requireElement("#shortcut-toggle-play"),
  shortcutSeekBackward: requireElement("#shortcut-seek-backward"),
  shortcutSeekForward: requireElement("#shortcut-seek-forward"),
  shortcutRateDown: requireElement("#shortcut-rate-down"),
  shortcutRateUp: requireElement("#shortcut-rate-up"),
  shortcutSeekSeconds: requireElement("#shortcut-seek-seconds"),
  saveShortcuts: requireElement("#save-shortcuts"),
  currentTime: requireElement("#current-time"),
  durationTime: requireElement("#duration-time"),
  videoName: requireElement("#video-name"),
  subtitleName: requireElement("#subtitle-name"),
  videoCompatibilityStatus: requireElement("#video-compatibility-status"),
  videoCompatibilitySummary: requireElement("#video-compatibility-summary"),
  videoProbeDetail: requireElement("#video-probe-detail"),
  videoTranscodePlan: requireElement("#video-transcode-plan"),
  videoProcessingStatus: requireElement("#video-processing-status"),
  videoProcessingProgressBar: requireElement("#video-processing-progress-bar"),
  videoProcessingProgress: requireElement("#video-processing-progress"),
  videoProcessingNote: requireElement("#video-processing-note"),
  playOriginalVideo: requireElement("#play-original-video"),
  preprocessVideo: requireElement("#preprocess-video"),
  playProcessedVideo: requireElement("#play-processed-video"),
  downloadProcessedVideo: requireElement("#download-processed-video"),
  subtitleStatus: requireElement("#subtitle-status"),
  matchingProgressBar: requireElement("#matching-progress-bar"),
  matchingProgress: requireElement("#matching-progress"),
  manifestName: requireElement("#manifest-name"),
  playbackState: requireElement("#playback-state"),
  syncCoverage: requireElement("#sync-coverage"),
  manifestSource: requireElement("#manifest-source"),
  activeParagraph: requireElement("#active-paragraph"),
  bindingStatus: requireElement("#binding-status"),
  pageMatchStatus: requireElement("#page-match-status"),
  pageTitle: requireElement("#page-title"),
  pageUrlDisplay: requireElement("#page-url-display"),
  pageParagraphCount: requireElement("#page-paragraph-count"),
  currentTranscriptPreview: requireElement("#current-transcript-preview"),
  currentArticlePreview: requireElement("#current-article-preview"),
  currentSyncRange: requireElement("#current-sync-range"),
  currentSyncScore: requireElement("#current-sync-score"),
  currentSyncSegments: requireElement("#current-sync-segments"),
  currentSyncNote: requireElement("#current-sync-note"),
  syncNearbyList: requireElement("#sync-nearby-list"),
  dropZone: requireElement("#drop-zone"),
  statusText: requireElement("#status-text"),
  logOutput: requireElement("#log-output"),
  tutorialOverlay: requireElement("#tutorial-overlay"),
  tutorialSpotlight: requireElement("#tutorial-spotlight"),
  tutorialCard: requireElement("#tutorial-card"),
  tutorialStepCounter: requireElement("#tutorial-step-counter"),
  tutorialTitle: requireElement("#tutorial-title"),
  tutorialDescription: requireElement("#tutorial-description"),
  tutorialClose: requireElement("#tutorial-close"),
  tutorialNext: requireElement("#tutorial-next")
};
elements.video.controls = true;
var browserFfmpegService = new BrowserFfmpegService();
var manifest = null;
var pageContext = null;
var articleSnapshot = null;
var articleSnapshotError = null;
var activePageTabId = null;
var boundPageTabId = null;
var connectedTabs = [];
var remoteManifestCandidates = [];
var manifestObjectUrl = null;
var videoObjectUrl = null;
var sourceVideoFile = null;
var sourceVideoProbe = null;
var sourceVideoAssessment = null;
var sourceVideoStrategy = null;
var sourceVideoInspectionError = null;
var processedVideoFile = null;
var processedVideoObjectUrl = null;
var currentVideoVariant = null;
var videoInspectionBusy = false;
var videoTranscodeBusy = false;
var videoInspectionToken = 0;
var remoteIndexSourceUrl = null;
var lastBroadcastAt = 0;
var transcriptSegmentsByIndex = /* @__PURE__ */ new Map();
var articleParagraphsByIndex = /* @__PURE__ */ new Map();
var playbackRateSteps = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
var loadedSubtitleDocument = null;
var currentRuntimeBuild = null;
var manifestOriginKind = "none";
var subtitleAutoBuildEnabled = false;
var shortcutSettings = { ...defaultShortcutSettings };
var runtimeBuildInFlight = false;
var runtimeBuildFingerprint = null;
var runtimeBuildRequestedFingerprint = null;
var runtimeBuildFailedFingerprint = null;
var runtimeBuildToken = 0;
var playerPort = null;
var playerPortReconnectTimer = null;
var playerPageUnloading = false;
var pageContextTabResolutionInFlight = null;
var pageContextTabResolutionKey = null;
var tutorialState = { ...defaultTutorialState };
var tutorialActive = false;
var tutorialStepIndex = 0;
var tutorialActiveTarget = null;
var tutorialPositionTimer = null;
function clearPlayerPortReconnectTimer() {
  if (playerPortReconnectTimer !== null) {
    window.clearTimeout(playerPortReconnectTimer);
    playerPortReconnectTimer = null;
  }
}
function schedulePlayerPortReconnect(delayMs = 280) {
  if (playerPortReconnectTimer !== null) {
    return;
  }
  playerPortReconnectTimer = window.setTimeout(() => {
    playerPortReconnectTimer = null;
    connectPlayerPort();
  }, delayMs);
}
function handlePlayerPortDisconnect(disconnectedPort) {
  if (playerPort !== disconnectedPort) {
    return;
  }
  playerPort = null;
  if (playerPageUnloading) {
    return;
  }
  appendLog("\u64AD\u653E\u5668\u540E\u53F0\u8FDE\u63A5\u5DF2\u65AD\u5F00\uFF0C\u51C6\u5907\u81EA\u52A8\u91CD\u8FDE");
  schedulePlayerPortReconnect();
}
function connectPlayerPort() {
  if (playerPort) {
    return playerPort;
  }
  clearPlayerPortReconnectTimer();
  const nextPort = chrome.runtime.connect({ name: PLAYER_PORT_NAME });
  playerPort = nextPort;
  nextPort.onMessage.addListener(handleRuntimeMessage);
  nextPort.onDisconnect.addListener(() => {
    handlePlayerPortDisconnect(nextPort);
  });
  return nextPort;
}
function postRuntimeMessage(message, options) {
  const retry = options?.retry !== false;
  const targetPort = connectPlayerPort();
  try {
    targetPort.postMessage(message);
    return true;
  } catch (error) {
    logger.warn("Player port postMessage failed", { type: message.type, error });
    if (playerPort === targetPort) {
      playerPort = null;
    }
    schedulePlayerPortReconnect();
    if (!retry) {
      return false;
    }
    try {
      const retriedPort = connectPlayerPort();
      retriedPort.postMessage(message);
      return true;
    } catch (retryError) {
      logger.warn("Player port retry postMessage failed", { type: message.type, error: retryError });
      if (playerPort === targetPort) {
        playerPort = null;
      }
      schedulePlayerPortReconnect(420);
      return false;
    }
  }
}
function setStatus(message) {
  elements.statusText.textContent = message;
}
function setMatchingProgress(message, percent) {
  if (typeof percent === "number" && Number.isFinite(percent)) {
    elements.matchingProgressBar.value = Math.min(100, Math.max(0, Math.round(percent * 100)));
  }
  elements.matchingProgress.textContent = message;
}
function appendLog(message, metadata) {
  logger.info(message, metadata);
  const renderedMetadata = metadata === void 0 ? "" : ` ${JSON.stringify(metadata, null, 2)}`;
  const timestamp = (/* @__PURE__ */ new Date()).toLocaleTimeString("zh-CN", { hour12: false });
  elements.logOutput.textContent = `[${timestamp}] ${message}${renderedMetadata}
${elements.logOutput.textContent}`;
}
function setVideoProcessingProgress(message, percent) {
  if (typeof percent === "number" && Number.isFinite(percent)) {
    const normalized = Math.min(100, Math.max(0, Math.round(percent * 100)));
    elements.videoProcessingProgressBar.value = normalized;
    elements.videoProcessingProgress.textContent = `${normalized}%`;
  } else {
    elements.videoProcessingProgressBar.value = 0;
    elements.videoProcessingProgress.textContent = "0%";
  }
  elements.videoProcessingNote.textContent = message;
}
function updateVideoFileSelectionStatus(message) {
  elements.videoFileStatus.textContent = message ?? (sourceVideoFile ? `\u5DF2\u8F7D\u5165\uFF1A${sourceVideoFile.name}` : "\u672A\u9009\u62E9\u4EFB\u4F55\u6587\u4EF6");
}
function updateSubtitleFileSelectionStatus(message) {
  elements.subtitleFileStatus.textContent = message ?? (loadedSubtitleDocument ? `\u5DF2\u8F7D\u5165\uFF1A${loadedSubtitleDocument.fileName}` : "\u672A\u9009\u62E9\u4EFB\u4F55\u6587\u4EF6");
}
function updateVideoDecisionControls() {
  const hasSourceVideo = sourceVideoFile !== null;
  const hasProcessedVideo = processedVideoFile !== null;
  const canDirectPlay = hasSourceVideo && !videoInspectionBusy && !videoTranscodeBusy;
  const canPreprocess = hasSourceVideo && sourceVideoProbe !== null && sourceVideoAssessment !== null && !sourceVideoAssessment.isRecommendedProfile && !videoInspectionBusy && !videoTranscodeBusy;
  elements.playOriginalVideo.disabled = !canDirectPlay;
  elements.preprocessVideo.disabled = !canPreprocess;
  elements.playProcessedVideo.disabled = !hasProcessedVideo || videoInspectionBusy || videoTranscodeBusy;
  elements.downloadProcessedVideo.disabled = !hasProcessedVideo || videoInspectionBusy || videoTranscodeBusy;
}
function describeVideoProbe(fileName, probe) {
  const videoStream = probe.streams.find((stream) => stream.codecType === "video");
  const audioStreams = probe.streams.filter((stream) => stream.codecType === "audio");
  const videoDescription = videoStream ? `${videoStream.codecName}${videoStream.width && videoStream.height ? ` ${videoStream.width}x${videoStream.height}` : ""}` : "none";
  return `\u5C01\u88C5 ${formatContainerFormats(resolveContainerFormatsForDisplay(fileName, probe.containerFormats))}\uFF0C\u89C6\u9891 ${videoDescription}\uFF0C\u97F3\u9891 ${formatAudioCodecs(
    audioStreams.map((stream) => stream.codecName)
  )}`;
}
function describeTranscodePlan(strategy) {
  const containerStep = strategy.containerAction === "copy" ? "\u5C01\u88C5\u65E0\u9700\u91CD\u505A" : "\u91CD\u5C01\u88C5\u5230 MP4";
  const videoStep = strategy.videoAction === "copy" ? `\u89C6\u9891\u590D\u7528 ${strategy.videoCodec}` : "\u89C6\u9891\u8F6C HEVC(HVC1)";
  const audioStep = strategy.audioAction === "copy" ? `\u97F3\u9891\u590D\u7528 ${formatAudioCodecs(strategy.audioCodecs)}` : `\u97F3\u9891\u8F6C AAC\uFF08\u5F53\u524D ${formatAudioCodecs(strategy.audioCodecs)}\uFF09`;
  return `${containerStep}\uFF1B${videoStep}\uFF1B${audioStep}`;
}
function revokeProcessedVideoArtifact() {
  if (processedVideoObjectUrl) {
    URL.revokeObjectURL(processedVideoObjectUrl);
    processedVideoObjectUrl = null;
  }
  processedVideoFile = null;
}
function resetVideoDecisionState(fileName) {
  if (videoObjectUrl) {
    URL.revokeObjectURL(videoObjectUrl);
    videoObjectUrl = null;
  }
  elements.video.pause();
  elements.video.removeAttribute("src");
  elements.video.load();
  updateTransportTime();
  updatePlayToggle();
  updatePictureInPictureButton();
  broadcastPlayerState(true);
  sourceVideoProbe = null;
  sourceVideoAssessment = null;
  sourceVideoStrategy = null;
  sourceVideoInspectionError = null;
  currentVideoVariant = null;
  revokeProcessedVideoArtifact();
  elements.videoName.textContent = fileName ?? "\u672A\u52A0\u8F7D";
  updateVideoFileSelectionStatus(fileName ? `\u5DF2\u8F7D\u5165\uFF1A${fileName}` : void 0);
  elements.videoCompatibilityStatus.textContent = fileName ? "\u6B63\u5728\u68C0\u6D4B\u771F\u5B9E\u6D41\u4FE1\u606F" : "\u7B49\u5F85\u89C6\u9891\u8F93\u5165";
  elements.videoCompatibilitySummary.textContent = fileName ? "\u6B63\u5728\u88C5\u8F7D\u5185\u7F6E FFmpeg Core \u5E76\u63A2\u6D4B\u5BB9\u5668\u3001\u89C6\u9891\u6D41\u548C\u97F3\u9891\u6D41\u3002" : "\u68C0\u6D4B\u57FA\u4E8E\u771F\u5B9E\u5BB9\u5668\u3001\u89C6\u9891\u6D41\u548C\u97F3\u9891\u6D41\uFF0C\u4E0D\u4F9D\u8D56\u6587\u4EF6\u540D\u6216\u6269\u5C55\u540D\u731C\u6D4B\u3002";
  elements.videoProbeDetail.textContent = "-";
  elements.videoTranscodePlan.textContent = "\u5C1A\u672A\u751F\u6210\u9884\u5904\u7406\u8BA1\u5212\u3002";
  elements.videoProcessingStatus.textContent = "\u5F85\u547D";
  setVideoProcessingProgress("\u5982\u679C\u6587\u4EF6\u504F\u79BB\u63A8\u8350\u7684 HVC1 + AAC \u57FA\u7EBF\uFF0C\u53EF\u4EE5\u76F4\u63A5\u8BD5\u64AD\uFF0C\u4E5F\u53EF\u4EE5\u4E00\u952E\u9884\u5904\u7406\u540E\u64AD\u653E\u3002");
  updateVideoDecisionControls();
}
function applyProbeOutcome(file, probe, assessment, strategy) {
  sourceVideoFile = file;
  sourceVideoProbe = probe;
  sourceVideoAssessment = assessment;
  sourceVideoStrategy = strategy;
  sourceVideoInspectionError = null;
  updateVideoFileSelectionStatus(`\u5DF2\u8F7D\u5165\uFF1A${file.name}`);
  elements.videoCompatibilityStatus.textContent = assessment.isRecommendedProfile ? "\u63A8\u8350\u57FA\u7EBF\u547D\u4E2D" : "\u68C0\u6D4B\u5230\u517C\u5BB9\u98CE\u9669";
  elements.videoCompatibilitySummary.textContent = assessment.summary;
  elements.videoProbeDetail.textContent = describeVideoProbe(file.name, probe);
  elements.videoTranscodePlan.textContent = describeTranscodePlan(strategy);
  elements.videoProcessingStatus.textContent = assessment.isRecommendedProfile ? "\u65E0\u9700\u9884\u5904\u7406" : "\u53EF\u76F4\u63A5\u8BD5\u64AD\u6216\u4E00\u952E\u9884\u5904\u7406";
  setVideoProcessingProgress(
    assessment.isRecommendedProfile ? "\u5F53\u524D\u6587\u4EF6\u5DF2\u843D\u5728\u63A8\u8350\u64AD\u653E\u57FA\u7EBF\uFF0C\u5C06\u76F4\u63A5\u8FDB\u5165\u539F\u751F\u64AD\u653E\u5668\u3002" : "\u5F53\u524D\u6587\u4EF6\u504F\u79BB\u63A8\u8350\u64AD\u653E\u57FA\u7EBF\u3002\u53EF\u4EE5\u65E0\u89C6\u98CE\u9669\u76F4\u63A5\u64AD\u653E\uFF0C\u4E5F\u53EF\u4EE5\u4E00\u952E\u9884\u5904\u7406\u540E\u518D\u64AD\u653E\u3002"
  );
  updateVideoDecisionControls();
}
function applyProbeFailure(file, message) {
  sourceVideoFile = file;
  sourceVideoProbe = null;
  sourceVideoAssessment = null;
  sourceVideoStrategy = null;
  sourceVideoInspectionError = message;
  elements.videoCompatibilityStatus.textContent = "\u68C0\u6D4B\u5931\u8D25";
  elements.videoCompatibilitySummary.textContent = "\u771F\u5B9E\u6D41\u63A2\u6D4B\u5931\u8D25\uFF0C\u4F46\u4F60\u4ECD\u7136\u53EF\u4EE5\u65E0\u89C6\u98CE\u9669\u76F4\u63A5\u64AD\u653E\u539F\u6587\u4EF6\u3002";
  elements.videoProbeDetail.textContent = "-";
  elements.videoTranscodePlan.textContent = "\u56E0\u4E3A\u672A\u62FF\u5230\u771F\u5B9E\u6D41\u4FE1\u606F\uFF0C\u6682\u65F6\u65E0\u6CD5\u7ED9\u51FA\u9884\u5904\u7406\u8BA1\u5212\u3002";
  elements.videoProcessingStatus.textContent = "\u53EF\u5C1D\u8BD5\u76F4\u63A5\u64AD\u653E";
  setVideoProcessingProgress(message);
  updateVideoFileSelectionStatus(`\u5DF2\u8F7D\u5165\uFF1A${file.name}\uFF08\u63A2\u6D4B\u5931\u8D25\uFF0C\u53EF\u76F4\u63A5\u8BD5\u64AD\uFF09`);
  updateVideoDecisionControls();
}
function formatMs(milliseconds) {
  const totalSeconds = Math.floor(milliseconds / 1e3);
  const remainingMs = milliseconds % 1e3;
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}.${String(remainingMs).padStart(3, "0")}`;
}
function formatAlignmentScore(score) {
  return `${Math.round(score * 100)}%`;
}
function formatRatio(value) {
  return `${Math.round(value * 100)}%`;
}
function playbackStateLabel(state) {
  switch (state) {
    case "playing":
      return "\u64AD\u653E\u4E2D";
    case "paused":
      return "\u5DF2\u6682\u505C";
    case "loading":
      return "\u8F7D\u5165\u4E2D";
    case "ended":
      return "\u5DF2\u7ED3\u675F";
    case "error":
      return "\u5F02\u5E38";
    default:
      return "\u5F85\u673A";
  }
}
function createExcerpt(text, maxLength = 140) {
  const normalized = text.replace(/\s+/g, " ").trim();
  if (!normalized) {
    return "";
  }
  if (normalized.length <= maxLength) {
    return normalized;
  }
  return `${normalized.slice(0, Math.max(0, maxLength - 1)).trimEnd()}\u2026`;
}
function fileExtension(fileName) {
  return fileName.split(".").pop()?.trim().toLowerCase() ?? "";
}
function isEditableTarget(target) {
  if (!(target instanceof HTMLElement)) {
    return false;
  }
  const editable = target.closest("textarea, input, [contenteditable='true']");
  if (!editable) {
    return false;
  }
  if (editable instanceof HTMLTextAreaElement) {
    return !editable.readOnly && !editable.disabled;
  }
  if (editable instanceof HTMLInputElement) {
    const editableInputTypes = /* @__PURE__ */ new Set([
      "text",
      "search",
      "url",
      "tel",
      "email",
      "password",
      "number"
    ]);
    return !editable.readOnly && !editable.disabled && editableInputTypes.has((editable.type || "text").toLowerCase());
  }
  return editable.isContentEditable;
}
function normalizeKeyboardKey(value) {
  return value.trim().toLowerCase();
}
function matchesKeyboardShortcut(event, code, keys) {
  if (event.code === code) {
    return true;
  }
  const normalizedEventKey = normalizeKeyboardKey(event.key);
  return keys.some((key) => normalizeKeyboardKey(key) === normalizedEventKey);
}
function matchesConfiguredShortcut(event, configuredValue) {
  const normalizedConfiguredValue = configuredValue.trim();
  if (!normalizedConfiguredValue) {
    return false;
  }
  if (event.code === normalizedConfiguredValue) {
    return true;
  }
  const normalizedEventKey = normalizeKeyboardKey(event.key);
  if (normalizeKeyboardKey(normalizedConfiguredValue) === normalizedEventKey) {
    return true;
  }
  if (normalizedConfiguredValue.toLowerCase().startsWith("key") && normalizedConfiguredValue.length === 4) {
    return normalizedEventKey === normalizedConfiguredValue.slice(3).toLowerCase();
  }
  return false;
}
function sanitizeShortcutSettings(rawValue) {
  if (!isObject(rawValue)) {
    return { ...defaultShortcutSettings };
  }
  const seekSeconds = Number.parseInt(String(rawValue.seekSeconds ?? defaultShortcutSettings.seekSeconds), 10);
  return {
    togglePlayback: String(rawValue.togglePlayback ?? defaultShortcutSettings.togglePlayback).trim() || defaultShortcutSettings.togglePlayback,
    seekBackward: String(rawValue.seekBackward ?? defaultShortcutSettings.seekBackward).trim() || defaultShortcutSettings.seekBackward,
    seekForward: String(rawValue.seekForward ?? defaultShortcutSettings.seekForward).trim() || defaultShortcutSettings.seekForward,
    rateDown: String(rawValue.rateDown ?? defaultShortcutSettings.rateDown).trim() || defaultShortcutSettings.rateDown,
    rateUp: String(rawValue.rateUp ?? defaultShortcutSettings.rateUp).trim() || defaultShortcutSettings.rateUp,
    seekSeconds: Number.isFinite(seekSeconds) ? clamp(seekSeconds, 1, 60) : defaultShortcutSettings.seekSeconds
  };
}
function applyShortcutSettingsToInputs(settings) {
  elements.shortcutTogglePlay.value = settings.togglePlayback;
  elements.shortcutSeekBackward.value = settings.seekBackward;
  elements.shortcutSeekForward.value = settings.seekForward;
  elements.shortcutRateDown.value = settings.rateDown;
  elements.shortcutRateUp.value = settings.rateUp;
  elements.shortcutSeekSeconds.value = String(settings.seekSeconds);
}
function readShortcutSettingsFromInputs() {
  return sanitizeShortcutSettings({
    togglePlayback: elements.shortcutTogglePlay.value,
    seekBackward: elements.shortcutSeekBackward.value,
    seekForward: elements.shortcutSeekForward.value,
    rateDown: elements.shortcutRateDown.value,
    rateUp: elements.shortcutRateUp.value,
    seekSeconds: elements.shortcutSeekSeconds.value
  });
}
async function persistShortcutSettings(settings) {
  shortcutSettings = settings;
  applyShortcutSettingsToInputs(settings);
  await chrome.storage.local.set({
    [shortcutStorageKey]: settings
  });
}
async function loadShortcutSettings() {
  const stored = await chrome.storage.local.get(shortcutStorageKey);
  shortcutSettings = sanitizeShortcutSettings(stored[shortcutStorageKey]);
  applyShortcutSettingsToInputs(shortcutSettings);
}
function sanitizeTutorialState(rawValue) {
  if (!isObject(rawValue)) {
    return { ...defaultTutorialState };
  }
  return {
    completedVersion: typeof rawValue.completedVersion === "string" ? rawValue.completedVersion : null,
    dismissedVersion: typeof rawValue.dismissedVersion === "string" ? rawValue.dismissedVersion : null
  };
}
async function loadTutorialState() {
  const stored = await chrome.storage.local.get(tutorialStorageKey);
  tutorialState = sanitizeTutorialState(stored[tutorialStorageKey]);
}
async function persistTutorialState(nextState) {
  tutorialState = nextState;
  await chrome.storage.local.set({
    [tutorialStorageKey]: tutorialState
  });
}
function shouldAutoOpenTutorial() {
  return tutorialState.completedVersion !== tutorialVersion && tutorialState.dismissedVersion !== tutorialVersion;
}
function clearTutorialPositionTimer() {
  if (tutorialPositionTimer !== null) {
    window.clearTimeout(tutorialPositionTimer);
    tutorialPositionTimer = null;
  }
}
function clearTutorialTargetHighlight() {
  if (!tutorialActiveTarget) {
    return;
  }
  tutorialActiveTarget.removeAttribute("data-tutorial-active");
  tutorialActiveTarget = null;
}
function resolveTutorialTarget(step) {
  return document.querySelector(step.targetSelector);
}
function highlightTutorialTarget(target) {
  if (tutorialActiveTarget === target) {
    return;
  }
  clearTutorialTargetHighlight();
  if (!target) {
    return;
  }
  target.setAttribute("data-tutorial-active", "true");
  tutorialActiveTarget = target;
}
function queueTutorialPositionUpdate(delayMs = 0) {
  clearTutorialPositionTimer();
  tutorialPositionTimer = window.setTimeout(() => {
    tutorialPositionTimer = null;
    positionTutorialOverlay();
  }, delayMs);
}
function positionTutorialOverlay() {
  if (!tutorialActive) {
    return;
  }
  const step = tutorialSteps[tutorialStepIndex];
  const target = resolveTutorialTarget(step);
  if (!target) {
    return;
  }
  const rect = target.getBoundingClientRect();
  const spotlightPadding = step.spotlightPadding ?? 12;
  const spotlightLeft = clamp(rect.left - spotlightPadding, 8, Math.max(8, window.innerWidth - 24));
  const spotlightTop = clamp(rect.top - spotlightPadding, 8, Math.max(8, window.innerHeight - 24));
  const spotlightWidth = Math.min(rect.width + spotlightPadding * 2, window.innerWidth - spotlightLeft - 8);
  const spotlightHeight = Math.min(rect.height + spotlightPadding * 2, window.innerHeight - spotlightTop - 8);
  Object.assign(elements.tutorialSpotlight.style, {
    left: `${spotlightLeft}px`,
    top: `${spotlightTop}px`,
    width: `${Math.max(spotlightWidth, 120)}px`,
    height: `${Math.max(spotlightHeight, 76)}px`
  });
  const cardRect = elements.tutorialCard.getBoundingClientRect();
  const viewportPadding = 16;
  const cardWidth = cardRect.width || Math.min(360, window.innerWidth - viewportPadding * 2);
  const cardHeight = cardRect.height || 220;
  const spaceBelow = window.innerHeight - rect.bottom;
  const cardTop = spaceBelow >= cardHeight + 28 ? rect.bottom + 18 : Math.max(viewportPadding, rect.top - cardHeight - 18);
  const cardLeft = clamp(rect.left, viewportPadding, Math.max(viewportPadding, window.innerWidth - cardWidth - viewportPadding));
  Object.assign(elements.tutorialCard.style, {
    left: `${cardLeft}px`,
    top: `${cardTop}px`
  });
}
function renderTutorialStep(options) {
  if (!tutorialActive) {
    return;
  }
  const step = tutorialSteps[tutorialStepIndex];
  const target = resolveTutorialTarget(step);
  highlightTutorialTarget(target);
  elements.tutorialStepCounter.textContent = `${tutorialStepIndex + 1} / ${tutorialSteps.length}`;
  elements.tutorialTitle.textContent = step.title;
  elements.tutorialDescription.textContent = step.description;
  elements.tutorialNext.textContent = tutorialStepIndex === tutorialSteps.length - 1 ? "\u5B8C\u6210" : "\u4E0B\u4E00\u6B65";
  if (target && options?.scroll !== false) {
    target.scrollIntoView({
      behavior: "smooth",
      block: "center",
      inline: "nearest"
    });
  }
  positionTutorialOverlay();
  if (target && options?.scroll !== false) {
    queueTutorialPositionUpdate(260);
  }
}
function hideTutorialOverlay() {
  tutorialActive = false;
  clearTutorialPositionTimer();
  clearTutorialTargetHighlight();
  elements.tutorialOverlay.hidden = true;
  elements.tutorialOverlay.setAttribute("aria-hidden", "true");
  document.body.classList.remove("tutorial-open");
}
async function dismissTutorial() {
  const nextState = tutorialState.completedVersion === tutorialVersion ? tutorialState : {
    ...tutorialState,
    dismissedVersion: tutorialVersion
  };
  await persistTutorialState(nextState);
  hideTutorialOverlay();
}
async function completeTutorial() {
  await persistTutorialState({
    completedVersion: tutorialVersion,
    dismissedVersion: null
  });
  hideTutorialOverlay();
}
function openTutorial(options) {
  tutorialStepIndex = clamp(options?.startIndex ?? 0, 0, tutorialSteps.length - 1);
  tutorialActive = true;
  elements.tutorialOverlay.hidden = false;
  elements.tutorialOverlay.setAttribute("aria-hidden", "false");
  document.body.classList.add("tutorial-open");
  renderTutorialStep({ scroll: options?.scroll !== false });
}
function advanceTutorial() {
  if (tutorialStepIndex >= tutorialSteps.length - 1) {
    void completeTutorial();
    return;
  }
  tutorialStepIndex += 1;
  renderTutorialStep({ scroll: true });
}
function currentPlaybackState() {
  if (elements.video.error) {
    return "error";
  }
  if (!elements.video.currentSrc) {
    return "idle";
  }
  if (elements.video.ended) {
    return "ended";
  }
  if (elements.video.seeking) {
    return "loading";
  }
  if (!elements.video.paused && elements.video.readyState < HTMLMediaElement.HAVE_FUTURE_DATA) {
    return "loading";
  }
  return elements.video.paused ? "paused" : "playing";
}
function currentPlaybackTimeMs() {
  return Math.round((elements.video.currentTime ?? 0) * 1e3);
}
function updateTransportTime() {
  const currentMs = currentPlaybackTimeMs();
  const durationMs = Number.isFinite(elements.video.duration) ? Math.round(elements.video.duration * 1e3) : 0;
  elements.currentTime.textContent = formatMs(currentMs);
  elements.durationTime.textContent = formatMs(durationMs);
  elements.seekRange.value = durationMs > 0 ? String(Math.round(currentMs / durationMs * 1e3)) : "0";
}
function updatePlayToggle() {
  elements.playToggle.textContent = elements.video.paused ? "\u64AD\u653E" : "\u6682\u505C";
}
function updatePictureInPictureButton() {
  const pictureInPictureButtons = [elements.pipToggle, elements.pipTogglePlayer];
  if (!document.pictureInPictureEnabled) {
    for (const button of pictureInPictureButtons) {
      button.disabled = true;
      button.textContent = "\u753B\u4E2D\u753B\u4E0D\u53EF\u7528";
    }
    return;
  }
  const activePiP = document.pictureInPictureElement === elements.video;
  for (const button of pictureInPictureButtons) {
    button.disabled = false;
    button.textContent = activePiP ? "\u9000\u51FA\u753B\u4E2D\u753B" : "\u753B\u4E2D\u753B";
  }
}
function setPlaybackRate(rate, source) {
  const supportedRate = playbackRateSteps.find((candidate) => candidate === rate) ?? 1;
  elements.video.playbackRate = supportedRate;
  elements.playbackRate.value = String(supportedRate);
  appendLog("\u64AD\u653E\u500D\u901F\u5DF2\u66F4\u65B0", { supportedRate, source });
  broadcastPlayerState(true);
}
function stepPlaybackRate(step, source) {
  const currentRate = Number.parseFloat(elements.playbackRate.value || String(elements.video.playbackRate || 1));
  const matchedIndex = playbackRateSteps.findIndex((candidate) => candidate >= currentRate - 1e-3);
  const currentIndex = matchedIndex === -1 ? playbackRateSteps.length - 1 : matchedIndex;
  const nextIndex = clamp(currentIndex + step, 0, playbackRateSteps.length - 1);
  setPlaybackRate(playbackRateSteps[nextIndex], source);
}
function setRemoteIndexStatus(message) {
  if (elements.remoteIndexStatus) {
    elements.remoteIndexStatus.textContent = message;
  }
}
function setConnectedTabsStatus(message) {
  elements.connectedTabsStatus.textContent = message;
}
function updateRemoteCandidateControlState() {
  if (!elements.remoteManifestCandidate || !elements.loadRemoteCandidateButton) {
    return;
  }
  const hasSelection = Boolean(elements.remoteManifestCandidate.value);
  elements.loadRemoteCandidateButton.disabled = !hasSelection;
}
function updateConnectedTabsControlState() {
  const selectedTabId = Number.parseInt(elements.pageTabSelect.value, 10);
  const hasSelection = Number.isFinite(selectedTabId) && selectedTabId > 0;
  elements.bindSelectedPageButton.disabled = !hasSelection;
}
function createSyntheticConnectedTab(pageContextValue, tabId) {
  return {
    tabId: tabId ?? -1,
    windowId: -1,
    active: true,
    title: pageContextValue.title,
    url: pageContextValue.articleUrl,
    articleId: pageContextValue.articleId,
    categoryId: pageContextValue.categoryId,
    paragraphCount: pageContextValue.paragraphs.length,
    preferred: true,
    capturedAt: pageContextValue.capturedAt
  };
}
function createRecoveredConnectedTab(pageContextValue, tab) {
  if (typeof tab.id !== "number") {
    return null;
  }
  return {
    tabId: tab.id,
    windowId: tab.windowId ?? -1,
    active: Boolean(tab.active),
    title: pageContextValue.title,
    url: pageContextValue.articleUrl,
    articleId: pageContextValue.articleId,
    categoryId: pageContextValue.categoryId,
    paragraphCount: pageContextValue.paragraphs.length,
    preferred: boundPageTabId === tab.id || activePageTabId === tab.id,
    capturedAt: pageContextValue.capturedAt
  };
}
function resolveArticleIdFromUrlString(urlValue) {
  try {
    const match = new URL(urlValue).pathname.match(/\/daily-feed\/(\d+)/);
    if (!match) {
      return null;
    }
    const parsed = Number.parseInt(match[1], 10);
    return Number.isFinite(parsed) ? parsed : null;
  } catch {
    return null;
  }
}
function resolveCategoryIdFromUrlString(urlValue) {
  try {
    const rawValue = new URL(urlValue).searchParams.get("categoryId");
    if (!rawValue) {
      return null;
    }
    const parsed = Number.parseInt(rawValue, 10);
    return Number.isFinite(parsed) ? parsed : null;
  } catch {
    return null;
  }
}
function buildPageContextResolutionKey(pageContextValue) {
  return [
    pageContextValue.articleUrl,
    pageContextValue.articleId ?? "-",
    pageContextValue.categoryId ?? "-"
  ].join("|");
}
function scoreTabAgainstPageContext(tab, pageContextValue) {
  const tabUrl = tab.url ?? "";
  if (!tabUrl.startsWith("https://aim-read.top/")) {
    return -1;
  }
  let score = 0;
  if (tabUrl === pageContextValue.articleUrl) {
    score += 100;
  }
  const tabArticleId = resolveArticleIdFromUrlString(tabUrl);
  const tabCategoryId = resolveCategoryIdFromUrlString(tabUrl);
  if (pageContextValue.articleId !== null && tabArticleId === pageContextValue.articleId) {
    score += 60;
  }
  if (pageContextValue.categoryId !== null && tabCategoryId === pageContextValue.categoryId) {
    score += 25;
  }
  if (tab.active) {
    score += 8;
  }
  return score;
}
async function resolvePageContextTabIdFromBrowser(pageContextValue) {
  const resolutionKey = buildPageContextResolutionKey(pageContextValue);
  if (pageContextTabResolutionInFlight && pageContextTabResolutionKey === resolutionKey) {
    return pageContextTabResolutionInFlight;
  }
  pageContextTabResolutionKey = resolutionKey;
  pageContextTabResolutionInFlight = (async () => {
    try {
      const tabs = await chrome.tabs.query({ url: ["https://aim-read.top/*"] });
      const resolvedTab = tabs.map((tab) => ({ tab, score: scoreTabAgainstPageContext(tab, pageContextValue) })).filter((entry) => entry.score > 0 && typeof entry.tab.id === "number").sort((left, right) => right.score - left.score)[0]?.tab ?? null;
      if (!resolvedTab || typeof resolvedTab.id !== "number") {
        return;
      }
      const resolvedTabId = resolvedTab.id;
      const tabAlreadyKnown = connectedTabs.some((tab) => tab.tabId === resolvedTabId);
      let shouldRender = false;
      if (activePageTabId !== resolvedTabId) {
        activePageTabId = resolvedTabId;
        shouldRender = true;
      }
      if (boundPageTabId === null || boundPageTabId === activePageTabId) {
        if (boundPageTabId !== resolvedTabId) {
          boundPageTabId = resolvedTabId;
          shouldRender = true;
        }
      }
      if (!tabAlreadyKnown) {
        const recoveredTab = createRecoveredConnectedTab(pageContextValue, resolvedTab);
        if (recoveredTab) {
          connectedTabs = sortConnectedTabs([...connectedTabs, recoveredTab]);
          shouldRender = true;
        }
      }
      if (shouldRender) {
        renderConnectedTabs();
        renderCurrentSyncDetails(currentPlaybackTimeMs());
      }
      requestConnectedTabs();
    } catch (error) {
      appendLog("\u6839\u636E\u9875\u9762\u5FEB\u7167\u53CD\u67E5\u771F\u5B9E\u9605\u8BFB\u9875\u5931\u8D25", {
        message: error instanceof Error ? error.message : String(error),
        articleUrl: pageContextValue.articleUrl
      });
    } finally {
      pageContextTabResolutionInFlight = null;
      if (pageContextTabResolutionKey === resolutionKey) {
        pageContextTabResolutionKey = null;
      }
    }
  })();
  return pageContextTabResolutionInFlight;
}
function sortConnectedTabs(tabs) {
  return [...tabs].sort((left, right) => {
    if (left.preferred !== right.preferred) {
      return left.preferred ? -1 : 1;
    }
    if (left.active !== right.active) {
      return left.active ? -1 : 1;
    }
    return left.tabId - right.tabId;
  });
}
function deriveEffectiveConnectedTabs() {
  const tabsById = /* @__PURE__ */ new Map();
  for (const tab of connectedTabs) {
    tabsById.set(tab.tabId, tab);
  }
  if (pageContext) {
    const syntheticTab = createSyntheticConnectedTab(pageContext, activePageTabId ?? boundPageTabId);
    if (syntheticTab.tabId > 0 && tabsById.has(syntheticTab.tabId)) {
      const current = tabsById.get(syntheticTab.tabId);
      if (current) {
        tabsById.set(syntheticTab.tabId, {
          ...current,
          title: syntheticTab.title,
          url: syntheticTab.url,
          articleId: syntheticTab.articleId,
          categoryId: syntheticTab.categoryId,
          paragraphCount: syntheticTab.paragraphCount,
          capturedAt: syntheticTab.capturedAt
        });
      }
    } else {
      tabsById.set(syntheticTab.tabId, syntheticTab);
    }
  }
  return sortConnectedTabs(Array.from(tabsById.values()));
}
function resolveSelectedConnectedTab(tabs) {
  if (tabs.length === 0) {
    return null;
  }
  if (boundPageTabId !== null) {
    const boundTab = tabs.find((tab) => tab.tabId === boundPageTabId);
    if (boundTab) {
      return boundTab;
    }
  }
  if (activePageTabId !== null) {
    const activeTab = tabs.find((tab) => tab.tabId === activePageTabId);
    if (activeTab) {
      return activeTab;
    }
  }
  return tabs.find((tab) => tab.preferred) ?? tabs[0] ?? null;
}
function isConnectedTabBackedByLivePort(tab) {
  return Boolean(tab && tab.tabId > 0 && connectedTabs.some((candidate) => candidate.tabId === tab.tabId));
}
function resolveSelectedConnectedTabLabel(tab) {
  if (!tab) {
    return "\u5F53\u524D\u9875\u9762";
  }
  return tab.tabId > 0 ? `tab#${tab.tabId}` : "\u5F53\u524D\u9875\u9762\u5FEB\u7167";
}
function dedupeStrings(values) {
  return Array.from(new Set(values.map((value) => value.trim()).filter(Boolean)));
}
function formatRemoteCandidateLabel(candidate) {
  const metaParts = [
    candidate.articleId !== null ? `article#${candidate.articleId}` : null,
    candidate.categoryId !== null ? `category#${candidate.categoryId}` : null,
    candidate.tags.length > 0 ? `\u6807\u7B7E ${candidate.tags.slice(0, 2).join("/")}` : null
  ].filter((value) => Boolean(value));
  const description = metaParts.length > 0 ? ` \xB7 ${metaParts.join(" \xB7 ")}` : "";
  return createExcerpt(`${candidate.title} (${candidate.slug})${description}`, 110);
}
function formatRemoteCandidateSummary(candidate) {
  const parts = [
    `${candidate.title} (${candidate.slug})`,
    candidate.articleId !== null ? `article#${candidate.articleId}` : null,
    candidate.categoryId !== null ? `category#${candidate.categoryId}` : null,
    candidate.description || null
  ].filter((value) => Boolean(value));
  return createExcerpt(parts.join(" \xB7 "), 180);
}
function syncRemoteCandidateStatus(selectedUrl) {
  if (remoteManifestCandidates.length === 0) {
    setRemoteIndexStatus("\u8FD8\u6CA1\u6709\u53EF\u7528\u5019\u9009\u3002");
    return;
  }
  const selectedCandidate = remoteManifestCandidates.find((candidate) => candidate.url === (selectedUrl ?? elements.remoteManifestCandidate?.value)) ?? remoteManifestCandidates[0] ?? null;
  if (!selectedCandidate) {
    setRemoteIndexStatus("\u8FD8\u6CA1\u6709\u53EF\u7528\u5019\u9009\u3002");
    return;
  }
  const sourceLabel = remoteIndexSourceUrl ? `\u5DF2\u4ECE ${remoteIndexSourceUrl} \u8F7D\u5165` : "\u5DF2\u8F7D\u5165";
  setRemoteIndexStatus(`${sourceLabel} ${remoteManifestCandidates.length} \u4E2A\u5019\u9009\uFF0C\u5F53\u524D\u4F18\u5148\uFF1A${formatRemoteCandidateSummary(selectedCandidate)}`);
}
function resolvePageBindingUiState() {
  const effectiveTabs = deriveEffectiveConnectedTabs();
  const selectedTab = resolveSelectedConnectedTab(effectiveTabs);
  const selectedTabLabel = resolveSelectedConnectedTabLabel(selectedTab);
  const hasRealTabs = effectiveTabs.some((tab) => tab.tabId > 0);
  const selectedTabBackedByLivePort = isConnectedTabBackedByLivePort(selectedTab);
  const isSnapshotFallback = Boolean(pageContext && !selectedTabBackedByLivePort);
  let connectedTabsStatus = "\u5F53\u524D\u8FD8\u6CA1\u6709\u53EF\u7ED1\u5B9A\u7684\u9875\u9762\u3002";
  if (effectiveTabs.length > 0) {
    if (isSnapshotFallback && !hasRealTabs) {
      connectedTabsStatus = "\u5DF2\u8FDE\u63A5\u5F53\u524D\u9875\u9762\u5FEB\u7167\uFF0C\u7B49\u5F85\u9875\u9762\u5217\u8868\u540C\u6B65\u3002";
    } else if (isSnapshotFallback) {
      connectedTabsStatus = `\u5DF2\u53D1\u73B0 ${effectiveTabs.length} \u4E2A\u9875\u9762\uFF0C\u5F53\u524D\u5148\u8DDF\u968F ${selectedTabLabel} \u7684\u5FEB\u7167\uFF0C\u7B49\u5F85\u9875\u9762\u5217\u8868\u540C\u6B65\u3002`;
    } else if (selectedTab) {
      connectedTabsStatus = `\u5DF2\u53D1\u73B0 ${effectiveTabs.length} \u4E2A\u9875\u9762\uFF0C\u5F53\u524D\u7ED1\u5B9A ${selectedTabLabel}\u3002`;
    } else {
      connectedTabsStatus = `\u5DF2\u53D1\u73B0 ${effectiveTabs.length} \u4E2A\u9875\u9762\uFF0C\u8BF7\u9009\u62E9\u8981\u7ED1\u5B9A\u7684\u76EE\u6807\u3002`;
    }
  }
  if (!pageContext) {
    return {
      effectiveTabs,
      selectedTab,
      connectedTabsStatus,
      bindingStatus: subtitleAutoBuildEnabled ? "\u7B49\u5F85\u76EE\u6807\u9605\u8BFB\u9875\u8FDE\u63A5" : "\u7B49\u5F85\u9875\u9762\u8FDE\u63A5",
      pageMatchStatus: effectiveTabs.length > 0 ? "\u5DF2\u53D1\u73B0\u9875\u9762\uFF0C\u4F46\u5F53\u524D\u5C1A\u672A\u62FF\u5230\u5FEB\u7167" : "\u672A\u83B7\u53D6 aim-read \u9875\u9762\u5FEB\u7167"
    };
  }
  if (!manifest) {
    const waitingLabel = subtitleAutoBuildEnabled ? isSnapshotFallback ? `\u5DF2\u8FDE\u63A5\u9605\u8BFB\u9875\u5FEB\u7167 (${selectedTabLabel})\uFF0C\u7B49\u5F85\u5168\u6587\u6293\u53D6\u5E76\u81EA\u52A8\u5339\u914D` : `\u5DF2\u8FDE\u63A5\u9605\u8BFB\u9875 (${selectedTabLabel})\uFF0C\u7B49\u5F85\u5168\u6587\u6293\u53D6\u5E76\u81EA\u52A8\u5339\u914D` : isSnapshotFallback ? `\u5DF2\u8FDE\u63A5\u9605\u8BFB\u9875\u5FEB\u7167 (${selectedTabLabel})\uFF0C\u7B49\u5F85\u9875\u9762\u5217\u8868\u540C\u6B65\u5E76\u52A0\u8F7D\u6E05\u5355` : `\u5DF2\u8FDE\u63A5\u9605\u8BFB\u9875 (${selectedTabLabel})\uFF0C\u7B49\u5F85\u6E05\u5355`;
    return {
      effectiveTabs,
      selectedTab,
      connectedTabsStatus,
      bindingStatus: waitingLabel,
      pageMatchStatus: `\u5F53\u524D\u9875\u9762 articleId ${pageContext.articleId ?? "-"} \xB7 categoryId ${pageContext.categoryId ?? "-"}`
    };
  }
  const sourceArticleId = manifest.source.articleId ?? null;
  const sourceCategoryId = manifest.source.categoryId ?? null;
  const sameArticle = sourceArticleId !== null && pageContext.articleId === sourceArticleId;
  const sameCategory = sourceCategoryId === null || pageContext.categoryId === sourceCategoryId;
  if (sameArticle && sameCategory) {
    return {
      effectiveTabs,
      selectedTab,
      connectedTabsStatus,
      bindingStatus: isSnapshotFallback ? `\u5DF2\u6309\u9875\u9762\u5FEB\u7167\u7ED1\u5B9A (${selectedTabLabel})\uFF0C\u7B49\u5F85\u9875\u9762\u5217\u8868\u540C\u6B65` : `\u5DF2\u7ED1\u5B9A\u5F53\u524D\u9605\u8BFB\u9875 (${selectedTabLabel})`,
      pageMatchStatus: `articleId ${pageContext.articleId ?? "-"} \xB7 categoryId ${pageContext.categoryId ?? "-"}`
    };
  }
  if (sourceArticleId === null && manifest.source.articleUrl && manifest.source.articleUrl === pageContext.articleUrl) {
    return {
      effectiveTabs,
      selectedTab,
      connectedTabsStatus,
      bindingStatus: isSnapshotFallback ? `\u5DF2\u6309\u9875\u9762\u5FEB\u7167 URL \u7ED1\u5B9A (${selectedTabLabel})\uFF0C\u7B49\u5F85\u9875\u9762\u5217\u8868\u540C\u6B65` : `\u5DF2\u6309 URL \u7ED1\u5B9A\u5F53\u524D\u9875\u9762 (${selectedTabLabel})`,
      pageMatchStatus: "\u6E05\u5355\u672A\u58F0\u660E articleId\uFF0C\u5DF2\u6309 articleUrl \u7CBE\u786E\u5339\u914D"
    };
  }
  return {
    effectiveTabs,
    selectedTab,
    connectedTabsStatus,
    bindingStatus: isSnapshotFallback ? `\u5F53\u524D\u9875\u9762\u5FEB\u7167\u4E0E\u6E05\u5355\u4E0D\u4E00\u81F4 (${selectedTabLabel})\uFF0C\u7B49\u5F85\u9875\u9762\u5217\u8868\u540C\u6B65` : `\u5F53\u524D\u9875\u9762\u4E0E\u6E05\u5355\u4E0D\u4E00\u81F4 (${selectedTabLabel})`,
    pageMatchStatus: `\u6E05\u5355 articleId ${sourceArticleId ?? "-"} / categoryId ${sourceCategoryId ?? "-"}\uFF0C\u5F53\u524D\u4E3A ${pageContext.articleId ?? "-"} / ${pageContext.categoryId ?? "-"}`
  };
}
function applyPageBindingUiState() {
  const uiState = resolvePageBindingUiState();
  setConnectedTabsStatus(uiState.connectedTabsStatus);
  elements.bindingStatus.textContent = uiState.bindingStatus;
  elements.pageMatchStatus.textContent = uiState.pageMatchStatus;
}
function resolveManifestSourceLabel(manifestValue) {
  if (!manifestValue) {
    return "-";
  }
  if (manifestOriginKind === "runtime-subtitle") {
    const parts2 = ["\u5B57\u5E55\u8FD0\u884C\u65F6\u5339\u914D"];
    if (typeof manifestValue.source.articleId === "number") {
      parts2.push(`article#${manifestValue.source.articleId}`);
    }
    return parts2.join(" \xB7 ");
  }
  const parts = [manifestValue.source.slug];
  if (typeof manifestValue.source.articleId === "number") {
    parts.push(`article#${manifestValue.source.articleId}`);
  }
  if (typeof manifestValue.source.categoryId === "number") {
    parts.push(`category#${manifestValue.source.categoryId}`);
  }
  return parts.join(" \xB7 ");
}
function resolveCoverageLabel(manifestValue) {
  if (!manifestValue) {
    return "-";
  }
  const mappedCount = manifestValue.sync.filter((entry) => entry.transcriptSegmentIndexes.length > 0).length;
  const smoothedCount = manifestValue.sync.length - mappedCount;
  const articleParagraphCount = manifestValue.article?.paragraphs.length ?? manifestValue.sync.length;
  return `${mappedCount}/${articleParagraphCount} \u547D\u4E2D\uFF0C${smoothedCount} \u5E73\u6ED1`;
}
function updatePageContext(pageContextValue, tabId) {
  if (pageContextValue && articleSnapshot && (articleSnapshot.articleId !== null && pageContextValue.articleId !== articleSnapshot.articleId || articleSnapshot.articleUrl !== pageContextValue.articleUrl)) {
    articleSnapshot = null;
    articleSnapshotError = null;
  }
  pageContext = pageContextValue;
  if (typeof tabId === "number") {
    activePageTabId = tabId;
    if (boundPageTabId === null) {
      boundPageTabId = tabId;
    }
  } else if (pageContextValue) {
    void resolvePageContextTabIdFromBrowser(pageContextValue);
  } else if (!pageContextValue) {
    activePageTabId = null;
  }
  elements.exportPageContextButton.disabled = !pageContextValue;
  elements.pageTitle.textContent = pageContextValue?.title ?? "\u672A\u68C0\u6D4B";
  elements.pageUrlDisplay.textContent = pageContextValue?.articleUrl ?? "-";
  elements.pageParagraphCount.textContent = String(pageContextValue?.paragraphs.length ?? 0);
  if (pageContextValue) {
    appendLog("\u5DF2\u66F4\u65B0\u5F53\u524D\u9875\u9762\u5FEB\u7167", {
      tabId: activePageTabId,
      articleUrl: pageContextValue.articleUrl,
      paragraphCount: pageContextValue.paragraphs.length
    });
  }
  renderConnectedTabs();
  renderCurrentSyncDetails(currentPlaybackTimeMs());
  if (subtitleAutoBuildEnabled && pageContextValue) {
    maybeRebuildRuntimeSubtitleManifest();
  }
}
function setSubtitleStatus(message) {
  elements.subtitleStatus.textContent = message;
}
function updateArticleSnapshot(snapshot, error, tabId) {
  articleSnapshot = snapshot;
  articleSnapshotError = error;
  if (typeof tabId === "number") {
    activePageTabId = tabId;
    if (boundPageTabId === null) {
      boundPageTabId = tabId;
    }
  } else if (snapshot && pageContext) {
    void resolvePageContextTabIdFromBrowser(pageContext);
  } else if (!snapshot && !pageContext) {
    activePageTabId = null;
  }
  if (snapshot) {
    appendLog("\u5DF2\u66F4\u65B0\u5168\u6587\u6587\u7AE0\u5FEB\u7167", {
      tabId: activePageTabId,
      articleId: snapshot.articleId,
      paragraphCount: snapshot.paragraphs.length,
      totalPages: snapshot.pageInfo?.totalPages ?? null
    });
  } else if (error) {
    appendLog("\u5168\u6587\u6587\u7AE0\u5FEB\u7167\u83B7\u53D6\u5931\u8D25", {
      tabId: activePageTabId,
      message: error
    });
  }
  if (subtitleAutoBuildEnabled) {
    maybeRebuildRuntimeSubtitleManifest();
  }
}
function requestArticleSnapshot() {
  postRuntimeMessage({ type: "REQUEST_ACTIVE_ARTICLE_SNAPSHOT" });
}
function rebuildManifestLookups(manifestValue) {
  transcriptSegmentsByIndex = new Map(
    manifestValue.transcript.segments.map((segment) => [segment.index, segment])
  );
  articleParagraphsByIndex = new Map(
    (manifestValue.article?.paragraphs ?? []).map((paragraph) => [
      paragraph.paragraphIndex,
      paragraph
    ])
  );
}
function resolveArticleParagraph(paragraphIndex) {
  return articleParagraphsByIndex.get(paragraphIndex) ?? pageContext?.paragraphs.find((paragraph) => paragraph.paragraphIndex === paragraphIndex) ?? null;
}
function resolveTranscriptText(syncEntry) {
  return syncEntry.transcriptSegmentIndexes.map((segmentIndex) => transcriptSegmentsByIndex.get(segmentIndex)?.text ?? "").filter(Boolean).join(" ").replace(/\s+/g, " ").trim();
}
function resolveSyncNote(syncEntry, articleParagraph) {
  if (syncEntry.transcriptSegmentIndexes.length === 0) {
    return "\u8FD9\u4E00\u6BB5\u662F\u57FA\u4E8E\u4E0A\u4E0B\u6587\u505A\u7684\u5E73\u6ED1\u8865\u6BB5\uFF0C\u6CA1\u6709\u76F4\u63A5 transcript \u547D\u4E2D\u3002";
  }
  if (articleParagraph?.translation) {
    return `\u8BD1\u6587\uFF1A${articleParagraph.translation}`;
  }
  return `\u547D\u4E2D ${syncEntry.transcriptSegmentIndexes.length} \u4E2A transcript \u7247\u6BB5\u3002`;
}
function syncQualityClass(score) {
  if (score >= 0.85) {
    return "sync-quality-good";
  }
  if (score >= 0.5) {
    return "sync-quality-mid";
  }
  return "sync-quality-low";
}
function updateOverviewFields() {
  elements.playbackState.textContent = playbackStateLabel(currentPlaybackState());
  elements.syncCoverage.textContent = resolveCoverageLabel(manifest);
  elements.manifestSource.textContent = resolveManifestSourceLabel(manifest);
  applyPageBindingUiState();
}
function renderRemoteManifestCandidates(selectedUrl) {
  if (!elements.remoteManifestCandidate) {
    return;
  }
  elements.remoteManifestCandidate.replaceChildren();
  if (remoteManifestCandidates.length === 0) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "\u6CA1\u6709\u53EF\u7528\u5019\u9009";
    elements.remoteManifestCandidate.append(option);
    updateRemoteCandidateControlState();
    return;
  }
  for (const candidate of remoteManifestCandidates) {
    const option = document.createElement("option");
    option.value = candidate.url;
    option.textContent = formatRemoteCandidateLabel(candidate);
    option.title = `${formatRemoteCandidateSummary(candidate)}
${candidate.url}`;
    if (selectedUrl && candidate.url === selectedUrl) {
      option.selected = true;
    }
    elements.remoteManifestCandidate.append(option);
  }
  if (!elements.remoteManifestCandidate.value) {
    elements.remoteManifestCandidate.value = selectedUrl ?? remoteManifestCandidates[0]?.url ?? "";
  }
  syncRemoteCandidateStatus(elements.remoteManifestCandidate.value);
  updateRemoteCandidateControlState();
}
function renderConnectedTabs() {
  const uiState = resolvePageBindingUiState();
  const { effectiveTabs, selectedTab } = uiState;
  elements.pageTabSelect.replaceChildren();
  if (effectiveTabs.length === 0) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "\u7B49\u5F85\u9875\u9762\u8FDE\u63A5";
    elements.pageTabSelect.append(option);
    applyPageBindingUiState();
    updateConnectedTabsControlState();
    return;
  }
  for (const tab of effectiveTabs) {
    const option = document.createElement("option");
    option.value = tab.tabId > 0 ? String(tab.tabId) : "";
    const tag = tab.preferred ? "\u5DF2\u7ED1\u5B9A" : tab.active ? "\u5F53\u524D\u7A97\u53E3\u6D3B\u52A8\u9875" : "\u5019\u9009";
    option.textContent = `${tab.title} \xB7 article ${tab.articleId ?? "-"} \xB7 ${tag}`;
    option.selected = Boolean(selectedTab && selectedTab.tabId === tab.tabId);
    elements.pageTabSelect.append(option);
  }
  if (!elements.pageTabSelect.value) {
    const fallbackTabId = selectedTab?.tabId ?? activePageTabId ?? effectiveTabs[0]?.tabId;
    elements.pageTabSelect.value = fallbackTabId && fallbackTabId > 0 ? String(fallbackTabId) : "";
  }
  applyPageBindingUiState();
  updateConnectedTabsControlState();
}
function updateConnectedTabs(payload) {
  connectedTabs = payload.tabs;
  const nextPreferredTabId = payload.preferredTabId ?? payload.tabs[0]?.tabId ?? null;
  const availableTabIds = new Set(payload.tabs.map((tab) => tab.tabId));
  if (typeof nextPreferredTabId === "number") {
    boundPageTabId = nextPreferredTabId;
  } else if (!pageContext) {
    boundPageTabId = null;
  }
  if (activePageTabId === null) {
    activePageTabId = nextPreferredTabId;
  } else if (!availableTabIds.has(activePageTabId) && !pageContext) {
    activePageTabId = nextPreferredTabId;
  }
  if (boundPageTabId !== null && !availableTabIds.has(boundPageTabId) && !pageContext) {
    boundPageTabId = nextPreferredTabId;
  }
  renderConnectedTabs();
  renderCurrentSyncDetails(currentPlaybackTimeMs());
}
function resolveNearbyCenterIndex(currentTimeMs) {
  if (!manifest || manifest.sync.length === 0) {
    return -1;
  }
  const activeEntry = resolveActiveSyncEntry(manifest, currentTimeMs);
  if (activeEntry) {
    return manifest.sync.findIndex((entry) => entry.paragraphIndex === activeEntry.paragraphIndex);
  }
  let low = 0;
  let high = manifest.sync.length - 1;
  while (low <= high) {
    const middle = Math.floor((low + high) / 2);
    const entry = manifest.sync[middle];
    if (currentTimeMs < entry.startMs) {
      high = middle - 1;
      continue;
    }
    low = middle + 1;
  }
  return clamp(low, 0, manifest.sync.length - 1);
}
function renderNearbySyncEntries(currentTimeMs, activeEntry) {
  elements.syncNearbyList.replaceChildren();
  if (!manifest || manifest.sync.length === 0) {
    const empty = document.createElement("p");
    empty.className = "sync-nearby-excerpt";
    empty.textContent = "\u52A0\u8F7D\u540C\u6B65\u6E05\u5355\u540E\uFF0C\u8FD9\u91CC\u4F1A\u51FA\u73B0\u5F53\u524D\u9644\u8FD1\u7684\u53EF\u8DF3\u8F6C\u6BB5\u843D\u3002";
    elements.syncNearbyList.append(empty);
    return;
  }
  const centerIndex = resolveNearbyCenterIndex(currentTimeMs);
  const startIndex = Math.max(0, centerIndex - 3);
  const endIndex = Math.min(manifest.sync.length, centerIndex + 4);
  const fragment = document.createDocumentFragment();
  for (const entry of manifest.sync.slice(startIndex, endIndex)) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "sync-nearby-item";
    if (activeEntry && activeEntry.paragraphIndex === entry.paragraphIndex) {
      button.classList.add("is-active");
    }
    button.dataset.startMs = String(entry.startMs);
    button.dataset.paragraphIndex = String(entry.paragraphIndex);
    const header = document.createElement("div");
    header.className = "sync-nearby-head";
    const title = document.createElement("span");
    title.className = "sync-nearby-title";
    title.textContent = `\u6BB5\u843D #${entry.paragraphIndex}`;
    const range = document.createElement("span");
    range.className = "sync-nearby-meta";
    range.textContent = `${formatMs(entry.startMs)} - ${formatMs(entry.endMs)}`;
    header.append(title, range);
    const meta = document.createElement("div");
    meta.className = "sync-nearby-meta";
    meta.textContent = entry.transcriptSegmentIndexes.length > 0 ? `Transcript #${entry.transcriptSegmentIndexes.join(", ")}` : "\u5E73\u6ED1\u8865\u6BB5";
    const quality = document.createElement("span");
    quality.className = `sync-nearby-meta ${syncQualityClass(entry.alignmentScore)}`;
    quality.textContent = `\u5BF9\u9F50 ${formatAlignmentScore(entry.alignmentScore)}`;
    meta.append(" \xB7 ", quality);
    const excerpt = document.createElement("p");
    excerpt.className = "sync-nearby-excerpt";
    excerpt.textContent = createExcerpt(
      resolveArticleParagraph(entry.paragraphIndex)?.text || resolveTranscriptText(entry) || "\u6682\u65E0\u6587\u672C\u9884\u89C8",
      160
    );
    button.append(header, meta, excerpt);
    fragment.append(button);
  }
  elements.syncNearbyList.append(fragment);
}
function renderCurrentSyncDetails(currentTimeMs) {
  updateOverviewFields();
  if (!manifest) {
    elements.activeParagraph.textContent = "-";
    elements.currentTranscriptPreview.textContent = "\u7B49\u5F85\u540C\u6B65\u6E05\u5355\u548C\u89C6\u9891\u3002";
    elements.currentArticlePreview.textContent = "\u7B49\u5F85\u5F53\u524D\u9875\u9762\u5FEB\u7167\u3002";
    elements.currentSyncRange.textContent = "-";
    elements.currentSyncScore.textContent = "-";
    elements.currentSyncSegments.textContent = "-";
    elements.currentSyncNote.textContent = "\u5F53\u524D\u65E0\u53EF\u5C55\u793A\u6620\u5C04\u3002\u52A0\u8F7D\u89C6\u9891\u4E0E\u540C\u6B65\u6E05\u5355\u540E\u4F1A\u81EA\u52A8\u66F4\u65B0\u3002";
    renderNearbySyncEntries(currentTimeMs, null);
    return;
  }
  const syncEntry = resolveActiveSyncEntry(manifest, currentTimeMs);
  elements.activeParagraph.textContent = syncEntry ? String(syncEntry.paragraphIndex) : "-";
  if (!syncEntry) {
    elements.currentTranscriptPreview.textContent = "\u5F53\u524D\u65F6\u95F4\u5C1A\u672A\u843D\u5728\u4EFB\u4F55\u6620\u5C04\u533A\u95F4\u5185\u3002";
    elements.currentArticlePreview.textContent = articleFallbackText;
    elements.currentSyncRange.textContent = "-";
    elements.currentSyncScore.textContent = "-";
    elements.currentSyncSegments.textContent = "-";
    elements.currentSyncNote.textContent = "\u4F60\u53EF\u4EE5\u70B9\u51FB\u4E0B\u65B9\u9644\u8FD1\u6BB5\u843D\uFF0C\u6216\u62D6\u52A8\u65F6\u95F4\u8F74\u8FDB\u5165\u5DF2\u6620\u5C04\u533A\u57DF\u3002";
    renderNearbySyncEntries(currentTimeMs, null);
    return;
  }
  const articleParagraph = resolveArticleParagraph(syncEntry.paragraphIndex);
  const transcriptText = resolveTranscriptText(syncEntry);
  elements.currentTranscriptPreview.textContent = transcriptText || transcriptFallbackText;
  elements.currentArticlePreview.textContent = articleParagraph?.translation ? `${articleParagraph.text}

${articleParagraph.translation}` : articleParagraph?.text ?? articleFallbackText;
  elements.currentSyncRange.textContent = `#${syncEntry.paragraphIndex} \xB7 ${formatMs(syncEntry.startMs)} - ${formatMs(syncEntry.endMs)}`;
  elements.currentSyncScore.textContent = formatAlignmentScore(syncEntry.alignmentScore);
  elements.currentSyncSegments.textContent = syncEntry.transcriptSegmentIndexes.length > 0 ? `Transcript #${syncEntry.transcriptSegmentIndexes.join(", ")}` : "\u65E0\u76F4\u63A5 transcript \u547D\u4E2D";
  elements.currentSyncNote.textContent = resolveSyncNote(syncEntry, articleParagraph);
  renderNearbySyncEntries(currentTimeMs, syncEntry);
}
function broadcastPlayerState(force = false) {
  const now = Date.now();
  if (!force && now - lastBroadcastAt < 120) {
    renderCurrentSyncDetails(currentPlaybackTimeMs());
    return;
  }
  lastBroadcastAt = now;
  const currentTimeMs = currentPlaybackTimeMs();
  const syncEntry = resolveActiveSyncEntry(manifest, currentTimeMs);
  postRuntimeMessage({
    type: "PLAYER_STATE_UPDATE",
    payload: {
      currentTimeMs,
      state: currentPlaybackState(),
      activeParagraphIndex: syncEntry?.paragraphIndex ?? null,
      manifestSlug: manifest?.source.slug ?? null,
      playbackRate: elements.video.playbackRate
    }
  }, { retry: false });
  renderCurrentSyncDetails(currentTimeMs);
}
function validateSegment(segment) {
  return isObject(segment) && typeof segment.index === "number" && typeof segment.startMs === "number" && typeof segment.endMs === "number" && typeof segment.text === "string";
}
function validateSyncEntry(entry) {
  return isObject(entry) && typeof entry.paragraphIndex === "number" && typeof entry.startMs === "number" && typeof entry.endMs === "number" && Array.isArray(entry.transcriptSegmentIndexes);
}
function parseManifest(rawValue) {
  if (!isObject(rawValue)) {
    throw new Error("Sync manifest must be an object.");
  }
  if (rawValue.version !== "1.0.0") {
    throw new Error("Unsupported sync manifest version.");
  }
  if (!isObject(rawValue.source) || typeof rawValue.source.slug !== "string") {
    throw new Error("Sync manifest is missing source.slug.");
  }
  if (!isObject(rawValue.transcript) || typeof rawValue.transcript.mode !== "string" || typeof rawValue.transcript.text !== "string" || !Array.isArray(rawValue.transcript.segments) || !rawValue.transcript.segments.every(validateSegment)) {
    throw new Error("Sync manifest has an invalid transcript payload.");
  }
  if (!Array.isArray(rawValue.sync) || !rawValue.sync.every(validateSyncEntry)) {
    throw new Error("Sync manifest has an invalid sync array.");
  }
  return rawValue;
}
function installManifest(manifestValue, displayName, originKind) {
  manifest = manifestValue;
  manifestOriginKind = originKind;
  rebuildManifestLookups(manifestValue);
  elements.manifestName.textContent = originKind === "runtime-subtitle" ? `${displayName} (${manifestValue.sync.length} \u6BB5\u8FD0\u884C\u65F6\u6620\u5C04)` : `${displayName} (${manifestValue.sync.length} \u6761\u6620\u5C04)`;
  if (elements.remoteSlug && !elements.remoteSlug.value) {
    elements.remoteSlug.value = manifestValue.source.slug;
  }
  setStatus(`\u5DF2\u52A0\u8F7D\u540C\u6B65\u6E05\u5355\uFF1A${displayName}`);
  appendLog("\u540C\u6B65\u6E05\u5355\u5DF2\u52A0\u8F7D", {
    slug: manifestValue.source.slug,
    syncCount: manifestValue.sync.length
  });
  renderCurrentSyncDetails(currentPlaybackTimeMs());
  broadcastPlayerState(true);
}
async function readJsonFile(file) {
  return JSON.parse(await file.text());
}
function guessMimeTypeFromFileName(fileName) {
  const extension = fileExtension(fileName);
  switch (extension) {
    case "mp4":
      return "video/mp4";
    case "m4v":
      return "video/mp4";
    case "webm":
      return "video/webm";
    case "mkv":
      return "video/x-matroska";
    case "mov":
      return "video/quicktime";
    default:
      return null;
  }
}
async function applyVideoFileToPlayer(file, variant, displayName, statusMessage) {
  if (videoObjectUrl) {
    URL.revokeObjectURL(videoObjectUrl);
  }
  videoObjectUrl = URL.createObjectURL(file);
  elements.video.pause();
  elements.video.currentTime = 0;
  elements.video.removeAttribute("src");
  elements.video.load();
  currentVideoVariant = variant;
  elements.videoName.textContent = displayName;
  const detectedMimeType = file.type || guessMimeTypeFromFileName(file.name) || "\u672A\u77E5";
  const canPlay = detectedMimeType === "\u672A\u77E5" ? "maybe" : elements.video.canPlayType(detectedMimeType);
  elements.video.src = videoObjectUrl;
  elements.video.load();
  if (canPlay === "") {
    setStatus(`\u5F53\u524D\u6D4F\u89C8\u5668\u5185\u6838\u5F88\u53EF\u80FD\u4E0D\u652F\u6301\u76F4\u63A5\u89E3\u7801 ${file.name} (${detectedMimeType})\u3002`);
    appendLog("\u6D4F\u89C8\u5668\u62A5\u544A\u5F53\u524D\u6587\u4EF6\u683C\u5F0F\u53EF\u80FD\u65E0\u6CD5\u76F4\u63A5\u89E3\u7801", {
      fileName: file.name,
      detectedMimeType
    });
  } else {
    setStatus(statusMessage);
  }
  appendLog("\u672C\u5730\u89C6\u9891\u5DF2\u52A0\u8F7D", {
    fileName: file.name,
    displayName,
    detectedMimeType,
    canPlay,
    variant
  });
  updatePictureInPictureButton();
}
async function playOriginalVideoFile() {
  if (!sourceVideoFile) {
    throw new Error("\u8BF7\u5148\u62D6\u5165\u89C6\u9891\u6587\u4EF6\u3002");
  }
  const directPlaySuffix = sourceVideoAssessment?.isRecommendedProfile ? "\u63A8\u8350\u57FA\u7EBF\u547D\u4E2D\uFF0C\u5DF2\u76F4\u63A5\u64AD\u653E\u539F\u6587\u4EF6\u3002" : "\u5DF2\u65E0\u89C6\u98CE\u9669\u76F4\u63A5\u64AD\u653E\u539F\u6587\u4EF6\u3002";
  await applyVideoFileToPlayer(sourceVideoFile, "original", sourceVideoFile.name, directPlaySuffix);
}
async function playProcessedVideoFile() {
  if (!processedVideoFile) {
    throw new Error("\u5F53\u524D\u8FD8\u6CA1\u6709\u53EF\u64AD\u653E\u7684\u9884\u5904\u7406\u7ED3\u679C\u3002");
  }
  await applyVideoFileToPlayer(
    processedVideoFile,
    "processed",
    `${processedVideoFile.name}\uFF08\u8F6C\u7801\u7248\uFF09`,
    `\u5DF2\u52A0\u8F7D\u9884\u5904\u7406\u7ED3\u679C\uFF1A${processedVideoFile.name}`
  );
}
function buildBrowserFfmpegStatusMessage(event) {
  switch (event.phase) {
    case "loading-core":
      return "\u6B63\u5728\u88C5\u8F7D\u6269\u5C55\u5185\u7F6E FFmpeg Core";
    case "ready":
      return "\u5185\u7F6E FFmpeg Core \u5DF2\u5C31\u7EEA";
    case "writing-input":
      return event.detail?.message ?? "\u6B63\u5728\u5199\u5165\u8F93\u5165\u6587\u4EF6";
    case "probing":
      return event.detail?.message ?? "\u6B63\u5728\u5206\u6790\u5A92\u4F53\u6D41";
    case "transcoding":
      return event.detail?.message ?? "\u6B63\u5728\u9884\u5904\u7406\u5A92\u4F53\u6D41";
    case "reading-output":
      return event.detail?.message ?? "\u6B63\u5728\u8BFB\u53D6\u8F93\u51FA\u6587\u4EF6";
    case "completed":
      return event.detail?.message ?? "\u5904\u7406\u5B8C\u6210";
    default:
      return "\u5904\u7406\u4E2D";
  }
}
async function loadVideoFile(file) {
  if (videoTranscodeBusy) {
    throw new Error("\u5F53\u524D\u4ECD\u5728\u9884\u5904\u7406\u4E0A\u4E00\u4E2A\u89C6\u9891\uFF0C\u8BF7\u7B49\u5F85\u5B8C\u6210\u540E\u518D\u5207\u6362\u3002");
  }
  const currentToken = ++videoInspectionToken;
  sourceVideoFile = file;
  videoInspectionBusy = true;
  resetVideoDecisionState(file.name);
  updateVideoFileSelectionStatus(`\u5DF2\u8F7D\u5165\uFF1A${file.name}\uFF08\u6B63\u5728\u68C0\u6D4B\uFF09`);
  setStatus(`\u6B63\u5728\u68C0\u6D4B\u672C\u5730\u89C6\u9891\uFF1A${file.name}`);
  appendLog("\u5F00\u59CB\u68C0\u6D4B\u672C\u5730\u89C6\u9891", { fileName: file.name, size: file.size, type: file.type || "unknown" });
  try {
    const probe = await browserFfmpegService.inspectFile(file, {
      onStatusChange: (event) => {
        if (currentToken !== videoInspectionToken) {
          return;
        }
        const message = buildBrowserFfmpegStatusMessage(event);
        elements.videoProcessingStatus.textContent = message;
        setVideoProcessingProgress(message);
      },
      onLog: (message) => {
        if (currentToken !== videoInspectionToken) {
          return;
        }
        if (message.includes("Input #0") || message.includes("Video:") || message.includes("Audio:")) {
          appendLog("FFmpeg \u63A2\u6D4B\u65E5\u5FD7", { message });
        }
      }
    });
    if (currentToken !== videoInspectionToken) {
      return;
    }
    const assessment = assessMediaCompatibility(file.name, probe);
    const strategy = buildMediaTranscodeStrategy(file.name, probe);
    applyProbeOutcome(file, probe, assessment, strategy);
    appendLog("\u89C6\u9891\u771F\u5B9E\u6D41\u68C0\u6D4B\u5B8C\u6210", {
      fileName: file.name,
      probe,
      assessment,
      strategy
    });
    if (assessment.isRecommendedProfile) {
      await playOriginalVideoFile();
    } else {
      setStatus("\u5DF2\u68C0\u6D4B\u5230\u5F53\u524D\u6587\u4EF6\u504F\u79BB\u63A8\u8350\u64AD\u653E\u57FA\u7EBF\uFF0C\u8BF7\u9009\u62E9\u76F4\u63A5\u64AD\u653E\u6216\u4E00\u952E\u9884\u5904\u7406\u3002");
    }
  } catch (error) {
    if (currentToken !== videoInspectionToken) {
      return;
    }
    const message = error instanceof Error ? error.message : String(error);
    applyProbeFailure(file, message);
    setStatus(`\u89C6\u9891\u63A2\u6D4B\u5931\u8D25\uFF1A${message}`);
    appendLog("\u89C6\u9891\u771F\u5B9E\u6D41\u68C0\u6D4B\u5931\u8D25", { fileName: file.name, message });
  } finally {
    if (currentToken === videoInspectionToken) {
      videoInspectionBusy = false;
      updateVideoDecisionControls();
    }
  }
}
async function preprocessVideoFile() {
  if (!sourceVideoFile) {
    throw new Error("\u8BF7\u5148\u62D6\u5165\u89C6\u9891\u6587\u4EF6\u3002");
  }
  if (!sourceVideoProbe || !sourceVideoStrategy) {
    throw new Error("\u5F53\u524D\u6CA1\u6709\u53EF\u7528\u7684\u771F\u5B9E\u6D41\u68C0\u6D4B\u7ED3\u679C\uFF0C\u6682\u65F6\u4E0D\u80FD\u9884\u5904\u7406\u3002");
  }
  if (videoInspectionBusy || videoTranscodeBusy) {
    throw new Error("\u5F53\u524D\u5DF2\u6709\u89C6\u9891\u4EFB\u52A1\u5728\u6267\u884C\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002");
  }
  const sourceFile = sourceVideoFile;
  const sourceProbe = sourceVideoProbe;
  const strategy = sourceVideoStrategy;
  videoTranscodeBusy = true;
  updateVideoDecisionControls();
  elements.videoProcessingStatus.textContent = "\u6B63\u5728\u672C\u5730\u9884\u5904\u7406";
  setVideoProcessingProgress("\u51C6\u5907\u5199\u5165\u89C6\u9891\u5E76\u542F\u52A8\u9884\u5904\u7406...");
  setStatus(`\u6B63\u5728\u672C\u5730\u9884\u5904\u7406\uFF1A${sourceFile.name}`);
  appendLog("\u5F00\u59CB\u672C\u5730\u9884\u5904\u7406\u89C6\u9891", {
    fileName: sourceFile.name,
    strategy
  });
  try {
    revokeProcessedVideoArtifact();
    const result = await browserFfmpegService.transcodeFile(sourceFile, sourceProbe, {
      onStatusChange: (event) => {
        const message = buildBrowserFfmpegStatusMessage(event);
        elements.videoProcessingStatus.textContent = message;
        setVideoProcessingProgress(message);
      },
      onProgress: ({ progress }) => {
        setVideoProcessingProgress(describeTranscodePlan(strategy), progress);
      }
    });
    processedVideoFile = result.file;
    processedVideoObjectUrl = URL.createObjectURL(result.blob);
    elements.videoCompatibilityStatus.textContent = "\u5DF2\u751F\u6210\u517C\u5BB9\u7248\u672C";
    elements.videoCompatibilitySummary.textContent = "\u9884\u5904\u7406\u5B8C\u6210\uFF0C\u5DF2\u7ECF\u751F\u6210\u53EF\u4E0B\u8F7D\u3001\u53EF\u7ACB\u5373\u64AD\u653E\u7684 HVC1 + AAC MP4\u3002";
    elements.videoTranscodePlan.textContent = describeTranscodePlan(result.strategy);
    elements.videoProcessingStatus.textContent = "\u9884\u5904\u7406\u5B8C\u6210";
    setVideoProcessingProgress(`\u5DF2\u751F\u6210 ${result.file.name}\uFF0C\u53EF\u4EE5\u76F4\u63A5\u64AD\u653E\u6216\u4E0B\u8F7D\u3002`, 1);
    appendLog("\u672C\u5730\u9884\u5904\u7406\u5B8C\u6210", {
      sourceFileName: sourceFile.name,
      outputFileName: result.file.name,
      strategy: result.strategy,
      outputSize: result.file.size
    });
    await playProcessedVideoFile();
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    elements.videoProcessingStatus.textContent = "\u9884\u5904\u7406\u5931\u8D25";
    setVideoProcessingProgress(message);
    setStatus(`\u89C6\u9891\u9884\u5904\u7406\u5931\u8D25\uFF1A${message}`);
    appendLog("\u89C6\u9891\u9884\u5904\u7406\u5931\u8D25", { fileName: sourceFile.name, message });
    throw error;
  } finally {
    videoTranscodeBusy = false;
    updateVideoDecisionControls();
  }
}
function downloadProcessedVideo() {
  if (!processedVideoFile || !processedVideoObjectUrl) {
    throw new Error("\u5F53\u524D\u8FD8\u6CA1\u6709\u53EF\u4E0B\u8F7D\u7684\u8F6C\u7801\u7ED3\u679C\u3002");
  }
  const link = document.createElement("a");
  link.href = processedVideoObjectUrl;
  link.download = processedVideoFile.name;
  link.click();
}
function resetRuntimeSubtitleBuild() {
  currentRuntimeBuild = null;
  runtimeBuildInFlight = false;
  runtimeBuildRequestedFingerprint = null;
  runtimeBuildFailedFingerprint = null;
}
function resolveRuntimeBuildFingerprint() {
  if (!loadedSubtitleDocument || !articleSnapshot) {
    return null;
  }
  return [
    loadedSubtitleDocument.fileName,
    loadedSubtitleDocument.metadata.segmentCount,
    articleSnapshot.articleUrl,
    articleSnapshot.paragraphs.length
  ].join("::");
}
function describeBuildProgress(progress) {
  return `${Math.round(progress.percent * 100)}% \xB7 ${progress.message}`;
}
function applyRuntimeSubtitleStatus(buildResult) {
  if (!loadedSubtitleDocument) {
    setSubtitleStatus("\u672A\u52A0\u8F7D\u5B57\u5E55\u3002");
    setMatchingProgress("\u5F85\u547D", 0);
    return;
  }
  if (!buildResult) {
    if (runtimeBuildInFlight) {
      setSubtitleStatus("\u5B57\u5E55\u5DF2\u8F7D\u5165\uFF0C\u6B63\u5728\u6267\u884C\u8FD0\u884C\u65F6\u5339\u914D...");
      return;
    }
    if (articleSnapshotError) {
      setSubtitleStatus(`\u5B57\u5E55\u5DF2\u8F7D\u5165\uFF0C\u7B49\u5F85\u5168\u6587\u6587\u7AE0\u5FEB\u7167\uFF1A${articleSnapshotError}`);
      return;
    }
    if (!articleSnapshot) {
      setSubtitleStatus("\u5B57\u5E55\u5DF2\u8F7D\u5165\uFF0C\u7B49\u5F85\u4ECE reader \u9875\u9762\u62C9\u53D6\u5168\u6587\u6587\u7AE0\u540E\u81EA\u52A8\u5339\u914D\u3002");
      return;
    }
    setSubtitleStatus("\u5B57\u5E55\u5DF2\u8F7D\u5165\uFF0C\u7B49\u5F85\u8FD0\u884C\u65F6\u5339\u914D\u5B8C\u6210\u3002");
    return;
  }
  const { stats } = buildResult;
  setMatchingProgress(`\u5B8C\u6210 \xB7 \u8986\u76D6 ${formatRatio(stats.coverageRatio)}`, 1);
  setSubtitleStatus(
    `\u5DF2\u751F\u6210\u8FD0\u884C\u65F6\u6E05\u5355\uFF1A\u8986\u76D6 ${formatRatio(stats.coverageRatio)}\uFF0C\u547D\u4E2D ${stats.matchedParagraphCount}/${stats.articleParagraphCount} \u6BB5\uFF0C\u5E73\u6ED1 ${stats.smoothedParagraphCount} \u6BB5\u3002`
  );
}
function maybeRebuildRuntimeSubtitleManifest() {
  if (!subtitleAutoBuildEnabled || !loadedSubtitleDocument) {
    return;
  }
  if (articleSnapshotError) {
    applyRuntimeSubtitleStatus(null);
    return;
  }
  if (!articleSnapshot) {
    applyRuntimeSubtitleStatus(null);
    requestArticleSnapshot();
    return;
  }
  const fingerprint = resolveRuntimeBuildFingerprint();
  if (!fingerprint) {
    return;
  }
  if (fingerprint === runtimeBuildFingerprint && currentRuntimeBuild) {
    applyRuntimeSubtitleStatus(currentRuntimeBuild);
    return;
  }
  if (fingerprint === runtimeBuildFailedFingerprint) {
    applyRuntimeSubtitleStatus(null);
    return;
  }
  if (runtimeBuildInFlight && fingerprint === runtimeBuildRequestedFingerprint) {
    applyRuntimeSubtitleStatus(null);
    return;
  }
  const activeBuildToken = ++runtimeBuildToken;
  const activeSubtitleDocument = loadedSubtitleDocument;
  const activeArticleSnapshot = articleSnapshot;
  runtimeBuildInFlight = true;
  runtimeBuildRequestedFingerprint = fingerprint;
  currentRuntimeBuild = null;
  setMatchingProgress("0% \xB7 \u6B63\u5728\u51C6\u5907\u5339\u914D...", 0);
  setSubtitleStatus("\u5B57\u5E55\u5DF2\u8F7D\u5165\uFF0C\u6B63\u5728\u6267\u884C\u8FD0\u884C\u65F6\u5339\u914D...");
  void buildRuntimeManifestFromSubtitleAsync(activeSubtitleDocument, activeArticleSnapshot, (progress) => {
    if (activeBuildToken !== runtimeBuildToken) {
      return;
    }
    const progressText = describeBuildProgress(progress);
    setMatchingProgress(progressText, progress.percent);
    setSubtitleStatus(`\u5B57\u5E55\u5DF2\u8F7D\u5165\uFF0C\u6B63\u5728\u6267\u884C\u8FD0\u884C\u65F6\u5339\u914D... ${progressText}`);
  }).then((buildResult) => {
    if (activeBuildToken !== runtimeBuildToken) {
      return;
    }
    runtimeBuildInFlight = false;
    runtimeBuildFingerprint = fingerprint;
    runtimeBuildRequestedFingerprint = null;
    runtimeBuildFailedFingerprint = null;
    currentRuntimeBuild = buildResult;
    installManifest(
      buildResult.manifest,
      `${activeSubtitleDocument.fileName} \xB7 \u8FD0\u884C\u65F6\u5339\u914D`,
      "runtime-subtitle"
    );
    applyRuntimeSubtitleStatus(buildResult);
    appendLog("\u5DF2\u7528\u5B57\u5E55\u548C\u5168\u6587\u6587\u7AE0\u5FEB\u7167\u751F\u6210\u8FD0\u884C\u65F6\u6E05\u5355", {
      subtitleFile: activeSubtitleDocument.fileName,
      articleId: activeArticleSnapshot.articleId,
      coverageRatio: buildResult.stats.coverageRatio,
      matchedParagraphCount: buildResult.stats.matchedParagraphCount,
      smoothedParagraphCount: buildResult.stats.smoothedParagraphCount
    });
  }).catch((error) => {
    if (activeBuildToken !== runtimeBuildToken) {
      return;
    }
    resetRuntimeSubtitleBuild();
    runtimeBuildFailedFingerprint = fingerprint;
    const message = error instanceof Error ? error.message : String(error);
    setMatchingProgress(`\u5931\u8D25 \xB7 ${message}`, 0);
    setSubtitleStatus(`\u5B57\u5E55\u5339\u914D\u5931\u8D25\uFF1A${message}`);
    setStatus(message);
    appendLog("\u5B57\u5E55\u8FD0\u884C\u65F6\u5339\u914D\u5931\u8D25", { message, fileName: activeSubtitleDocument.fileName });
  });
}
async function loadSubtitleFile(file) {
  updateSubtitleFileSelectionStatus(`\u5DF2\u8F7D\u5165\uFF1A${file.name}\uFF08\u6B63\u5728\u89E3\u6790\uFF09`);
  const parsed = await parseSubtitleFile(file);
  loadedSubtitleDocument = parsed;
  subtitleAutoBuildEnabled = true;
  resetRuntimeSubtitleBuild();
  elements.subtitleName.textContent = `${parsed.fileName} (${parsed.metadata.segmentCount} \u6761\u5B57\u5E55)`;
  updateSubtitleFileSelectionStatus(`\u5DF2\u8F7D\u5165\uFF1A${parsed.fileName}`);
  setStatus(`\u5DF2\u52A0\u8F7D\u5B57\u5E55\uFF1A${parsed.fileName}`);
  setSubtitleStatus("\u5B57\u5E55\u5DF2\u89E3\u6790\uFF0C\u6B63\u5728\u8BF7\u6C42\u5168\u6587\u6587\u7AE0\u5E76\u81EA\u52A8\u5339\u914D...");
  appendLog("\u5B57\u5E55\u6587\u4EF6\u5DF2\u52A0\u8F7D", {
    fileName: parsed.fileName,
    format: parsed.format,
    segmentCount: parsed.metadata.segmentCount,
    translationCount: parsed.metadata.translationCount
  });
  maybeRebuildRuntimeSubtitleManifest();
}
async function loadManifestFile(file) {
  subtitleAutoBuildEnabled = false;
  resetRuntimeSubtitleBuild();
  installManifest(parseManifest(await readJsonFile(file)), file.name, "file");
  applyRuntimeSubtitleStatus(currentRuntimeBuild);
}
async function processDroppedFiles(files) {
  const unsupportedFiles = [];
  const loadedKinds = [];
  for (const file of files) {
    const extension = fileExtension(file.name);
    if (file.type.startsWith("video/") || supportedVideoExtensions.has(extension)) {
      await loadVideoFile(file);
      loadedKinds.push(`\u89C6\u9891 ${file.name}`);
      continue;
    }
    if (supportedSubtitleExtensions.has(extension)) {
      await loadSubtitleFile(file);
      loadedKinds.push(`\u5B57\u5E55 ${file.name}`);
      continue;
    }
    if (supportedManifestExtensions.has(extension)) {
      await loadManifestFile(file);
      loadedKinds.push(`\u6E05\u5355 ${file.name}`);
      continue;
    }
    unsupportedFiles.push(file.name);
  }
  if (unsupportedFiles.length > 0) {
    const message = `\u8FD9\u4E9B\u6587\u4EF6\u5F53\u524D\u672A\u8BC6\u522B\uFF1A${unsupportedFiles.join(", ")}`;
    setStatus(message);
    appendLog("\u6536\u5230\u672A\u8BC6\u522B\u7684\u62D6\u5165\u6587\u4EF6", { files: unsupportedFiles });
    return;
  }
  if (loadedKinds.length > 0) {
    setStatus(`\u62D6\u62FD\u5DF2\u8F7D\u5165\uFF1A${loadedKinds.join("\uFF1B")}`);
  }
}
function downloadJson(fileName, payload) {
  if (manifestObjectUrl) {
    URL.revokeObjectURL(manifestObjectUrl);
  }
  manifestObjectUrl = URL.createObjectURL(
    new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" })
  );
  const link = document.createElement("a");
  link.href = manifestObjectUrl;
  link.download = fileName;
  link.click();
}
function normalizeBaseUrl(baseUrl) {
  return baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
}
function guessRemoteManifestUrls(baseUrl, slug) {
  const normalizedBaseUrl = normalizeBaseUrl(baseUrl);
  return [`${normalizedBaseUrl}${slug}.json`, `${normalizedBaseUrl}sync-data/${slug}.json`];
}
function guessRemoteIndexUrls(baseUrl) {
  const normalizedBaseUrl = normalizeBaseUrl(baseUrl);
  return [`${normalizedBaseUrl}index.json`, `${normalizedBaseUrl}sync-data/index.json`];
}
function asStringArray(value) {
  return Array.isArray(value) ? value.filter((item) => typeof item === "string") : [];
}
function extractString(value) {
  return typeof value === "string" && value.trim().length > 0 ? value.trim() : null;
}
function extractNumber(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function extractCollection(rawValue) {
  return extractCollectionWithDepth(rawValue, 0);
}
function extractCollectionWithDepth(rawValue, depth) {
  if (depth > 4) {
    return [];
  }
  if (Array.isArray(rawValue)) {
    return rawValue;
  }
  if (!isObject(rawValue)) {
    return [];
  }
  const collectionKeys = ["manifests", "items", "files", "entries", "results", "data", "episodes", "records", "list", "catalog", "catalogue", "index"];
  for (const key of collectionKeys) {
    const nestedCollection = extractCollectionWithDepth(rawValue[key], depth + 1);
    if (nestedCollection.length > 0) {
      return nestedCollection;
    }
  }
  const objectEntries = Object.entries(rawValue);
  const mappedObjectValues = objectEntries.flatMap(([key, value]) => {
    if (typeof value === "string") {
      return [{ key, path: value }];
    }
    if (isObject(value)) {
      return [{ key, ...value }];
    }
    return [];
  });
  if (mappedObjectValues.some(
    (value) => isObject(value) && [
      value.slug,
      value.id,
      value.key,
      value.episodeSlug,
      value.url,
      value.manifestUrl,
      value.downloadUrl,
      value.path,
      value.fileName,
      value.file,
      value.filePath
    ].some((candidate) => typeof candidate === "string")
  )) {
    return mappedObjectValues;
  }
  return objectEntries.flatMap(([, value]) => extractCollectionWithDepth(value, depth + 1));
}
function collectCandidateMetadataObjects(entry) {
  const metadataKeys = ["source", "meta", "metadata", "manifest", "episode", "record", "item", "attributes", "context", "file"];
  const objects = [entry];
  for (const key of metadataKeys) {
    const candidate = entry[key];
    if (isObject(candidate)) {
      objects.push(candidate);
    }
  }
  return objects;
}
function extractStringFromObjects(objects, extractor) {
  for (const objectValue of objects) {
    const extracted = extractString(extractor(objectValue));
    if (extracted) {
      return extracted;
    }
  }
  return null;
}
function extractNumberFromObjects(objects, extractor) {
  for (const objectValue of objects) {
    const extracted = extractNumber(extractor(objectValue));
    if (extracted !== null) {
      return extracted;
    }
  }
  return null;
}
function extractStringArraysFromObjects(objects, extractor) {
  return dedupeStrings(objects.flatMap((objectValue) => asStringArray(extractor(objectValue))));
}
function resolveCandidateUrl(baseUrl, rawUrl) {
  return new URL(rawUrl, normalizeBaseUrl(baseUrl)).toString();
}
function parseRemoteIndexCandidates(rawValue, baseUrl) {
  const collection = extractCollection(rawValue);
  const candidates = collection.flatMap((entry) => {
    if (typeof entry === "string") {
      const inferredSlug = normalizeEpisodeSlug(entry.split("/").pop() ?? entry);
      return [{
        slug: inferredSlug,
        title: inferredSlug,
        url: resolveCandidateUrl(baseUrl, entry),
        description: entry,
        articleId: null,
        categoryId: null,
        tags: []
      }];
    }
    if (!isObject(entry)) {
      return [];
    }
    const candidateObjects = collectCandidateMetadataObjects(entry);
    const slug = extractStringFromObjects(candidateObjects, (objectValue) => objectValue.slug) ?? extractStringFromObjects(candidateObjects, (objectValue) => objectValue.id) ?? extractStringFromObjects(candidateObjects, (objectValue) => objectValue.key) ?? extractStringFromObjects(candidateObjects, (objectValue) => objectValue.episodeSlug) ?? (extractString(entry.fileName) ? normalizeEpisodeSlug(extractString(entry.fileName) ?? "") : null) ?? (extractString(entry.filePath) ? normalizeEpisodeSlug((extractString(entry.filePath) ?? "").split("/").pop() ?? extractString(entry.filePath) ?? "") : null) ?? (extractString(entry.path) ? normalizeEpisodeSlug((extractString(entry.path) ?? "").split("/").pop() ?? extractString(entry.path) ?? "") : null) ?? null;
    const rawUrl = extractStringFromObjects(candidateObjects, (objectValue) => objectValue.url) ?? extractStringFromObjects(candidateObjects, (objectValue) => objectValue.manifestUrl) ?? extractStringFromObjects(candidateObjects, (objectValue) => objectValue.downloadUrl) ?? extractStringFromObjects(candidateObjects, (objectValue) => objectValue.path) ?? extractStringFromObjects(candidateObjects, (objectValue) => objectValue.fileName) ?? extractStringFromObjects(candidateObjects, (objectValue) => objectValue.file) ?? extractStringFromObjects(candidateObjects, (objectValue) => objectValue.filePath) ?? null;
    if (!slug || !rawUrl) {
      return [];
    }
    const title = extractStringFromObjects(candidateObjects, (objectValue) => objectValue.title) ?? extractStringFromObjects(candidateObjects, (objectValue) => objectValue.name) ?? extractStringFromObjects(candidateObjects, (objectValue) => objectValue.label) ?? extractStringFromObjects(candidateObjects, (objectValue) => objectValue.displayName) ?? slug;
    const articleId = extractNumberFromObjects(candidateObjects, (objectValue) => objectValue.articleId);
    const categoryId = extractNumberFromObjects(candidateObjects, (objectValue) => objectValue.categoryId);
    const tags = dedupeStrings([
      ...extractStringArraysFromObjects(candidateObjects, (objectValue) => objectValue.tags),
      ...extractStringArraysFromObjects(candidateObjects, (objectValue) => objectValue.keywords),
      ...extractStringArraysFromObjects(candidateObjects, (objectValue) => objectValue.aliases)
    ]);
    const parts = [
      articleId !== null ? `article#${articleId}` : null,
      categoryId !== null ? `category#${categoryId}` : null,
      extractStringFromObjects(candidateObjects, (objectValue) => objectValue.series),
      extractStringFromObjects(candidateObjects, (objectValue) => objectValue.seasonEpisode),
      extractStringFromObjects(candidateObjects, (objectValue) => objectValue.description),
      ...tags
    ].filter((value) => Boolean(value));
    return [{
      slug,
      title,
      url: resolveCandidateUrl(baseUrl, rawUrl),
      description: parts.join(" \xB7 "),
      articleId,
      categoryId,
      tags
    }];
  });
  return Array.from(new Map(candidates.map((candidate) => [candidate.url, candidate])).values());
}
async function fetchManifestFromUrl(url) {
  const response = await fetch(url, { credentials: "omit" });
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }
  return parseManifest(await response.json());
}
function rankRemoteCandidates(slug, candidates) {
  const normalizedSlug = slug.trim().toLowerCase();
  const currentArticleId = pageContext?.articleId ?? manifest?.source.articleId ?? null;
  const currentCategoryId = pageContext?.categoryId ?? manifest?.source.categoryId ?? null;
  return [...candidates].sort((left, right) => {
    const score = (candidate) => {
      let total = 0;
      const slugLower = candidate.slug.toLowerCase();
      const titleLower = candidate.title.toLowerCase();
      const descriptionLower = candidate.description.toLowerCase();
      if (slugLower === normalizedSlug) {
        total += 100;
      } else if (slugLower.startsWith(normalizedSlug)) {
        total += 70;
      } else if (slugLower.includes(normalizedSlug)) {
        total += 50;
      }
      if (titleLower.includes(normalizedSlug)) {
        total += 20;
      }
      if (descriptionLower.includes(normalizedSlug)) {
        total += 10;
      }
      if (candidate.tags.some((tag) => tag.toLowerCase().includes(normalizedSlug))) {
        total += 15;
      }
      if (currentArticleId !== null && candidate.articleId === currentArticleId) {
        total += 80;
      }
      if (currentCategoryId !== null && candidate.categoryId === currentCategoryId) {
        total += 30;
      }
      return total;
    };
    const leftScore = score(left);
    const rightScore = score(right);
    if (leftScore !== rightScore) {
      return rightScore - leftScore;
    }
    return left.slug.localeCompare(right.slug);
  });
}
async function fetchRemoteIndex(baseUrl) {
  const indexUrls = guessRemoteIndexUrls(baseUrl);
  let lastError = null;
  for (const indexUrl of indexUrls) {
    try {
      appendLog("\u5C1D\u8BD5\u62C9\u53D6\u8FDC\u7AEF\u7D22\u5F15", { url: indexUrl });
      const response = await fetch(indexUrl, { credentials: "omit" });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const candidates = parseRemoteIndexCandidates(await response.json(), baseUrl);
      if (candidates.length === 0) {
        throw new Error("\u8FDC\u7AEF\u7D22\u5F15\u4E2D\u6CA1\u6709\u53EF\u7528\u5019\u9009\u3002");
      }
      return { candidates, sourceUrl: indexUrl };
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
    }
  }
  throw lastError ?? new Error("\u8FDC\u7AEF\u7D22\u5F15\u62C9\u53D6\u5931\u8D25\u3002");
}
async function refreshRemoteIndexCandidates(preferredSlug) {
  if (!elements.manifestBaseUrl || !elements.remoteSlug) {
    throw new Error("\u5F53\u524D\u5206\u652F\u5DF2\u5173\u95ED\u8FDC\u7AEF\u6E05\u5355\u5165\u53E3\u3002");
  }
  const baseUrl = elements.manifestBaseUrl.value.trim();
  if (!baseUrl) {
    throw new Error("\u8BF7\u5148\u586B\u5199\u8FDC\u7AEF\u6E05\u5355\u57FA\u5730\u5740\u3002");
  }
  localStorage.setItem(storageKey, baseUrl);
  const indexResponse = await fetchRemoteIndex(baseUrl);
  remoteIndexSourceUrl = indexResponse.sourceUrl;
  const slug = (preferredSlug ?? elements.remoteSlug.value.trim()).trim();
  remoteManifestCandidates = slug ? rankRemoteCandidates(slug, indexResponse.candidates) : indexResponse.candidates;
  renderRemoteManifestCandidates(remoteManifestCandidates[0]?.url ?? null);
  appendLog("\u8FDC\u7AEF\u7D22\u5F15\u5DF2\u8F7D\u5165", {
    sourceUrl: indexResponse.sourceUrl,
    candidateCount: remoteManifestCandidates.length,
    preferredSlug: slug
  });
  return remoteManifestCandidates;
}
async function loadRemoteManifestCandidate(candidateUrl) {
  const selectedCandidate = remoteManifestCandidates.find((candidate) => candidate.url === candidateUrl) ?? null;
  appendLog("\u5C1D\u8BD5\u52A0\u8F7D\u8FDC\u7AEF\u5019\u9009\u6E05\u5355", { url: candidateUrl });
  const manifestValue = await fetchManifestFromUrl(candidateUrl);
  subtitleAutoBuildEnabled = false;
  resetRuntimeSubtitleBuild();
  installManifest(manifestValue, candidateUrl, "remote");
  applyRuntimeSubtitleStatus(currentRuntimeBuild);
  if (selectedCandidate) {
    setRemoteIndexStatus(`\u5DF2\u4ECE\u5019\u9009\u5217\u8868\u52A0\u8F7D\uFF1A${formatRemoteCandidateSummary(selectedCandidate)}`);
  }
}
async function fetchRemoteManifest() {
  const explicitManifestUrl = searchParameters.get("manifestUrl")?.trim();
  if (explicitManifestUrl) {
    appendLog("\u5C1D\u8BD5\u62C9\u53D6\u663E\u5F0F\u6E05\u5355 URL", { url: explicitManifestUrl });
    subtitleAutoBuildEnabled = false;
    resetRuntimeSubtitleBuild();
    installManifest(await fetchManifestFromUrl(explicitManifestUrl), explicitManifestUrl, "remote");
    applyRuntimeSubtitleStatus(currentRuntimeBuild);
    return;
  }
  if (!elements.manifestBaseUrl || !elements.remoteSlug) {
    throw new Error("\u5F53\u524D\u5206\u652F\u5DF2\u5173\u95ED\u8FDC\u7AEF\u6E05\u5355\u5165\u53E3\u3002");
  }
  const baseUrl = elements.manifestBaseUrl.value.trim();
  if (!baseUrl) {
    throw new Error("\u8BF7\u5148\u586B\u5199\u8FDC\u7AEF\u6E05\u5355\u57FA\u5730\u5740\u3002");
  }
  const slug = elements.remoteSlug.value.trim();
  if (!slug) {
    throw new Error("\u8BF7\u5148\u586B\u5199\u5267\u96C6 slug\u3002");
  }
  localStorage.setItem(storageKey, baseUrl);
  const candidates = guessRemoteManifestUrls(baseUrl, slug);
  let lastError = null;
  for (const candidateUrl of candidates) {
    try {
      appendLog("\u5C1D\u8BD5\u62C9\u53D6\u8FDC\u7AEF\u6E05\u5355", { url: candidateUrl });
      subtitleAutoBuildEnabled = false;
      resetRuntimeSubtitleBuild();
      installManifest(await fetchManifestFromUrl(candidateUrl), candidateUrl, "remote");
      applyRuntimeSubtitleStatus(currentRuntimeBuild);
      setRemoteIndexStatus("\u5DF2\u901A\u8FC7 slug \u76F4\u8FDE\u627E\u5230\u8FDC\u7AEF\u6E05\u5355\u3002");
      return;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
    }
  }
  appendLog("slug \u76F4\u8FDE\u5931\u8D25\uFF0C\u8F6C\u5165\u8FDC\u7AEF\u7D22\u5F15\u515C\u5E95", { slug, message: lastError?.message ?? null });
  const fallbackCandidates = await refreshRemoteIndexCandidates(slug);
  const bestCandidate = fallbackCandidates.find((candidate) => candidate.slug.toLowerCase() === slug.toLowerCase()) ?? fallbackCandidates[0] ?? null;
  if (!bestCandidate) {
    throw lastError ?? new Error("\u8FDC\u7AEF\u6E05\u5355\u62C9\u53D6\u5931\u8D25\u3002");
  }
  await loadRemoteManifestCandidate(bestCandidate.url);
}
function seekToMilliseconds(milliseconds) {
  if (!Number.isFinite(milliseconds)) {
    return;
  }
  elements.video.currentTime = Math.max(milliseconds, 0) / 1e3;
  updateTransportTime();
  broadcastPlayerState(true);
}
function handleParagraphSeek(paragraphIndex) {
  if (!manifest) {
    appendLog("\u6536\u5230\u9875\u9762\u6BB5\u843D\u70B9\u51FB\uFF0C\u4F46\u5F53\u524D\u6CA1\u6709\u540C\u6B65\u6E05\u5355\u3002");
    return;
  }
  const entry = manifest.sync.find((item) => item.paragraphIndex === paragraphIndex);
  if (!entry) {
    appendLog("\u5F53\u524D\u540C\u6B65\u6E05\u5355\u6CA1\u6709\u8FD9\u4E2A\u6BB5\u843D\u7684\u6620\u5C04", { paragraphIndex });
    return;
  }
  seekToMilliseconds(entry.startMs);
  appendLog("\u6839\u636E\u9875\u9762\u6BB5\u843D\u70B9\u51FB\u56DE\u8DF3\u89C6\u9891", { paragraphIndex, seekMs: entry.startMs });
}
async function togglePlayback() {
  if (elements.video.paused) {
    await elements.video.play();
  } else {
    elements.video.pause();
  }
  updatePlayToggle();
  broadcastPlayerState(true);
}
function adjustPlaybackBy(deltaMs) {
  seekToMilliseconds(currentPlaybackTimeMs() + deltaMs);
  appendLog("\u5FEB\u6377\u952E\u8DF3\u8F6C", { deltaMs, currentTimeMs: currentPlaybackTimeMs() });
}
async function executePlayerControlCommand(payload) {
  switch (payload.command) {
    case "toggle_playback":
      await togglePlayback();
      return;
    case "seek_by":
      adjustPlaybackBy(payload.deltaMs ?? 0);
      return;
    case "step_playback_rate":
      stepPlaybackRate(payload.step ?? 0, payload.source);
      return;
    default:
      return;
  }
}
async function togglePictureInPicture() {
  if (!document.pictureInPictureEnabled) {
    setStatus("\u5F53\u524D\u6D4F\u89C8\u5668\u73AF\u5883\u4E0D\u652F\u6301\u753B\u4E2D\u753B\u3002");
    return;
  }
  if (!elements.video.src) {
    setStatus("\u8BF7\u5148\u52A0\u8F7D\u672C\u5730\u89C6\u9891\u540E\u518D\u8FDB\u5165\u753B\u4E2D\u753B\u3002");
    return;
  }
  if (document.pictureInPictureElement === elements.video) {
    await document.exitPictureInPicture();
    appendLog("\u5DF2\u9000\u51FA\u753B\u4E2D\u753B");
  } else {
    await elements.video.requestPictureInPicture();
    appendLog("\u5DF2\u8FDB\u5165\u753B\u4E2D\u753B");
  }
  updatePictureInPictureButton();
}
function requestConnectedTabs() {
  postRuntimeMessage({ type: "REQUEST_CONNECTED_TABS" });
}
function refreshReaderTabs() {
  setConnectedTabsStatus("\u6B63\u5728\u626B\u63CF\u6240\u6709 aim-read \u9875\u9762\uFF0C\u5FC5\u8981\u65F6\u4F1A\u5237\u65B0\u6587\u7AE0\u9875\u2026");
  postRuntimeMessage({ type: "REFRESH_READER_TABS" });
}
function bindSelectedPage() {
  const tabId = Number.parseInt(elements.pageTabSelect.value, 10);
  if (!Number.isFinite(tabId)) {
    return;
  }
  boundPageTabId = tabId;
  renderConnectedTabs();
  postRuntimeMessage({
    type: "SET_PREFERRED_TAB",
    payload: { tabId }
  });
  setConnectedTabsStatus(`\u6B63\u5728\u7ED1\u5B9A tab#${tabId}...`);
  if (subtitleAutoBuildEnabled) {
    requestArticleSnapshot();
  }
}
elements.videoFile.addEventListener("change", async () => {
  const file = elements.videoFile.files?.[0];
  if (!file) {
    return;
  }
  try {
    await loadVideoFile(file);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    setStatus(message);
    appendLog("\u89C6\u9891\u6587\u4EF6\u52A0\u8F7D\u5931\u8D25", { message, fileName: file.name });
  }
});
elements.subtitleFile.addEventListener("change", async () => {
  const file = elements.subtitleFile.files?.[0];
  if (!file) {
    return;
  }
  try {
    await loadSubtitleFile(file);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    updateSubtitleFileSelectionStatus(`\u5DF2\u8F7D\u5165\uFF1A${file.name}\uFF08\u52A0\u8F7D\u5931\u8D25\uFF09`);
    setSubtitleStatus(`\u5B57\u5E55\u52A0\u8F7D\u5931\u8D25\uFF1A${message}`);
    setStatus(message);
    appendLog("\u5B57\u5E55\u6587\u4EF6\u52A0\u8F7D\u5931\u8D25", { message, fileName: file.name });
  }
});
elements.playOriginalVideo.addEventListener("click", () => {
  void playOriginalVideoFile().catch((error) => {
    const message = error instanceof Error ? error.message : String(error);
    setStatus(message);
    appendLog("\u76F4\u63A5\u64AD\u653E\u539F\u6587\u4EF6\u5931\u8D25", { message, fileName: sourceVideoFile?.name ?? null });
  });
});
elements.preprocessVideo.addEventListener("click", () => {
  void preprocessVideoFile().catch((error) => {
    const message = error instanceof Error ? error.message : String(error);
    setStatus(message);
    appendLog("\u70B9\u51FB\u9884\u5904\u7406\u5931\u8D25", { message, fileName: sourceVideoFile?.name ?? null });
  });
});
elements.playProcessedVideo.addEventListener("click", () => {
  void playProcessedVideoFile().catch((error) => {
    const message = error instanceof Error ? error.message : String(error);
    setStatus(message);
    appendLog("\u64AD\u653E\u8F6C\u7801\u7ED3\u679C\u5931\u8D25", { message, fileName: processedVideoFile?.name ?? null });
  });
});
elements.downloadProcessedVideo.addEventListener("click", () => {
  try {
    downloadProcessedVideo();
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    setStatus(message);
    appendLog("\u4E0B\u8F7D\u8F6C\u7801\u7ED3\u679C\u5931\u8D25", { message, fileName: processedVideoFile?.name ?? null });
  }
});
elements.manifestFile?.addEventListener("change", async () => {
  const file = elements.manifestFile?.files?.[0];
  if (!file) {
    return;
  }
  try {
    await loadManifestFile(file);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    setStatus(message);
    appendLog("\u672C\u5730\u6E05\u5355\u52A0\u8F7D\u5931\u8D25", { message, fileName: file.name });
  }
});
elements.fetchRemoteManifestButton?.addEventListener("click", async () => {
  try {
    setStatus("\u6B63\u5728\u62C9\u53D6\u8FDC\u7AEF\u6E05\u5355...");
    await fetchRemoteManifest();
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    setStatus(message);
    appendLog("\u8FDC\u7AEF\u6E05\u5355\u62C9\u53D6\u5931\u8D25", { message });
  }
});
elements.refreshRemoteIndexButton?.addEventListener("click", async () => {
  try {
    setStatus("\u6B63\u5728\u5237\u65B0\u8FDC\u7AEF\u5019\u9009...");
    await refreshRemoteIndexCandidates();
    setStatus("\u8FDC\u7AEF\u5019\u9009\u5DF2\u5237\u65B0\u3002");
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    setStatus(message);
    appendLog("\u8FDC\u7AEF\u7D22\u5F15\u62C9\u53D6\u5931\u8D25", { message });
  }
});
elements.remoteManifestCandidate?.addEventListener("change", () => {
  updateRemoteCandidateControlState();
  syncRemoteCandidateStatus(elements.remoteManifestCandidate?.value);
});
elements.loadRemoteCandidateButton?.addEventListener("click", async () => {
  try {
    const candidateUrl = elements.remoteManifestCandidate?.value.trim() ?? "";
    if (!candidateUrl) {
      throw new Error("\u8BF7\u5148\u9009\u62E9\u4E00\u4E2A\u8FDC\u7AEF\u5019\u9009\u3002");
    }
    setStatus("\u6B63\u5728\u52A0\u8F7D\u6240\u9009\u8FDC\u7AEF\u5019\u9009...");
    await loadRemoteManifestCandidate(candidateUrl);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    setStatus(message);
    appendLog("\u8FDC\u7AEF\u5019\u9009\u52A0\u8F7D\u5931\u8D25", { message });
  }
});
elements.requestPageContextButton.addEventListener("click", () => {
  postRuntimeMessage({ type: "REQUEST_ACTIVE_PAGE_CONTEXT" });
  if (subtitleAutoBuildEnabled) {
    requestArticleSnapshot();
  }
});
elements.refreshConnectedTabsButton.addEventListener("click", () => {
  refreshReaderTabs();
});
elements.pageTabSelect.addEventListener("change", () => {
  updateConnectedTabsControlState();
});
elements.bindSelectedPageButton.addEventListener("click", () => {
  bindSelectedPage();
});
elements.saveShortcuts.addEventListener("click", () => {
  const settings = readShortcutSettingsFromInputs();
  void persistShortcutSettings(settings).then(() => {
    setStatus("\u5FEB\u6377\u952E\u8BBE\u7F6E\u5DF2\u4FDD\u5B58\u3002");
    appendLog("\u5FEB\u6377\u952E\u8BBE\u7F6E\u5DF2\u4FDD\u5B58", settings);
  }).catch((error) => {
    const message = error instanceof Error ? error.message : String(error);
    setStatus(message);
    appendLog("\u4FDD\u5B58\u5FEB\u6377\u952E\u8BBE\u7F6E\u5931\u8D25", { message });
  });
});
elements.exportPageContextButton.addEventListener("click", () => {
  if (!pageContext) {
    return;
  }
  const fileName = `aim-read-page-context-${pageContext.articleId ?? "unknown"}-${Date.now()}.json`;
  downloadJson(fileName, pageContext);
});
elements.pipToggle.addEventListener("click", async () => {
  try {
    await togglePictureInPicture();
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    setStatus(message);
    appendLog("\u753B\u4E2D\u753B\u5207\u6362\u5931\u8D25", { message });
  }
});
elements.pipTogglePlayer.addEventListener("click", async () => {
  try {
    await togglePictureInPicture();
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    setStatus(message);
    appendLog("\u64AD\u653E\u5668\u533A\u753B\u4E2D\u753B\u5207\u6362\u5931\u8D25", { message });
  }
});
elements.openTutorialButton.addEventListener("click", () => {
  openTutorial({ scroll: true });
});
elements.tutorialClose.addEventListener("click", () => {
  void dismissTutorial();
});
elements.tutorialNext.addEventListener("click", () => {
  advanceTutorial();
});
elements.playToggle.addEventListener("click", async () => {
  try {
    await togglePlayback();
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    setStatus(message);
    appendLog("\u64AD\u653E\u5668\u5207\u6362\u5931\u8D25", { message });
  }
});
elements.seekRange.addEventListener("input", () => {
  const durationMs = Number.isFinite(elements.video.duration) ? elements.video.duration * 1e3 : 0;
  const ratio = Number.parseInt(elements.seekRange.value, 10) / 1e3;
  elements.video.currentTime = durationMs * ratio / 1e3;
  updateTransportTime();
  broadcastPlayerState(true);
});
elements.playbackRate.addEventListener("change", () => {
  setPlaybackRate(Number.parseFloat(elements.playbackRate.value), "player");
});
elements.syncNearbyList.addEventListener("click", (event) => {
  const target = event.target;
  if (!(target instanceof HTMLElement)) {
    return;
  }
  const trigger = target.closest("[data-start-ms]");
  if (!trigger) {
    return;
  }
  const startMs = Number.parseInt(trigger.dataset.startMs ?? "", 10);
  const paragraphIndex = Number.parseInt(trigger.dataset.paragraphIndex ?? "", 10);
  seekToMilliseconds(startMs);
  appendLog("\u4ECE\u64AD\u653E\u5668\u9644\u8FD1\u6BB5\u843D\u5217\u8868\u56DE\u8DF3", { paragraphIndex, startMs });
});
for (const eventName of ["dragenter", "dragover"]) {
  elements.dropZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    elements.dropZone.classList.add("is-drag-over");
  });
}
for (const eventName of ["dragleave", "dragend"]) {
  elements.dropZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    const relatedTarget = "relatedTarget" in event ? event.relatedTarget : null;
    if (!(relatedTarget instanceof Node) || !elements.dropZone.contains(relatedTarget)) {
      elements.dropZone.classList.remove("is-drag-over");
    }
  });
}
elements.dropZone.addEventListener("drop", (event) => {
  event.preventDefault();
  elements.dropZone.classList.remove("is-drag-over");
  const files = Array.from(event.dataTransfer?.files ?? []);
  if (files.length === 0) {
    return;
  }
  void processDroppedFiles(files).catch((error) => {
    const message = error instanceof Error ? error.message : String(error);
    setStatus(message);
    appendLog("\u62D6\u62FD\u6587\u4EF6\u5904\u7406\u5931\u8D25", { message });
  });
});
window.addEventListener("keydown", async (event) => {
  if (tutorialActive) {
    if (event.key === "Escape") {
      event.preventDefault();
      void dismissTutorial();
    }
    return;
  }
  if (isEditableTarget(event.target) || event.isComposing) {
    return;
  }
  if (matchesConfiguredShortcut(event, shortcutSettings.togglePlayback)) {
    if (isEventFromVideoElement(event)) {
      return;
    }
    event.preventDefault();
    await togglePlayback().catch((error) => {
      const message = error instanceof Error ? error.message : String(error);
      setStatus(message);
      appendLog("\u5FEB\u6377\u952E\u64AD\u653E\u5207\u6362\u5931\u8D25", { message });
    });
    return;
  }
  if (matchesConfiguredShortcut(event, shortcutSettings.seekBackward)) {
    event.preventDefault();
    adjustPlaybackBy(-shortcutSettings.seekSeconds * 1e3);
    return;
  }
  if (matchesConfiguredShortcut(event, shortcutSettings.seekForward)) {
    event.preventDefault();
    adjustPlaybackBy(shortcutSettings.seekSeconds * 1e3);
    return;
  }
  if (matchesConfiguredShortcut(event, shortcutSettings.rateDown)) {
    event.preventDefault();
    stepPlaybackRate(-1, "player");
    return;
  }
  if (matchesConfiguredShortcut(event, shortcutSettings.rateUp)) {
    event.preventDefault();
    stepPlaybackRate(1, "player");
    return;
  }
  if (matchesKeyboardShortcut(event, "KeyJ", ["j"])) {
    adjustPlaybackBy(-1e4);
    return;
  }
  if (matchesKeyboardShortcut(event, "KeyL", ["l"])) {
    adjustPlaybackBy(1e4);
    return;
  }
  if (matchesKeyboardShortcut(event, "KeyP", ["p"])) {
    event.preventDefault();
    await togglePictureInPicture().catch((error) => {
      const message = error instanceof Error ? error.message : String(error);
      setStatus(message);
      appendLog("\u5FEB\u6377\u952E\u753B\u4E2D\u753B\u5207\u6362\u5931\u8D25", { message });
    });
  }
});
for (const eventName of [
  "play",
  "pause",
  "canplay",
  "seeking",
  "seeked",
  "timeupdate",
  "ended",
  "error",
  "loadedmetadata",
  "enterpictureinpicture",
  "leavepictureinpicture"
]) {
  elements.video.addEventListener(eventName, () => {
    updateTransportTime();
    updatePlayToggle();
    updatePictureInPictureButton();
    broadcastPlayerState(eventName !== "timeupdate");
  });
}
elements.video.addEventListener("error", () => {
  const mediaError = elements.video.error;
  const message = mediaError?.message || (typeof mediaError?.code === "number" ? `HTMLMediaElement error code ${mediaError.code}` : "\u6D4F\u89C8\u5668\u65E0\u6CD5\u64AD\u653E\u5F53\u524D\u89C6\u9891\u6587\u4EF6\u3002");
  setStatus(message);
  appendLog("\u89C6\u9891\u52A0\u8F7D\u6216\u64AD\u653E\u5931\u8D25", {
    message,
    code: mediaError?.code ?? null,
    currentSrc: elements.video.currentSrc || null
  });
});
function handleRuntimeMessage(message) {
  switch (message.type) {
    case "ACTIVE_ARTICLE_SNAPSHOT_RESPONSE":
      updateArticleSnapshot(message.payload.articleSnapshot, message.payload.error, message.payload.tabId);
      return;
    case "ACTIVE_PAGE_CONTEXT_RESPONSE":
      updatePageContext(message.payload.pageContext, message.payload.tabId);
      return;
    case "CONNECTED_TABS_RESPONSE":
      updateConnectedTabs(message.payload);
      return;
    case "PLAYER_CONTROL_COMMAND":
      void executePlayerControlCommand(message.payload).catch((error) => {
        const messageText = error instanceof Error ? error.message : String(error);
        setStatus(messageText);
        appendLog("\u8FDC\u7AEF\u63A7\u5236\u6267\u884C\u5931\u8D25", { message: messageText, source: message.payload.source });
      });
      return;
    case "PLAYER_SEEK_COMMAND":
      handleParagraphSeek(message.payload.paragraphIndex);
      return;
    default:
      return;
  }
}
if (elements.manifestBaseUrl) {
  elements.manifestBaseUrl.value = localStorage.getItem(storageKey) ?? "";
  if (searchParameters.has("manifestBaseUrl")) {
    elements.manifestBaseUrl.value = searchParameters.get("manifestBaseUrl") ?? "";
  }
}
if (elements.remoteSlug && searchParameters.has("slug")) {
  elements.remoteSlug.value = searchParameters.get("slug") ?? "";
}
elements.playbackRate.value = "1";
elements.video.playbackRate = 1;
updateVideoFileSelectionStatus();
updateSubtitleFileSelectionStatus();
elements.subtitleName.textContent = "\u672A\u52A0\u8F7D";
resetVideoDecisionState();
setSubtitleStatus("\u672A\u52A0\u8F7D\u5B57\u5E55\u3002");
setRemoteIndexStatus("\u8FD8\u6CA1\u6709\u62C9\u53D6\u8FDC\u7AEF\u7D22\u5F15\u3002");
setMatchingProgress("\u5F85\u547D");
setConnectedTabsStatus("\u5F53\u524D\u8FD8\u6CA1\u6709\u53EF\u7ED1\u5B9A\u7684\u9875\u9762\u3002");
updateRemoteCandidateControlState();
updateConnectedTabsControlState();
updateTransportTime();
updatePlayToggle();
updatePictureInPictureButton();
renderRemoteManifestCandidates();
renderConnectedTabs();
renderCurrentSyncDetails(currentPlaybackTimeMs());
setStatus("\u7B49\u5F85\u8F93\u5165\u3002");
connectPlayerPort();
requestConnectedTabs();
postRuntimeMessage({ type: "REQUEST_ACTIVE_PAGE_CONTEXT" });
window.addEventListener("resize", () => {
  if (tutorialActive) {
    queueTutorialPositionUpdate();
  }
});
window.addEventListener("scroll", () => {
  if (tutorialActive) {
    queueTutorialPositionUpdate();
  }
}, { passive: true });
window.addEventListener("beforeunload", () => {
  playerPageUnloading = true;
  clearTutorialPositionTimer();
  if (videoObjectUrl) {
    URL.revokeObjectURL(videoObjectUrl);
  }
  if (processedVideoObjectUrl) {
    URL.revokeObjectURL(processedVideoObjectUrl);
  }
  clearPlayerPortReconnectTimer();
  playerPort?.disconnect();
  browserFfmpegService.terminate();
});
void loadShortcutSettings().catch((error) => {
  const message = error instanceof Error ? error.message : String(error);
  appendLog("\u8BFB\u53D6\u5FEB\u6377\u952E\u8BBE\u7F6E\u5931\u8D25", { message });
});
void loadTutorialState().then(() => {
  if (shouldAutoOpenTutorial()) {
    window.setTimeout(() => {
      openTutorial({ scroll: true });
    }, 420);
  }
}).catch((error) => {
  appendLog("\u8BFB\u53D6\u65B0\u624B\u5F15\u5BFC\u72B6\u6001\u5931\u8D25", {
    message: error instanceof Error ? error.message : String(error)
  });
});
if (searchParameters.get("autofetch") === "1") {
  void fetchRemoteManifest().catch((error) => {
    const message = error instanceof Error ? error.message : String(error);
    setStatus(message);
    appendLog("\u81EA\u52A8\u62C9\u53D6\u540C\u6B65\u6E05\u5355\u5931\u8D25", { message });
  });
}
//# sourceMappingURL=player.js.map
